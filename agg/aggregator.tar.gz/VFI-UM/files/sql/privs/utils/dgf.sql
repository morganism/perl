grant select, references on dgf.node_ref to utils with grant option;
grant select, references on dgf.system_ref to utils with grant option;

exit;
