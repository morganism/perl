grant execute on um.unload_old_ss_suspense to gdl;

exit;
