grant dgf_ro to customer;

grant select, references on dgf.node_ref to customer with grant option;

exit
