grant select on gdl.format_mapping_version to customer;
grant select on gdl.format_mapping         to customer;

exit
