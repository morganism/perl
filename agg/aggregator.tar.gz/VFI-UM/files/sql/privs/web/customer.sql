grant select, delete, update, insert on customer.interconnect_routes to web;
grant select, delete, update, insert on customer.itc_excl_service_centre to web;
grant select, delete, update, insert on customer.postpaid_voice_free_of_charge to web;
grant select, delete, update, insert on customer.V_FILE_METRIC_ISSUES to web;
grant select, delete, update, insert on CUSTOMER.V_MREC_CAT_OPEN_ISSUES to web;
grant select, delete, update, insert on customer.partners to web;


exit
