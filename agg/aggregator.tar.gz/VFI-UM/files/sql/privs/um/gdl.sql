grant select on um.sql_ref to gdl;

exit
