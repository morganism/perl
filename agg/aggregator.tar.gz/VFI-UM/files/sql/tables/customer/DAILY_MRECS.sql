create table customer.daily_mrecs ( mrec_definition_id number ) 
/

exit
