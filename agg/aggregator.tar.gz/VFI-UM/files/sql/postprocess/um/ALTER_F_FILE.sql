


alter table um.f_file_staging modify edr_bytes number;
alter table um.f_file modify edr_bytes number;

exit;
