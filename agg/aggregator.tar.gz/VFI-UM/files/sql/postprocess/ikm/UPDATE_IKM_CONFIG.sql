update ikm.jam_topic
set    current_version_id = 37023
where  topic_id = 2;

commit;

exit;
