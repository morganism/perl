
insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100266, 'MSS vs GMSC ICCS (Count) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Count - Reconciliation Threshold', 'Percentage', 'MSS vs GMSC ICCS (Count) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100267, 'GMSC ICCS vs ICCS Unbilled (Count) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Count - Reconciliation Threshold', 'Percentage', 'GMSC ICCS vs ICCS Unbilled (Count) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100268, 'TAPIN MO vs ICCS Unbilled (Count) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count - Reconciliation Threshold', 'Percentage', 'TAPIN MO vs ICCS Unbilled (Count) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100269, 'GMSC ICCS vs ICCS Unbilled (Duration) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Duration - Reconciliation Threshold', 'Percentage', 'GMSC ICCS vs ICCS Unbilled (Duration) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Duration - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100270, 'TAPIN MO vs ICCS Unbilled (Duration) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Duration - Reconciliation Threshold', 'Percentage', 'TAPIN MO vs ICCS Unbilled (Duration) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Duration - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100271, 'MMSC - MMSC ARP vs MMS ICCS (Count) - ST_MMS_POSTPAID - EDR Count - Reconciliation Threshold', 'Percentage', 'MMSC - MMSC ARP vs MMS ICCS (Count) - ST_MMS_POSTPAID - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100272, 'MMSC - MMSC ARP vs MMS CCN (Count) - ST_MMS_PREPAID - EDR Count - Reconciliation Threshold', 'Percentage', 'MMSC - MMSC ARP vs MMS CCN (Count) - ST_MMS_PREPAID - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100273, 'MMSC - MMSC ARP vs MMS ICCS + MMS CCN (Count) - ST_MMS - EDR Count - Reconciliation Threshold', 'Percentage', 'MMSC - MMSC ARP vs MMS ICCS + MMS CCN (Count) - ST_MMS - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100274, 'PGW vs EMM Data (Bytes) - ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes - Reconciliation Threshold', 'Percentage', 'PGW vs EMM Data (Bytes) - ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100275, 'PGW vs EMM Data (Bytes) - ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes - Reconciliation Threshold', 'Percentage', 'PGW vs EMM Data (Bytes) - ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100300, 'EMM Data: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold', 'Percentage', 'EMM Data: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100301, 'EMM Data: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count - Metric Threshold', 'Percentage', 'EMM Data: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100302, 'EMM Data: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold', 'Percentage', 'EMM Data: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100303, 'EMM Data: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count - Metric Threshold', 'Percentage', 'EMM Data: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100304, 'GMSC: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Count - Metric Threshold', 'Percentage', 'GMSC: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100305, 'GMSC: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Duration - Metric Threshold', 'Percentage', 'GMSC: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Duration - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100306, 'ICCS Unbilled: ST_SMS_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count - Metric Threshold', 'Percentage', 'ICCS Unbilled: ST_SMS_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100307, 'ICCS Unbilled: ST_SMS_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Value - Metric Threshold', 'Percentage', 'ICCS Unbilled: ST_SMS_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100308, 'MMSC ARP: ST_MMS_POSTPAID - EDR Bytes - Metric Threshold', 'Percentage', 'MMSC ARP: ST_MMS_POSTPAID - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100309, 'MMSC ARP: ST_MMS_POSTPAID - EDR Count - Metric Threshold', 'Percentage', 'MMSC ARP: ST_MMS_POSTPAID - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100310, 'MMSC ARP: ST_MMS_POSTPAID_ARP - EDR Count - Metric Threshold', 'Percentage', 'MMSC ARP: ST_MMS_POSTPAID_ARP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100311, 'MMSC ARP: ST_MMS_POSTPAID_HOME_MO - EDR Bytes - Metric Threshold', 'Percentage', 'MMSC ARP: ST_MMS_POSTPAID_HOME_MO - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100312, 'MMSC ARP: ST_MMS_POSTPAID_HOME_MO - EDR Count - Metric Threshold', 'Percentage', 'MMSC ARP: ST_MMS_POSTPAID_HOME_MO - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100313, 'MMSC ARP: ST_MMS_POSTPAID_HOME_MO_ARP - EDR Count - Metric Threshold', 'Percentage', 'MMSC ARP: ST_MMS_POSTPAID_HOME_MO_ARP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100314, 'MMSC ARP: ST_MMS_PREPAID - EDR Bytes - Metric Threshold', 'Percentage', 'MMSC ARP: ST_MMS_PREPAID - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100315, 'MMSC ARP: ST_MMS_PREPAID - EDR Count - Metric Threshold', 'Percentage', 'MMSC ARP: ST_MMS_PREPAID - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100316, 'MMSC ARP: ST_MMS_PREPAID_ARP - EDR Count - Metric Threshold', 'Percentage', 'MMSC ARP: ST_MMS_PREPAID_ARP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100317, 'MMSC ARP: ST_MMS_PREPAID_HOME_MO - EDR Bytes - Metric Threshold', 'Percentage', 'MMSC ARP: ST_MMS_PREPAID_HOME_MO - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100318, 'MMSC ARP: ST_MMS_PREPAID_HOME_MO - EDR Count - Metric Threshold', 'Percentage', 'MMSC ARP: ST_MMS_PREPAID_HOME_MO - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100319, 'MMSC ARP: ST_MMS_PREPAID_HOME_MO_ARP - EDR Count - Metric Threshold', 'Percentage', 'MMSC ARP: ST_MMS_PREPAID_HOME_MO_ARP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100320, 'MSS: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Count - Metric Threshold', 'Percentage', 'MSS: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100321, 'MSS: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Duration - Metric Threshold', 'Percentage', 'MSS: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Duration - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100322, 'MSS: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT_ARP - EDR Count - Metric Threshold', 'Percentage', 'MSS: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT_ARP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100323, 'MSS: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT_ARP - EDR Duration - Metric Threshold', 'Percentage', 'MSS: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT_ARP - EDR Duration - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100324, 'PGW: ST_DATA_2G_ARP - EDR Count - Metric Threshold', 'Percentage', 'PGW: ST_DATA_2G_ARP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100325, 'PGW: ST_DATA_2G_OUTBOUND_ROAMERS_ARP - EDR Bytes - Metric Threshold', 'Percentage', 'PGW: ST_DATA_2G_OUTBOUND_ROAMERS_ARP - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100326, 'PGW: ST_DATA_2G_OUTBOUND_ROAMERS_ARP - EDR Count - Metric Threshold', 'Percentage', 'PGW: ST_DATA_2G_OUTBOUND_ROAMERS_ARP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100327, 'PGW: ST_DATA_3G_ARP - EDR Count - Metric Threshold', 'Percentage', 'PGW: ST_DATA_3G_ARP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100328, 'PGW: ST_DATA_3G_OUTBOUND_ROAMERS_ARP - EDR Bytes - Metric Threshold', 'Percentage', 'PGW: ST_DATA_3G_OUTBOUND_ROAMERS_ARP - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100329, 'PGW: ST_DATA_3G_OUTBOUND_ROAMERS_ARP - EDR Count - Metric Threshold', 'Percentage', 'PGW: ST_DATA_3G_OUTBOUND_ROAMERS_ARP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100330, 'PGW: ST_DATA_4G_ARP - EDR Count - Metric Threshold', 'Percentage', 'PGW: ST_DATA_4G_ARP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100331, 'PGW: ST_DATA_4G_OUTBOUND_ROAMERS_ARP - EDR Bytes - Metric Threshold', 'Percentage', 'PGW: ST_DATA_4G_OUTBOUND_ROAMERS_ARP - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100332, 'PGW: ST_DATA_4G_OUTBOUND_ROAMERS_ARP - EDR Count - Metric Threshold', 'Percentage', 'PGW: ST_DATA_4G_OUTBOUND_ROAMERS_ARP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100333, 'PGW: ST_DATA_GPRS_ARP - EDR Count - Metric Threshold', 'Percentage', 'PGW: ST_DATA_GPRS_ARP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100334, 'PGW: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold', 'Percentage', 'PGW: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100335, 'PGW: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count - Metric Threshold', 'Percentage', 'PGW: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100336, 'PGW: ST_DATA_GPRS_OUTBOUND_ROAMERS_ARP - EDR Bytes - Metric Threshold', 'Percentage', 'PGW: ST_DATA_GPRS_OUTBOUND_ROAMERS_ARP - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100337, 'PGW: ST_DATA_GPRS_OUTBOUND_ROAMERS_ARP - EDR Count - Metric Threshold', 'Percentage', 'PGW: ST_DATA_GPRS_OUTBOUND_ROAMERS_ARP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100338, 'PGW: ST_DATA_WAP_ARP - EDR Count - Metric Threshold', 'Percentage', 'PGW: ST_DATA_WAP_ARP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100339, 'PGW: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold', 'Percentage', 'PGW: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100340, 'PGW: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count - Metric Threshold', 'Percentage', 'PGW: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100341, 'PGW: ST_DATA_WAP_OUTBOUND_ROAMERS_ARP - EDR Bytes - Metric Threshold', 'Percentage', 'PGW: ST_DATA_WAP_OUTBOUND_ROAMERS_ARP - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100342, 'PGW: ST_DATA_WAP_OUTBOUND_ROAMERS_ARP - EDR Count - Metric Threshold', 'Percentage', 'PGW: ST_DATA_WAP_OUTBOUND_ROAMERS_ARP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100343, 'SMS ICCS: ST_SMS_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count - Metric Threshold', 'Percentage', 'SMS ICCS: ST_SMS_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100344, 'SMSC: ST_SMS_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count - Metric Threshold', 'Percentage', 'SMSC: ST_SMS_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100345, 'SMSC: ST_SMS_OUTBOUND_POSTPAID_ROAMERS_MO_ARP - EDR Count - Metric Threshold', 'Percentage', 'SMSC: ST_SMS_OUTBOUND_POSTPAID_ROAMERS_MO_ARP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100346, 'TAPIN MO: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count - Metric Threshold', 'Percentage', 'TAPIN MO: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100347, 'TAPIN MO: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Duration - Metric Threshold', 'Percentage', 'TAPIN MO: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Duration - Metric Threshold');



-----------



insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100266, 'MSS vs GMSC ICCS (Count) . ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Count - Reconciliation Threshold', 100266, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100267, 'GMSC ICCS vs ICCS Unbilled (Count) . ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Count - Reconciliation Threshold', 100267, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100268, 'TAPIN MO vs ICCS Unbilled (Count) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count - Reconciliation Threshold', 100268, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100269, 'GMSC ICCS vs ICCS Unbilled (Duration) . ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Duration - Reconciliation Threshold', 100269, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100270, 'TAPIN MO vs ICCS Unbilled (Duration) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Duration - Reconciliation Threshold', 100270, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100271, 'MMSC - MMSC ARP vs MMS ICCS (Count) - ST_MMS_POSTPAID - EDR Count - Reconciliation Threshold', 100271, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100272, 'MMSC - MMSC ARP vs MMS CCN (Count) - ST_MMS_PREPAID - EDR Count - Reconciliation Threshold', 100272, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100273, 'MMSC - MMSC ARP vs MMS ICCS + MMS CCN (Count) - ST_MMS - EDR Count - Reconciliation Threshold', 100273, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100274, 'PGW vs EMM Data (Bytes) - ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes - Reconciliation Threshold', 100274, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100275, 'PGW vs EMM Data (Bytes) - ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes - Reconciliation Threshold', 100275, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100300, 'EMM Data: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold', 100300, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100301, 'EMM Data: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count - Metric Threshold', 100301, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100302, 'EMM Data: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold', 100302, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100303, 'EMM Data: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count - Metric Threshold', 100303, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100304, 'GMSC: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Count - Metric Threshold', 100304, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100305, 'GMSC: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Duration - Metric Threshold', 100305, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100306, 'ICCS Unbilled: ST_SMS_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count - Metric Threshold', 100306, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100307, 'ICCS Unbilled: ST_SMS_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Value - Metric Threshold', 100307, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100308, 'MMSC ARP: ST_MMS_POSTPAID - EDR Bytes - Metric Threshold', 100308, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100309, 'MMSC ARP: ST_MMS_POSTPAID - EDR Count - Metric Threshold', 100309, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100310, 'MMSC ARP: ST_MMS_POSTPAID_ARP - EDR Count - Metric Threshold', 100310, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100311, 'MMSC ARP: ST_MMS_POSTPAID_HOME_MO - EDR Bytes - Metric Threshold', 100311, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100312, 'MMSC ARP: ST_MMS_POSTPAID_HOME_MO - EDR Count - Metric Threshold', 100312, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100313, 'MMSC ARP: ST_MMS_POSTPAID_HOME_MO_ARP - EDR Count - Metric Threshold', 100313, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100314, 'MMSC ARP: ST_MMS_PREPAID - EDR Bytes - Metric Threshold', 100314, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100315, 'MMSC ARP: ST_MMS_PREPAID - EDR Count - Metric Threshold', 100315, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100316, 'MMSC ARP: ST_MMS_PREPAID_ARP - EDR Count - Metric Threshold', 100316, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100317, 'MMSC ARP: ST_MMS_PREPAID_HOME_MO - EDR Bytes - Metric Threshold', 100317, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100318, 'MMSC ARP: ST_MMS_PREPAID_HOME_MO - EDR Count - Metric Threshold', 100318, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100319, 'MMSC ARP: ST_MMS_PREPAID_HOME_MO_ARP - EDR Count - Metric Threshold', 100319, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100320, 'MSS: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Count - Metric Threshold', 100320, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100321, 'MSS: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Duration - Metric Threshold', 100321, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100322, 'MSS: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT_ARP - EDR Count - Metric Threshold', 100322, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100323, 'MSS: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT_ARP - EDR Duration - Metric Threshold', 100323, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100324, 'PGW: ST_DATA_2G_ARP - EDR Count - Metric Threshold', 100324, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100325, 'PGW: ST_DATA_2G_OUTBOUND_ROAMERS_ARP - EDR Bytes - Metric Threshold', 100325, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100326, 'PGW: ST_DATA_2G_OUTBOUND_ROAMERS_ARP - EDR Count - Metric Threshold', 100326, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100327, 'PGW: ST_DATA_3G_ARP - EDR Count - Metric Threshold', 100327, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100328, 'PGW: ST_DATA_3G_OUTBOUND_ROAMERS_ARP - EDR Bytes - Metric Threshold', 100328, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100329, 'PGW: ST_DATA_3G_OUTBOUND_ROAMERS_ARP - EDR Count - Metric Threshold', 100329, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100330, 'PGW: ST_DATA_4G_ARP - EDR Count - Metric Threshold', 100330, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100331, 'PGW: ST_DATA_4G_OUTBOUND_ROAMERS_ARP - EDR Bytes - Metric Threshold', 100331, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100332, 'PGW: ST_DATA_4G_OUTBOUND_ROAMERS_ARP - EDR Count - Metric Threshold', 100332, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100333, 'PGW: ST_DATA_GPRS_ARP - EDR Count - Metric Threshold', 100333, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100334, 'PGW: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold', 100334, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100335, 'PGW: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count - Metric Threshold', 100335, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100336, 'PGW: ST_DATA_GPRS_OUTBOUND_ROAMERS_ARP - EDR Bytes - Metric Threshold', 100336, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100337, 'PGW: ST_DATA_GPRS_OUTBOUND_ROAMERS_ARP - EDR Count - Metric Threshold', 100337, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100338, 'PGW: ST_DATA_WAP_ARP - EDR Count - Metric Threshold', 100338, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100339, 'PGW: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold', 100339, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100340, 'PGW: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count - Metric Threshold', 100340, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100341, 'PGW: ST_DATA_WAP_OUTBOUND_ROAMERS_ARP - EDR Bytes - Metric Threshold', 100341, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100342, 'PGW: ST_DATA_WAP_OUTBOUND_ROAMERS_ARP - EDR Count - Metric Threshold', 100342, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100343, 'SMS ICCS: ST_SMS_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count - Metric Threshold', 100343, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100344, 'SMSC: ST_SMS_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count - Metric Threshold', 100344, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100345, 'SMSC: ST_SMS_OUTBOUND_POSTPAID_ROAMERS_MO_ARP - EDR Count - Metric Threshold', 100345, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100346, 'TAPIN MO: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count - Metric Threshold', 100346, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100347, 'TAPIN MO: ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Duration - Metric Threshold', 100347, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

-----

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101266, 100266, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102266, 100266, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101267, 100267, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102267, 100267, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101268, 100268, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102268, 100268, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101269, 100269, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102269, 100269, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101270, 100270, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102270, 100270, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101271, 100271, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102271, 100271, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101272, 100272, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102272, 100272, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101273, 100273, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102273, 100273, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101274, 100274, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102274, 100274, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101275, 100275, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102275, 100275, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101300, 100300, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102300, 100300, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101301, 100301, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102301, 100301, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101302, 100302, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102302, 100302, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101303, 100303, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102303, 100303, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101304, 100304, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102304, 100304, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101305, 100305, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102305, 100305, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101306, 100306, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102306, 100306, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101307, 100307, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102307, 100307, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101308, 100308, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102308, 100308, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101309, 100309, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102309, 100309, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101310, 100310, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102310, 100310, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101311, 100311, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102311, 100311, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101312, 100312, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102312, 100312, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101313, 100313, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102313, 100313, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101314, 100314, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102314, 100314, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101315, 100315, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102315, 100315, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101316, 100316, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102316, 100316, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101317, 100317, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102317, 100317, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101318, 100318, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102318, 100318, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101319, 100319, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102319, 100319, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101320, 100320, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102320, 100320, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101321, 100321, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102321, 100321, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101322, 100322, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102322, 100322, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101323, 100323, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102323, 100323, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101324, 100324, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102324, 100324, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101325, 100325, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102325, 100325, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101326, 100326, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102326, 100326, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101327, 100327, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102327, 100327, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101328, 100328, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102328, 100328, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101329, 100329, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102329, 100329, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101330, 100330, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102330, 100330, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101331, 100331, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102331, 100331, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101332, 100332, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102332, 100332, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101333, 100333, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102333, 100333, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101334, 100334, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102334, 100334, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101335, 100335, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102335, 100335, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101336, 100336, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102336, 100336, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101337, 100337, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102337, 100337, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101338, 100338, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102338, 100338, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101339, 100339, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102339, 100339, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101340, 100340, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102340, 100340, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101341, 100341, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102341, 100341, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101342, 100342, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102342, 100342, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101343, 100343, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102343, 100343, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101344, 100344, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102344, 100344, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101345, 100345, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102345, 100345, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101346, 100346, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102346, 100346, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101347, 100347, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102347, 100347, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);




-----------


insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101266, 1, 100266, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102266, 2, 100266, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103266, 3, 100266, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104266, 4, 100266, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105266, 5, 100266, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106266, 6, 100266, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107266, 7, 100266, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101267, 1, 100267, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102267, 2, 100267, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103267, 3, 100267, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104267, 4, 100267, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105267, 5, 100267, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106267, 6, 100267, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107267, 7, 100267, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101268, 1, 100268, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102268, 2, 100268, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103268, 3, 100268, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104268, 4, 100268, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105268, 5, 100268, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106268, 6, 100268, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107268, 7, 100268, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101269, 1, 100269, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102269, 2, 100269, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103269, 3, 100269, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104269, 4, 100269, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105269, 5, 100269, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106269, 6, 100269, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107269, 7, 100269, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101270, 1, 100270, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102270, 2, 100270, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103270, 3, 100270, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104270, 4, 100270, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105270, 5, 100270, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106270, 6, 100270, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107270, 7, 100270, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101271, 1, 100271, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102271, 2, 100271, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103271, 3, 100271, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104271, 4, 100271, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105271, 5, 100271, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106271, 6, 100271, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107271, 7, 100271, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101272, 1, 100272, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102272, 2, 100272, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103272, 3, 100272, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104272, 4, 100272, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105272, 5, 100272, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106272, 6, 100272, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107272, 7, 100272, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101273, 1, 100273, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102273, 2, 100273, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103273, 3, 100273, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104273, 4, 100273, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105273, 5, 100273, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106273, 6, 100273, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107273, 7, 100273, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101274, 1, 100274, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102274, 2, 100274, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103274, 3, 100274, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104274, 4, 100274, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105274, 5, 100274, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106274, 6, 100274, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107274, 7, 100274, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101275, 1, 100275, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102275, 2, 100275, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103275, 3, 100275, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104275, 4, 100275, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105275, 5, 100275, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106275, 6, 100275, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107275, 7, 100275, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101300, 1, 100300, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102300, 2, 100300, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103300, 3, 100300, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104300, 4, 100300, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105300, 5, 100300, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106300, 6, 100300, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107300, 7, 100300, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101301, 1, 100301, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102301, 2, 100301, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103301, 3, 100301, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104301, 4, 100301, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105301, 5, 100301, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106301, 6, 100301, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107301, 7, 100301, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101302, 1, 100302, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102302, 2, 100302, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103302, 3, 100302, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104302, 4, 100302, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105302, 5, 100302, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106302, 6, 100302, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107302, 7, 100302, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101303, 1, 100303, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102303, 2, 100303, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103303, 3, 100303, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104303, 4, 100303, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105303, 5, 100303, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106303, 6, 100303, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107303, 7, 100303, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101304, 1, 100304, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102304, 2, 100304, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103304, 3, 100304, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104304, 4, 100304, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105304, 5, 100304, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106304, 6, 100304, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107304, 7, 100304, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101305, 1, 100305, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102305, 2, 100305, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103305, 3, 100305, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104305, 4, 100305, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105305, 5, 100305, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106305, 6, 100305, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107305, 7, 100305, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101306, 1, 100306, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102306, 2, 100306, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103306, 3, 100306, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104306, 4, 100306, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105306, 5, 100306, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106306, 6, 100306, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107306, 7, 100306, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101307, 1, 100307, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102307, 2, 100307, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103307, 3, 100307, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104307, 4, 100307, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105307, 5, 100307, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106307, 6, 100307, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107307, 7, 100307, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101308, 1, 100308, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102308, 2, 100308, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103308, 3, 100308, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104308, 4, 100308, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105308, 5, 100308, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106308, 6, 100308, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107308, 7, 100308, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101309, 1, 100309, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102309, 2, 100309, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103309, 3, 100309, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104309, 4, 100309, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105309, 5, 100309, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106309, 6, 100309, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107309, 7, 100309, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101310, 1, 100310, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102310, 2, 100310, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103310, 3, 100310, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104310, 4, 100310, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105310, 5, 100310, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106310, 6, 100310, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107310, 7, 100310, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101311, 1, 100311, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102311, 2, 100311, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103311, 3, 100311, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104311, 4, 100311, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105311, 5, 100311, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106311, 6, 100311, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107311, 7, 100311, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101312, 1, 100312, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102312, 2, 100312, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103312, 3, 100312, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104312, 4, 100312, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105312, 5, 100312, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106312, 6, 100312, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107312, 7, 100312, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101313, 1, 100313, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102313, 2, 100313, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103313, 3, 100313, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104313, 4, 100313, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105313, 5, 100313, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106313, 6, 100313, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107313, 7, 100313, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101314, 1, 100314, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102314, 2, 100314, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103314, 3, 100314, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104314, 4, 100314, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105314, 5, 100314, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106314, 6, 100314, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107314, 7, 100314, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101315, 1, 100315, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102315, 2, 100315, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103315, 3, 100315, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104315, 4, 100315, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105315, 5, 100315, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106315, 6, 100315, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107315, 7, 100315, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101316, 1, 100316, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102316, 2, 100316, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103316, 3, 100316, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104316, 4, 100316, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105316, 5, 100316, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106316, 6, 100316, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107316, 7, 100316, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101317, 1, 100317, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102317, 2, 100317, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103317, 3, 100317, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104317, 4, 100317, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105317, 5, 100317, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106317, 6, 100317, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107317, 7, 100317, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101318, 1, 100318, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102318, 2, 100318, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103318, 3, 100318, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104318, 4, 100318, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105318, 5, 100318, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106318, 6, 100318, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107318, 7, 100318, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101319, 1, 100319, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102319, 2, 100319, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103319, 3, 100319, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104319, 4, 100319, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105319, 5, 100319, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106319, 6, 100319, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107319, 7, 100319, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101320, 1, 100320, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102320, 2, 100320, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103320, 3, 100320, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104320, 4, 100320, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105320, 5, 100320, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106320, 6, 100320, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107320, 7, 100320, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101321, 1, 100321, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102321, 2, 100321, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103321, 3, 100321, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104321, 4, 100321, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105321, 5, 100321, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106321, 6, 100321, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107321, 7, 100321, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101322, 1, 100322, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102322, 2, 100322, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103322, 3, 100322, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104322, 4, 100322, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105322, 5, 100322, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106322, 6, 100322, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107322, 7, 100322, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101323, 1, 100323, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102323, 2, 100323, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103323, 3, 100323, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104323, 4, 100323, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105323, 5, 100323, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106323, 6, 100323, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107323, 7, 100323, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101324, 1, 100324, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102324, 2, 100324, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103324, 3, 100324, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104324, 4, 100324, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105324, 5, 100324, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106324, 6, 100324, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107324, 7, 100324, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101325, 1, 100325, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102325, 2, 100325, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103325, 3, 100325, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104325, 4, 100325, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105325, 5, 100325, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106325, 6, 100325, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107325, 7, 100325, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101326, 1, 100326, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102326, 2, 100326, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103326, 3, 100326, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104326, 4, 100326, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105326, 5, 100326, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106326, 6, 100326, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107326, 7, 100326, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101327, 1, 100327, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102327, 2, 100327, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103327, 3, 100327, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104327, 4, 100327, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105327, 5, 100327, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106327, 6, 100327, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107327, 7, 100327, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101328, 1, 100328, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102328, 2, 100328, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103328, 3, 100328, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104328, 4, 100328, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105328, 5, 100328, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106328, 6, 100328, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107328, 7, 100328, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101329, 1, 100329, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102329, 2, 100329, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103329, 3, 100329, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104329, 4, 100329, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105329, 5, 100329, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106329, 6, 100329, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107329, 7, 100329, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101330, 1, 100330, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102330, 2, 100330, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103330, 3, 100330, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104330, 4, 100330, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105330, 5, 100330, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106330, 6, 100330, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107330, 7, 100330, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101331, 1, 100331, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102331, 2, 100331, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103331, 3, 100331, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104331, 4, 100331, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105331, 5, 100331, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106331, 6, 100331, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107331, 7, 100331, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101332, 1, 100332, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102332, 2, 100332, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103332, 3, 100332, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104332, 4, 100332, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105332, 5, 100332, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106332, 6, 100332, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107332, 7, 100332, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101333, 1, 100333, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102333, 2, 100333, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103333, 3, 100333, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104333, 4, 100333, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105333, 5, 100333, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106333, 6, 100333, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107333, 7, 100333, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101334, 1, 100334, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102334, 2, 100334, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103334, 3, 100334, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104334, 4, 100334, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105334, 5, 100334, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106334, 6, 100334, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107334, 7, 100334, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101335, 1, 100335, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102335, 2, 100335, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103335, 3, 100335, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104335, 4, 100335, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105335, 5, 100335, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106335, 6, 100335, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107335, 7, 100335, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101336, 1, 100336, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102336, 2, 100336, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103336, 3, 100336, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104336, 4, 100336, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105336, 5, 100336, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106336, 6, 100336, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107336, 7, 100336, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101337, 1, 100337, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102337, 2, 100337, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103337, 3, 100337, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104337, 4, 100337, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105337, 5, 100337, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106337, 6, 100337, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107337, 7, 100337, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101338, 1, 100338, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102338, 2, 100338, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103338, 3, 100338, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104338, 4, 100338, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105338, 5, 100338, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106338, 6, 100338, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107338, 7, 100338, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101339, 1, 100339, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102339, 2, 100339, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103339, 3, 100339, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104339, 4, 100339, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105339, 5, 100339, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106339, 6, 100339, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107339, 7, 100339, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101340, 1, 100340, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102340, 2, 100340, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103340, 3, 100340, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104340, 4, 100340, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105340, 5, 100340, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106340, 6, 100340, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107340, 7, 100340, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101341, 1, 100341, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102341, 2, 100341, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103341, 3, 100341, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104341, 4, 100341, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105341, 5, 100341, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106341, 6, 100341, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107341, 7, 100341, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101342, 1, 100342, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102342, 2, 100342, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103342, 3, 100342, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104342, 4, 100342, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105342, 5, 100342, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106342, 6, 100342, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107342, 7, 100342, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101343, 1, 100343, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102343, 2, 100343, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103343, 3, 100343, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104343, 4, 100343, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105343, 5, 100343, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106343, 6, 100343, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107343, 7, 100343, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101344, 1, 100344, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102344, 2, 100344, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103344, 3, 100344, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104344, 4, 100344, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105344, 5, 100344, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106344, 6, 100344, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107344, 7, 100344, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101345, 1, 100345, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102345, 2, 100345, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103345, 3, 100345, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104345, 4, 100345, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105345, 5, 100345, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106345, 6, 100345, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107345, 7, 100345, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101346, 1, 100346, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102346, 2, 100346, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103346, 3, 100346, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104346, 4, 100346, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105346, 5, 100346, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106346, 6, 100346, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107346, 7, 100346, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101347, 1, 100347, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102347, 2, 100347, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103347, 3, 100347, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104347, 4, 100347, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105347, 5, 100347, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106347, 6, 100347, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107347, 7, 100347, 0, 86399);




commit;

exit
