insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100164, 100001, 100000, 'TAPIN MO', 'DS21', '', null);

insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100165, 100001, 100000, 'MMSC ARP', 'DS47', '', null);

insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100166, 100001, 100000, 'GMSC ICCS (Roaming MT)', 'DS78', '', null);

-----------

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100136, 100102, 100166, 1, 'MSS to GMSC ICCS (Roaming MT)', 'MSS to GMSC ICCS (Roaming MT)', ''); 

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100137, 100166, 100120, 1, 'GMSC ICCS (Roaming MT) to ICCS Unbilled', 'GMSC ICCS (Roaming MT) to ICCS Unbilled', ''); 

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100138, 100164, 100120, 1, 'TAPIN MO to ICCS Unbilled', 'TAPIN MO to ICCS Unbilled', '');

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100139, 100165, 100146, 1, 'MMSC ARP to MMS ICCS', 'MMSC ARP to MMS ICCS', '');

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100140, 100165, 100101, 1, 'MMSC ARP to CCN MMS', 'MMSC ARP to CCN MMS', '');

-----------

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100108, 100164); 

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100105, 100165); 

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100104, 100165);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100108, 100166);

commit;

exit
