-- Create entries for new feeds into customer.data_feed_frequency_ref

insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY)
values ('DS21', 'day', 25, 0.1, 7);

insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY)
values ('DS47', 'day', 25, 0.1, 1);

insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY)
values ('DS78', 'day', 25, 0.1, 1);

----------

-- Create table for new TAPIN MO feed
create table customer.STG_AGG_DATA_DS21
(
  currentdir    VARCHAR2(200),
  edrfilename   VARCHAR2(100),
  neid          VARCHAR2(100),
  umidentifier  VARCHAR2(50),
  usagetype     VARCHAR2(10),
  timeslot      DATE,
  servicetype   VARCHAR2(100),
  eventcount    INTEGER,
  sumduration   INTEGER,
  sumbytes      INTEGER,
  sumvalue      INTEGER,
  log_record_id INTEGER,
  processdate   DATE
)
tablespace CUSTOMER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Grant/Revoke object privileges
grant select on customer.STG_AGG_DATA_DS21 to CUSTOMER_RO;
grant select, insert, update, delete on customer.STG_AGG_DATA_DS21 to CUSTOMER_RW;

----------

-- Create table for new MMSC ARP feed
create table customer.STG_AGG_DATA_DS47
(
  currentdir    VARCHAR2(200),
  edrfilename   VARCHAR2(100),
  neid          VARCHAR2(100),
  umidentifier  VARCHAR2(50),
  usagetype     VARCHAR2(10),
  timeslot      DATE,
  servicetype   VARCHAR2(100),
  eventcount    INTEGER,
  sumduration   INTEGER,
  sumbytes      INTEGER,
  sumvalue      INTEGER,
  log_record_id INTEGER,
  processdate   DATE
)
tablespace CUSTOMER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Grant/Revoke object privileges
grant select on customer.STG_AGG_DATA_DS47 to CUSTOMER_RO;
grant select, insert, update, delete on customer.STG_AGG_DATA_DS47 to CUSTOMER_RW;

----------

-- Create table for new GMSC ICCS (Roaming MT) feed
create table customer.STG_AGG_DATA_DS78
(
  currentdir    VARCHAR2(200),
  edrfilename   VARCHAR2(100),
  neid          VARCHAR2(100),
  umidentifier  VARCHAR2(50),
  usagetype     VARCHAR2(10),
  timeslot      DATE,
  servicetype   VARCHAR2(100),
  eventcount    INTEGER,
  sumduration   INTEGER,
  sumbytes      INTEGER,
  sumvalue      INTEGER,
  log_record_id INTEGER,
  processdate   DATE
)
tablespace CUSTOMER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Grant/Revoke object privileges
grant select on customer.STG_AGG_DATA_DS78 to CUSTOMER_RO;
grant select, insert, update, delete on customer.STG_AGG_DATA_DS78 to CUSTOMER_RW;

--------------

grant insert, update, references, select on customer.stg_agg_data_ds21 to gdl;
grant insert, update, references, select on customer.stg_agg_data_ds47 to gdl;
grant insert, update, references, select on customer.stg_agg_data_ds78 to gdl;


insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100130);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100131);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100132);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100133);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100134);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100135);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100136);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100137);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100138);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100139);



commit;



exit
