insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100296, '(M) Import TAPIN MO', '-daemon no -load_type 1 -mapping 100094', 5000);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100297, '(M) Import MMSC ARP', '-daemon no -load_type 1 -mapping 100095', 5000);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100298, '(M) Import GMSC ICCS (Roaming MT)', '-daemon no -load_type 1 -mapping 100096', 5000);

-----

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100565, '(M) Node DS21', '-node 100164 -daemon no -offset 1 --terminatetime 23:59:59', 1);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100566, '(M) Node DS47', '-node 100165 -daemon no -offset 1 --terminatetime 23:59:59', 1);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100567, '(M) Node DS78', '-node 100166 -daemon no -offset 1 --terminatetime 23:59:59', 1);

update jobs.multi_job_ref
set    parameters = replace(parameters, '-match 100000 ','')
where  description like '(M) Node %'
and    parameters like '%-match 100000 %';

delete from jobs.option_job_jn where option_id = 35115 and job_code_id = 35110;

-----

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100765, '(M) Forecasts multi-job for node 100164', '-node_id 100164 -offset 1', 35004); -- DS21

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100766, '(M) Forecasts multi-job for node 100165', '-node_id 100165 -offset 1', 35004); -- DS47

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100767, '(M) Forecasts multi-job for node 100166', '-node_id 100166 -offset 1', 35004); -- DS78

-----

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105200, '(M) MSS vs GMSC ICCS (Count) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Count', '-mrec_id 100120 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105201, '(M) GMSC ICCS vs ICCS Unbilled (Count) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Count', '-mrec_id 100121 -num_days 21 -offset 28', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105202, '(M) TAPIN MO vs ICCS Unbilled (Count) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count', '-mrec_id 100122 -num_days 21 -offset 28', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105203, '(M) GMSC ICCS vs ICCS Unbilled (Duration) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Duration', '-mrec_id 100123 -num_days 21 -offset 28', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105204, '(M) TAPIN MO vs ICCS Unbilled (Duration) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Duration', '-mrec_id 100124 -num_days 21 -offset 28', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105205, '(M) MMSC - MMSC ARP vs MMS ICCS (Count) - ST_MMS_POSTPAID (Daily)', '-mrec_id 100125 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105206, '(M) MMSC - MMSC ARP vs MMS CCN (Count) - ST_MMS_PREPAID (Daily)', '-mrec_id 100126 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105207, '(M) MMSC - MMSC ARP vs MMS ICCS + MMS CCN (Count) - ST_MMS (Daily)', '-mrec_id 100127 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105208, '(M) PGW vs EMM Data (Bytes) - ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes', '-mrec_id 100128 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105209, '(M) PGW vs EMM Data (Bytes) - ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes', '-mrec_id 100129 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105210, '(M) MSS vs GMSC ICCS (Count) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Count (Daily)', '-mrec_id 100130 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105211, '(M) GMSC ICCS vs ICCS Unbilled (Count) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Count (Daily)', '-mrec_id 100131 -num_days 21 -offset 28', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105212, '(M) TAPIN MO vs ICCS Unbilled (Count) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Count (Daily)', '-mrec_id 100132 -num_days 21 -offset 28', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105213, '(M) GMSC ICCS vs ICCS Unbilled (Duration) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MT - EDR Duration (Daily)', '-mrec_id 100133 -num_days 21 -offset 28', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105214, '(M) TAPIN MO vs ICCS Unbilled (Duration) - ST_VOICE_OUTBOUND_POSTPAID_ROAMERS_MO - EDR Duration (Daily)', '-mrec_id 100134 -num_days 21 -offset 28', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105215, '(M) MMSC - MMSC ARP vs MMS ICCS (Count) - ST_MMS_POSTPAID (Daily)', '-mrec_id 100135 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105216, '(M) MMSC - MMSC ARP vs MMS CCN (Count) - ST_MMS_PREPAID (Daily)', '-mrec_id 100136 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105217, '(M) MMSC - MMSC ARP vs MMS ICCS + MMS CCN (Count) - ST_MMS (Daily)', '-mrec_id 100137 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105218, '(M) PGW vs EMM Data (Bytes) - ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes (Daily)', '-mrec_id 100138 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105219, '(M) PGW vs EMM Data (Bytes) - ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes (Daily)', '-mrec_id 100139 -num_days 7 -offset 8', 35005);


-----

/*Imports*/
insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100296, 102000, 100296, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100297, 102000, 100297, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100298, 102000, 100298, null);

--
/*Nodes*/
insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100565, 104000, 100565, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100566, 104000, 100566, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100567, 104000, 100567, null);

--
/*Forecast for node*/
insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100765, 100565, 100765, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100766, 100566, 100766, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100767, 100567, 100767, null);

--
/*Import*/
insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (102131, 100296, null, 5000);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (102132, 100297, null, 5000);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (102133, 100298, null, 5000);

--
/*Forecast*/
insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104223, 100765, null, 100113);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104224, 100766, null, 100100);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104225, 100767, null, 100099);

--
/*Nodes*/
insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104518, 100565, null, 35110);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104519, 100565, null, 35105);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104520, 100566, null, 35110);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104521, 100566, null, 35105);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104522, 100567, null, 35110);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104523, 100567, null, 35105);

--
/*Reconciliations*/
insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105300, 105200, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105301, 105201, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105302, 105202, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105303, 105203, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105304, 105204, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105305, 105205, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105306, 105206, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105307, 105207, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105308, 105208, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105309, 105209, null, 35501);



insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105330, 105210, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105331, 105211, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105332, 105212, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105333, 105213, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105334, 105214, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105335, 105215, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105336, 105216, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105337, 105217, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105338, 105218, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105339, 105219, null, 35501);



--
/*Reconciliations*/
insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105310, 105000, 105200, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105311, 105000, 105201, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105312, 105000, 105202, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105313, 105000, 105203, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105314, 105000, 105204, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105315, 105000, 105205, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105316, 105000, 105206, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105317, 105000, 105207, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105318, 105000, 105208, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105319, 105000, 105209, null);


insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105320, 105000, 105210, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105321, 105000, 105211, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105322, 105000, 105212, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105323, 105000, 105213, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105324, 105000, 105214, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105325, 105000, 105215, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105326, 105000, 105216, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105327, 105000, 105217, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105328, 105000, 105218, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105329, 105000, 105219, null);





-----
/*Dependency*/ 
insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100296,100295);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100297,100296);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100298,100297);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100765,104519);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100766,104521);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100767,104523);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (104519,104518);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (104521,104520);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (104523,104522);

commit;

exit
