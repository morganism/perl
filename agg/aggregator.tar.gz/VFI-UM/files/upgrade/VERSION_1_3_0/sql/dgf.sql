set scan off
set define off

-----------


insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100170, 100001, 100000, 'Eircom', 'DS90', '', null);

insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100171, 100001, 100000, 'BT', 'DS91', '', null);

insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100172, 100001, 100000, 'C&W', 'DS92', '', null);

insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100173, 100001, 100000, 'SS Rated', 'DS93', '', null);

insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100174, 100001, 100000, 'SS Discarded', 'DS94', '', null);

insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100175, 100001, 100000, 'SS Billed', 'DS95', '', null);

insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100176, 100001, 100000, 'VOIP', 'DS96', '', null);

insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100177, 100001, 100000, 'SS Rated Suspense', 'DS98', '', null);

insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100178, 100001, 100000, 'SS Rated Suspense History', 'DS99', '', null);


insert into dgf.graph_ref (GRAPH_ID, GRAPH_TYPE_ID, NAME, DESCRIPTION, NOTE, IS_SYSTEM)
values (100132, 8001, 'Fixed Line', 'Fiex Line nodes', '', '');

insert into dgf.node_group_ref (NODE_GROUP_ID, GRAPH_ID, NODE_GROUP, DESCRIPTION)
values (100112, 100132, 'Fixed Line ', 'All the Data Sources which comprise the Fixed Line path');



insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100112, 100170);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100112, 100171);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100112, 100172);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100112, 100173);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100112, 100174);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100112, 100175);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100112, 100176);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100112, 100177);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100112, 100178);



insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100150, 100170, 100173, 1, 'Eircom to SS Rated', 'Eircom to SS Rated', '');

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100151, 100171, 100173, 1, 'BT to SS Rated', 'BT to SS Rated', '');

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100152, 100172, 100173, 1, 'C&W to SS Rated', 'C&W to SS Rated', '');

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100153, 100176, 100173, 1, 'VOIP to SS Rated', 'VOIP to SS Rated', '');

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100154, 100173, 100174, 1, 'SS Rated to SS Discarded', 'SS Rated to SS Discarded', '');

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100155, 100173, 100177, 1, 'SS Rated to SS Suspense', 'SS Rated to SS Suspense', '');

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100156, 100173, 100178, 1, 'SS Rated to SS Suspense History', 'SS Rated to SS Suspense History', '');

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100157, 100173, 100175, 1, 'SS Rated to SS Billed', 'SS Rated to SS Billed', '');



commit;

exit

