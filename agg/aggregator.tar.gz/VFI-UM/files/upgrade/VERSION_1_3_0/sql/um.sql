set scan off
set define off

-----------


insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100170, 'ST_VOICE_PARTNERS', 'Voice for Partner customers (MVNO & Wholesale)');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100171, 'ST_DATA_PARTNERS', 'Data for Partner customers (MVNO & Wholesale)');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100172, 'ST_VOICE_IN_BUNDLE', 'Voice In Bundle');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100173, 'ST_VOICE_OUT_BUNDLE', 'Voice Out of Bundle');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100174, 'ST_VOICE_FO', 'Fixed Line Voice Originating');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100175, 'ST_VOICE_FT', 'Fixed Line Voice Terminating');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100176, 'ST_VOICE_INTL', 'Voice International');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100177, 'ST_VOICE_DOM', 'Voice Domestic');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100178, 'ST_VOICE_MT', 'Voice Mobile');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100179, 'ST_VOICE_MT_INTL', 'Voice Mobile International');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100180, 'ST_VOICE_INTL_FREE', 'Voice Mobile International Free');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100181, 'ST_VOICE_PREMIUM', 'Voice Premium');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100182, 'ST_VOICE_PREMIUM_INTL', 'Vocie Premium International');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100183, 'ST_VOICE_INTERNET', 'Voice Internet');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100184, 'ST_VOICE_VOIP', 'Voip');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100185, 'ST_VOICE_DQ', 'Directory Enquiries');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100186, 'ST_VOICE_LOW_CALL', 'Voice Low-Call');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100187, 'ST_VOICE_NGN', 'NGN');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100188, 'ST_VOICE_PROMOTIONAL', 'Voice Promotional');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100189, 'ST_VOICE_ANCILIARY', 'Anciliary');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100190, 'ST_VOICE_INBOUND', 'Voice Inbound');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100191, 'ST_SUSPENSE', 'Suspense');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100192, 'ST_VOICE_SUSPENSE', 'Voice Suspense');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100193, 'ST_VOICE_AGED', 'Voice Suspense Aged');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100194, 'ST_VOICE_EXPIRING', 'Voice Suspense About to Expire');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100195, 'ST_VOICE_DISCARDED', 'Voice Discarded');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100196, 'ST_DISCARDED', 'Discarded CDR');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100197, 'ST_SMS_IN_BUNDLE', 'SMS In Bundle');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100198, 'ST_SMS_OUT_BUNDLE', 'SMS Out of Bundle');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100199, 'ST_DATA_IN_BUNDLE', 'Data In Bundle');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100200, 'ST_DATA_OUT_BUNDLE', 'Data Out of Bundle');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100201, 'ST_MMS_IN_BUNDLE', 'MMS In Bundle');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100202, 'ST_MMS_OUT_BUNDLE', 'MMS Out of Bundle');


insert into um.source_type_ref (SOURCE_TYPE_ID, SOURCE_TYPE, DESCRIPTION)
values (100082, 'Eircom', 'Eircom');

insert into um.source_type_ref (SOURCE_TYPE_ID, SOURCE_TYPE, DESCRIPTION)
values (100083, 'BT', 'BT');

insert into um.source_type_ref (SOURCE_TYPE_ID, SOURCE_TYPE, DESCRIPTION)
values (100084, 'C&W', 'C&W');

insert into um.source_type_ref (SOURCE_TYPE_ID, SOURCE_TYPE, DESCRIPTION)
values (100085, 'VOIP', 'VOIP');




insert into um.source_type_ref (SOURCE_TYPE_ID, SOURCE_TYPE, DESCRIPTION)
values (100100, 'MVNO Partners', 'MVNO Partners');


insert into um.source_type_ref (SOURCE_TYPE_ID, SOURCE_TYPE, DESCRIPTION)
values (100101, 'Wholesale Partners', 'Wholesale Partners');


insert into um.source_ref (SOURCE_ID, SOURCE_TYPE_ID, REGION_ID, SYSTEM_ID, COUNTRY_ID, NAME, IDENTIFIER)
values (100082, 100082, -1, -1, -1, 'Eircom', 'Eircom');

insert into um.source_ref (SOURCE_ID, SOURCE_TYPE_ID, REGION_ID, SYSTEM_ID, COUNTRY_ID, NAME, IDENTIFIER)
values (100083, 100083, -1, -1, -1, 'BT', 'BT');

insert into um.source_ref (SOURCE_ID, SOURCE_TYPE_ID, REGION_ID, SYSTEM_ID, COUNTRY_ID, NAME, IDENTIFIER)
values (100084, 100084, -1, -1, -1, 'C&W', 'C&W');

insert into um.source_ref (SOURCE_ID, SOURCE_TYPE_ID, REGION_ID, SYSTEM_ID, COUNTRY_ID, NAME, IDENTIFIER)
values (100085, 100085, -1, -1, -1, 'VOIP', 'VOIP');




insert into um.source_ref (SOURCE_ID, SOURCE_TYPE_ID, REGION_ID, SYSTEM_ID, COUNTRY_ID, NAME, IDENTIFIER)
values (100072, 100100, -1, -1, -1, 'Just Mobile', 'JUST_MOBILE');

insert into um.source_ref (SOURCE_ID, SOURCE_TYPE_ID, REGION_ID, SYSTEM_ID, COUNTRY_ID, NAME, IDENTIFIER)
values (100073, 100100, -1, -1, -1, 'Postfone', 'POSTFONE');

insert into um.source_ref (SOURCE_ID, SOURCE_TYPE_ID, REGION_ID, SYSTEM_ID, COUNTRY_ID, NAME, IDENTIFIER)
values (100074, 100100, -1, -1, -1, 'e-Mobile', 'E-MOBILE');

insert into um.source_ref (SOURCE_ID, SOURCE_TYPE_ID, REGION_ID, SYSTEM_ID, COUNTRY_ID, NAME, IDENTIFIER)
values (100075, 100100, -1, -1, -1, 'Meteor  ', 'METEOR');

insert into um.source_ref (SOURCE_ID, SOURCE_TYPE_ID, REGION_ID, SYSTEM_ID, COUNTRY_ID, NAME, IDENTIFIER)
values (100076, 100100, -1, -1, -1, 'Hutchinson', 'HUTCHINSON');

insert into um.source_ref (SOURCE_ID, SOURCE_TYPE_ID, REGION_ID, SYSTEM_ID, COUNTRY_ID, NAME, IDENTIFIER)
values (100077, 100100, -1, -1, -1, 'Tesco', 'TESCO');

insert into um.source_ref (SOURCE_ID, SOURCE_TYPE_ID, REGION_ID, SYSTEM_ID, COUNTRY_ID, NAME, IDENTIFIER)
values (100078, 100100, -1, -1, -1, 'Lyca Mobile', 'LYCA_MOBILE');

insert into um.source_ref (SOURCE_ID, SOURCE_TYPE_ID, REGION_ID, SYSTEM_ID, COUNTRY_ID, NAME, IDENTIFIER)
values (100079, 100100, -1, -1, -1, 'UPC', 'UPC');

insert into um.source_ref (SOURCE_ID, SOURCE_TYPE_ID, REGION_ID, SYSTEM_ID, COUNTRY_ID, NAME, IDENTIFIER)
values (100080, 100100, -1, -1, -1, 'Carphone Warehouse', 'CARPHONE_WAREHOUSE');



insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100173, 'Eircom', 100082);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100174, 'Eircom', 100082);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100175, 'Eircom', 100082);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100177, 'Eircom', 100082);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100178, 'Eircom', 100082);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100173, 'BT', 100083);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100174, 'BT', 100083);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100175, 'BT', 100083);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100177, 'BT', 100083);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100178, 'BT', 100083);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100173, 'C&W', 100084);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100174, 'C&W', 100084);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100175, 'C&W', 100084);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100177, 'C&W', 100084);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100178, 'C&W', 100084);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100173, 'VOIP', 100085);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100174, 'VOIP', 100085);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100175, 'VOIP', 100085);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100177, 'VOIP', 100085);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100178, 'VOIP', 100085);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100102, 'JUST_MOBILE', 100072);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100105, 'JUST_MOBILE', 100072);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100120, 'JUST_MOBILE', 100072);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100141, 'JUST_MOBILE', 100072);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100142, 'JUST_MOBILE', 100072);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100144, 'JUST_MOBILE', 100072);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100152, 'JUST_MOBILE', 100072);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100102, 'POSTFONE', 100073);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100105, 'POSTFONE', 100073);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100120, 'POSTFONE', 100073);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100141, 'POSTFONE', 100073);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100142, 'POSTFONE', 100073);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100144, 'POSTFONE', 100073);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100152, 'POSTFONE', 100073);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100102, 'E-MOBILE', 100074);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100105, 'E-MOBILE', 100074);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100120, 'E-MOBILE', 100074);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100141, 'E-MOBILE', 100074);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100142, 'E-MOBILE', 100074);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100144, 'E-MOBILE', 100074);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100152, 'E-MOBILE', 100074);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100102, 'METEOR', 100075);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100105, 'METEOR', 100075);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100120, 'METEOR', 100075);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100141, 'METEOR', 100075);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100142, 'METEOR', 100075);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100144, 'METEOR', 100075);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100152, 'METEOR', 100075);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100102, 'HUTCHINSON', 100076);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100105, 'HUTCHINSON', 100076);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100120, 'HUTCHINSON', 100076);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100141, 'HUTCHINSON', 100076);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100142, 'HUTCHINSON', 100076);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100144, 'HUTCHINSON', 100076);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100152, 'HUTCHINSON', 100076);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100102, 'TESCO', 100077);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100105, 'TESCO', 100077);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100120, 'TESCO', 100077);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100141, 'TESCO', 100077);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100142, 'TESCO', 100077);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100144, 'TESCO', 100077);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100152, 'TESCO', 100077);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100102, 'LYCA_MOBILE', 100078);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100105, 'LYCA_MOBILE', 100078);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100120, 'LYCA_MOBILE', 100078);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100141, 'LYCA_MOBILE', 100078);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100142, 'LYCA_MOBILE', 100078);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100144, 'LYCA_MOBILE', 100078);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100152, 'LYCA_MOBILE', 100078);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100102, 'UPC', 100079);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100105, 'UPC', 100079);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100120, 'UPC', 100079);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100141, 'UPC', 100079);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100142, 'UPC', 100079);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100144, 'UPC', 100079);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100152, 'UPC', 100079);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100102, 'CARPHONE_WAREHOUSE', 100080);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100105, 'CARPHONE_WAREHOUSE', 100080);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100120, 'CARPHONE_WAREHOUSE', 100080);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100141, 'CARPHONE_WAREHOUSE', 100080);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100142, 'CARPHONE_WAREHOUSE', 100080);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100144, 'CARPHONE_WAREHOUSE', 100080);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100152, 'CARPHONE_WAREHOUSE', 100080);


insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100170, 100000);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100171, 100000);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100172, 100000);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100173, 100000);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100174, 100000);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100175, 100000);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100176, 100000);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100177, 100000);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100178, 100000);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100170, 100001);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100171, 100001);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100172, 100001);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100173, 100001);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100174, 100001);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100175, 100001);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100176, 100001);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100177, 100001);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100178, 100001);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100170, 100002);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100171, 100002);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100172, 100002);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100173, 100002);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100174, 100002);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100175, 100002);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100176, 100002);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100177, 100002);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100178, 100002);





insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102001, 'ST_DATA_PARTNERS - EDR Bytes', 'ST_DATA_PARTNERS - EDR Bytes', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102002, 'ST_DATA_PARTNERS - EDR Bytes (Daily)', 'ST_DATA_PARTNERS - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102003, 'ST_DATA_PARTNERS - EDR Count', 'ST_DATA_PARTNERS - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102004, 'ST_DATA_PARTNERS - EDR Count (Daily)', 'ST_DATA_PARTNERS - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102005, 'ST_DISCARDED - EDR Count', 'ST_DISCARDED - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102006, 'ST_DISCARDED - EDR Count (Daily)', 'ST_DISCARDED - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102007, 'ST_SMS - EDR Count (Daily)', 'ST_SMS - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102008, 'ST_SMS - EDR Value (Daily)', 'ST_SMS - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102009, 'ST_SUSPENSE - EDR Count', 'ST_SUSPENSE - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102010, 'ST_SUSPENSE - EDR Count (Daily)', 'ST_SUSPENSE - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102011, 'ST_VOICE - EDR Count (Daily)', 'ST_VOICE - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102012, 'ST_VOICE - EDR Duration (Daily)', 'ST_VOICE - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102013, 'ST_VOICE - EDR Value (Daily)', 'ST_VOICE - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102014, 'ST_VOICE_AGED - EDR Count', 'ST_VOICE_AGED - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102015, 'ST_VOICE_AGED - EDR Count (Daily)', 'ST_VOICE_AGED - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102016, 'ST_VOICE_ANCILIARY - EDR Count', 'ST_VOICE_ANCILIARY - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102017, 'ST_VOICE_ANCILIARY - EDR Count (Daily)', 'ST_VOICE_ANCILIARY - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102018, 'ST_VOICE_ANCILIARY - EDR Duration', 'ST_VOICE_ANCILIARY - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102019, 'ST_VOICE_ANCILIARY - EDR Duration (Daily)', 'ST_VOICE_ANCILIARY - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102020, 'ST_VOICE_ANCILIARY - EDR Value', 'ST_VOICE_ANCILIARY - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102021, 'ST_VOICE_ANCILIARY - EDR Value (Daily)', 'ST_VOICE_ANCILIARY - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102028, 'ST_VOICE_DISCARDED - EDR Count', 'ST_VOICE_DISCARDED - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102029, 'ST_VOICE_DISCARDED - EDR Count (Daily)', 'ST_VOICE_DISCARDED - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102030, 'ST_VOICE_DOM - EDR Count', 'ST_VOICE_DOM - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102031, 'ST_VOICE_DOM - EDR Count (Daily)', 'ST_VOICE_DOM - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102032, 'ST_VOICE_DOM - EDR Duration', 'ST_VOICE_DOM - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102033, 'ST_VOICE_DOM - EDR Duration (Daily)', 'ST_VOICE_DOM - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102034, 'ST_VOICE_DOM - EDR Value', 'ST_VOICE_DOM - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102035, 'ST_VOICE_DOM - EDR Value (Daily)', 'ST_VOICE_DOM - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102036, 'ST_VOICE_DQ - EDR Count', 'ST_VOICE_DQ - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102037, 'ST_VOICE_DQ - EDR Count (Daily)', 'ST_VOICE_DQ - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102038, 'ST_VOICE_DQ - EDR Duration', 'ST_VOICE_DQ - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102039, 'ST_VOICE_DQ - EDR Duration (Daily)', 'ST_VOICE_DQ - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102040, 'ST_VOICE_DQ - EDR Value', 'ST_VOICE_DQ - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102041, 'ST_VOICE_DQ - EDR Value (Daily)', 'ST_VOICE_DQ - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102042, 'ST_VOICE_EXPIRING - EDR Count', 'ST_VOICE_EXPIRING - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102043, 'ST_VOICE_EXPIRING - EDR Count (Daily)', 'ST_VOICE_EXPIRING - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102044, 'ST_VOICE_FO - EDR Count', 'ST_VOICE_FO - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102045, 'ST_VOICE_FO - EDR Count (Daily)', 'ST_VOICE_FO - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102046, 'ST_VOICE_FO - EDR Duration', 'ST_VOICE_FO - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102047, 'ST_VOICE_FO - EDR Duration (Daily)', 'ST_VOICE_FO - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102048, 'ST_VOICE_FO - EDR Value', 'ST_VOICE_FO - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102049, 'ST_VOICE_FO - EDR Value (Daily)', 'ST_VOICE_FO - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102050, 'ST_VOICE_FT - EDR Count', 'ST_VOICE_FT - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102051, 'ST_VOICE_FT - EDR Count (Daily)', 'ST_VOICE_FT - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102052, 'ST_VOICE_FT - EDR Duration', 'ST_VOICE_FT - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102053, 'ST_VOICE_FT - EDR Duration (Daily)', 'ST_VOICE_FT - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102054, 'ST_VOICE_FT - EDR Value', 'ST_VOICE_FT - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102055, 'ST_VOICE_FT - EDR Value (Daily)', 'ST_VOICE_FT - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102056, 'ST_VOICE_INBOUND - EDR Count', 'ST_VOICE_INBOUND - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102057, 'ST_VOICE_INBOUND - EDR Count (Daily)', 'ST_VOICE_INBOUND - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102058, 'ST_VOICE_INBOUND - EDR Duration', 'ST_VOICE_INBOUND - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102059, 'ST_VOICE_INBOUND - EDR Duration (Daily)', 'ST_VOICE_INBOUND - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102060, 'ST_VOICE_INBOUND - EDR Value', 'ST_VOICE_INBOUND - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102061, 'ST_VOICE_INBOUND - EDR Value (Daily)', 'ST_VOICE_INBOUND - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102062, 'ST_VOICE_INTERNET - EDR Count', 'ST_VOICE_INTERNET - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102063, 'ST_VOICE_INTERNET - EDR Count (Daily)', 'ST_VOICE_INTERNET - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102064, 'ST_VOICE_INTERNET - EDR Duration', 'ST_VOICE_INTERNET - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102065, 'ST_VOICE_INTERNET - EDR Duration (Daily)', 'ST_VOICE_INTERNET - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102066, 'ST_VOICE_INTERNET - EDR Value', 'ST_VOICE_INTERNET - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102067, 'ST_VOICE_INTERNET - EDR Value (Daily)', 'ST_VOICE_INTERNET - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102068, 'ST_VOICE_INTL - EDR Count', 'ST_VOICE_INTL - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102069, 'ST_VOICE_INTL - EDR Count (Daily)', 'ST_VOICE_INTL - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102070, 'ST_VOICE_INTL - EDR Duration', 'ST_VOICE_INTL - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102071, 'ST_VOICE_INTL - EDR Duration (Daily)', 'ST_VOICE_INTL - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102072, 'ST_VOICE_INTL - EDR Value', 'ST_VOICE_INTL - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102073, 'ST_VOICE_INTL - EDR Value (Daily)', 'ST_VOICE_INTL - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102074, 'ST_VOICE_INTL_FREE - EDR Count', 'ST_VOICE_INTL_FREE - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102075, 'ST_VOICE_INTL_FREE - EDR Count (Daily)', 'ST_VOICE_INTL_FREE - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102076, 'ST_VOICE_INTL_FREE - EDR Duration', 'ST_VOICE_INTL_FREE - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102077, 'ST_VOICE_INTL_FREE - EDR Duration (Daily)', 'ST_VOICE_INTL_FREE - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102078, 'ST_VOICE_IN_BUNDLE - EDR Count', 'ST_VOICE_IN_BUNDLE - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102079, 'ST_VOICE_IN_BUNDLE - EDR Count (Daily)', 'ST_VOICE_IN_BUNDLE - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102080, 'ST_VOICE_IN_BUNDLE - EDR Duration', 'ST_VOICE_IN_BUNDLE - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102081, 'ST_VOICE_IN_BUNDLE - EDR Duration (Daily)', 'ST_VOICE_IN_BUNDLE - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102082, 'ST_VOICE_IN_BUNDLE - EDR Value', 'ST_VOICE_IN_BUNDLE - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102083, 'ST_VOICE_IN_BUNDLE - EDR Value (Daily)', 'ST_VOICE_IN_BUNDLE - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102084, 'ST_VOICE_LOW_CALL - EDR Count', 'ST_VOICE_LOW_CALL - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102085, 'ST_VOICE_LOW_CALL - EDR Count (Daily)', 'ST_VOICE_LOW_CALL - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102086, 'ST_VOICE_LOW_CALL - EDR Duration', 'ST_VOICE_LOW_CALL - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102087, 'ST_VOICE_LOW_CALL - EDR Duration (Daily)', 'ST_VOICE_LOW_CALL - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102088, 'ST_VOICE_LOW_CALL - EDR Value', 'ST_VOICE_LOW_CALL - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102089, 'ST_VOICE_LOW_CALL - EDR Value (Daily)', 'ST_VOICE_LOW_CALL - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102090, 'ST_VOICE_MT - EDR Count', 'ST_VOICE_MT - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102091, 'ST_VOICE_MT - EDR Count (Daily)', 'ST_VOICE_MT - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102092, 'ST_VOICE_MT - EDR Duration', 'ST_VOICE_MT - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102093, 'ST_VOICE_MT - EDR Duration (Daily)', 'ST_VOICE_MT - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102094, 'ST_VOICE_MT - EDR Value', 'ST_VOICE_MT - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102095, 'ST_VOICE_MT - EDR Value (Daily)', 'ST_VOICE_MT - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102096, 'ST_VOICE_MT_INTL - EDR Count', 'ST_VOICE_MT_INTL - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102097, 'ST_VOICE_MT_INTL - EDR Count (Daily)', 'ST_VOICE_MT_INTL - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102098, 'ST_VOICE_MT_INTL - EDR Duration', 'ST_VOICE_MT_INTL - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102099, 'ST_VOICE_MT_INTL - EDR Duration (Daily)', 'ST_VOICE_MT_INTL - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102100, 'ST_VOICE_MT_INTL - EDR Value', 'ST_VOICE_MT_INTL - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102101, 'ST_VOICE_MT_INTL - EDR Value (Daily)', 'ST_VOICE_MT_INTL - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102102, 'ST_VOICE_NGN - EDR Count', 'ST_VOICE_NGN - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102103, 'ST_VOICE_NGN - EDR Count (Daily)', 'ST_VOICE_NGN - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102104, 'ST_VOICE_NGN - EDR Duration', 'ST_VOICE_NGN - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102105, 'ST_VOICE_NGN - EDR Duration (Daily)', 'ST_VOICE_NGN - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102106, 'ST_VOICE_NGN - EDR Value', 'ST_VOICE_NGN - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102107, 'ST_VOICE_NGN - EDR Value (Daily)', 'ST_VOICE_NGN - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102108, 'ST_VOICE_OUT_BUNDLE - EDR Count', 'ST_VOICE_OUT_BUNDLE - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102109, 'ST_VOICE_OUT_BUNDLE - EDR Count (Daily)', 'ST_VOICE_OUT_BUNDLE - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102110, 'ST_VOICE_OUT_BUNDLE - EDR Duration', 'ST_VOICE_OUT_BUNDLE - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102111, 'ST_VOICE_OUT_BUNDLE - EDR Duration (Daily)', 'ST_VOICE_OUT_BUNDLE - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102112, 'ST_VOICE_OUT_BUNDLE - EDR Value', 'ST_VOICE_OUT_BUNDLE - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102113, 'ST_VOICE_OUT_BUNDLE - EDR Value (Daily)', 'ST_VOICE_OUT_BUNDLE - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102114, 'ST_VOICE_PARTNERS - EDR Count', 'ST_VOICE_PARTNERS - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102115, 'ST_VOICE_PARTNERS - EDR Count (Daily)', 'ST_VOICE_PARTNERS - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102116, 'ST_VOICE_PARTNERS - EDR Duration', 'ST_VOICE_PARTNERS - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102117, 'ST_VOICE_PARTNERS - EDR Duration (Daily)', 'ST_VOICE_PARTNERS - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102118, 'ST_VOICE_PREMIUM - EDR Count', 'ST_VOICE_PREMIUM - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102119, 'ST_VOICE_PREMIUM - EDR Count (Daily)', 'ST_VOICE_PREMIUM - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102120, 'ST_VOICE_PREMIUM - EDR Duration', 'ST_VOICE_PREMIUM - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102121, 'ST_VOICE_PREMIUM - EDR Duration (Daily)', 'ST_VOICE_PREMIUM - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102122, 'ST_VOICE_PREMIUM - EDR Value', 'ST_VOICE_PREMIUM - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102123, 'ST_VOICE_PREMIUM - EDR Value (Daily)', 'ST_VOICE_PREMIUM - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102124, 'ST_VOICE_PREMIUM_INTL - EDR Count', 'ST_VOICE_PREMIUM_INTL - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102125, 'ST_VOICE_PREMIUM_INTL - EDR Count (Daily)', 'ST_VOICE_PREMIUM_INTL - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102126, 'ST_VOICE_PREMIUM_INTL - EDR Duration', 'ST_VOICE_PREMIUM_INTL - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102127, 'ST_VOICE_PREMIUM_INTL - EDR Duration (Daily)', 'ST_VOICE_PREMIUM_INTL - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102128, 'ST_VOICE_PREMIUM_INTL - EDR Value', 'ST_VOICE_PREMIUM_INTL - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102129, 'ST_VOICE_PREMIUM_INTL - EDR Value (Daily)', 'ST_VOICE_PREMIUM_INTL - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102130, 'ST_VOICE_PROMOTIONAL - EDR Count', 'ST_VOICE_PROMOTIONAL - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102131, 'ST_VOICE_PROMOTIONAL - EDR Count (Daily)', 'ST_VOICE_PROMOTIONAL - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102132, 'ST_VOICE_PROMOTIONAL - EDR Duration', 'ST_VOICE_PROMOTIONAL - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102133, 'ST_VOICE_PROMOTIONAL - EDR Duration (Daily)', 'ST_VOICE_PROMOTIONAL - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102134, 'ST_VOICE_PROMOTIONAL - EDR Value', 'ST_VOICE_PROMOTIONAL - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102135, 'ST_VOICE_PROMOTIONAL - EDR Value (Daily)', 'ST_VOICE_PROMOTIONAL - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102136, 'ST_VOICE_SUSPENSE - EDR Count', 'ST_VOICE_SUSPENSE - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102137, 'ST_VOICE_SUSPENSE - EDR Count (Daily)', 'ST_VOICE_SUSPENSE - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102138, 'ST_VOICE_SUSPENSE - EDR Duration', 'ST_VOICE_SUSPENSE - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102139, 'ST_VOICE_SUSPENSE - EDR Duration (Daily)', 'ST_VOICE_SUSPENSE - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102140, 'ST_VOICE_VOIP - EDR Count', 'ST_VOICE_VOIP - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102141, 'ST_VOICE_VOIP - EDR Count (Daily)', 'ST_VOICE_VOIP - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102142, 'ST_VOICE_VOIP - EDR Duration', 'ST_VOICE_VOIP - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102143, 'ST_VOICE_VOIP - EDR Duration (Daily)', 'ST_VOICE_VOIP - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102144, 'ST_VOICE_VOIP - EDR Value', 'ST_VOICE_VOIP - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102145, 'ST_VOICE_VOIP - EDR Value (Daily)', 'ST_VOICE_VOIP - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102146, 'ST_DATA_PARTNERS - EDR Count (Daily) (Absolute)', 'ST_DATA_PARTNERS - EDR Count (Daily) (Absolute)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102147, 'ST_VOICE_PARTNERS - EDR Count (Daily) (Absolute)', 'ST_VOICE_PARTNERS - EDR Count (Daily) (Absolute)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102331, 'ST_DATA_IN_BUNDLE - EDR Bytes', 'ST_DATA_IN_BUNDLE - EDR Bytes', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102332, 'ST_DATA_IN_BUNDLE - EDR Bytes (Daily)', 'ST_DATA_IN_BUNDLE - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102333, 'ST_DATA_IN_BUNDLE - EDR Count', 'ST_DATA_IN_BUNDLE - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102334, 'ST_DATA_IN_BUNDLE - EDR Count (Daily)', 'ST_DATA_IN_BUNDLE - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102335, 'ST_DATA_IN_BUNDLE - EDR Value', 'ST_DATA_IN_BUNDLE - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102336, 'ST_DATA_IN_BUNDLE - EDR Value (Daily)', 'ST_DATA_IN_BUNDLE - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102337, 'ST_DATA_OUT_BUNDLE - EDR Bytes', 'ST_DATA_OUT_BUNDLE - EDR Bytes', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102338, 'ST_DATA_OUT_BUNDLE - EDR Bytes (Daily)', 'ST_DATA_OUT_BUNDLE - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102339, 'ST_DATA_OUT_BUNDLE - EDR Count', 'ST_DATA_OUT_BUNDLE - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102340, 'ST_DATA_OUT_BUNDLE - EDR Count (Daily)', 'ST_DATA_OUT_BUNDLE - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102341, 'ST_DATA_OUT_BUNDLE - EDR Value', 'ST_DATA_OUT_BUNDLE - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102342, 'ST_DATA_OUT_BUNDLE - EDR Value (Daily)', 'ST_DATA_OUT_BUNDLE - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102343, 'ST_MMS_IN_BUNDLE - EDR Bytes', 'ST_MMS_IN_BUNDLE - EDR Bytes', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102344, 'ST_MMS_IN_BUNDLE - EDR Bytes (Daily)', 'ST_MMS_IN_BUNDLE - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102345, 'ST_MMS_IN_BUNDLE - EDR Count', 'ST_MMS_IN_BUNDLE - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102346, 'ST_MMS_IN_BUNDLE - EDR Count (Daily)', 'ST_MMS_IN_BUNDLE - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102347, 'ST_MMS_IN_BUNDLE - EDR Value', 'ST_MMS_IN_BUNDLE - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102348, 'ST_MMS_IN_BUNDLE - EDR Value (Daily) ', 'ST_MMS_IN_BUNDLE - EDR Value (Daily) ', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102349, 'ST_MMS_OUT_BUNDLE - EDR Bytes', 'ST_MMS_OUT_BUNDLE - EDR Bytes', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102350, 'ST_MMS_OUT_BUNDLE - EDR Bytes (Daily)', 'ST_MMS_OUT_BUNDLE - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102351, 'ST_MMS_OUT_BUNDLE - EDR Count', 'ST_MMS_OUT_BUNDLE - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102352, 'ST_MMS_OUT_BUNDLE - EDR Count (Daily)', 'ST_MMS_OUT_BUNDLE - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102353, 'ST_MMS_OUT_BUNDLE - EDR Value', 'ST_MMS_OUT_BUNDLE - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102354, 'ST_MMS_OUT_BUNDLE - EDR Value (Daily)', 'ST_MMS_OUT_BUNDLE - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102355, 'ST_SMS_IN_BUNDLE - EDR Count', 'ST_SMS_IN_BUNDLE - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102356, 'ST_SMS_IN_BUNDLE - EDR Count (Daily)', 'ST_SMS_IN_BUNDLE - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102357, 'ST_SMS_IN_BUNDLE - EDR Value', 'ST_SMS_IN_BUNDLE - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102358, 'ST_SMS_IN_BUNDLE - EDR Value (Daily)', 'ST_SMS_IN_BUNDLE - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102359, 'ST_SMS_OUT_BUNDLE - EDR Count', 'ST_SMS_OUT_BUNDLE - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102360, 'ST_SMS_OUT_BUNDLE - EDR Count (Daily)', 'ST_SMS_OUT_BUNDLE - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102361, 'ST_SMS_OUT_BUNDLE - EDR Value', 'ST_SMS_OUT_BUNDLE - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102362, 'ST_SMS_OUT_BUNDLE - EDR Value (Daily)', 'ST_SMS_OUT_BUNDLE - EDR Value (Daily)', 7, 100000, 100000);




insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102001, 102001, null, 'ST_DATA_PARTNERS - EDR Bytes', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102002, 102002, null, 'ST_DATA_PARTNERS - EDR Bytes (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102003, 102003, null, 'ST_DATA_PARTNERS - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102004, 102004, null, 'ST_DATA_PARTNERS - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102005, 102005, null, 'ST_DISCARDED - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102006, 102006, null, 'ST_DISCARDED - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102007, 102007, null, 'ST_SMS - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102008, 102008, null, 'ST_SMS - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102009, 102009, null, 'ST_SUSPENSE - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102010, 102010, null, 'ST_SUSPENSE - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102011, 102011, null, 'ST_VOICE - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102012, 102012, null, 'ST_VOICE - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102013, 102013, null, 'ST_VOICE - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102014, 102014, null, 'ST_VOICE_AGED - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102015, 102015, null, 'ST_VOICE_AGED - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102016, 102016, null, 'ST_VOICE_ANCILIARY - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102017, 102017, null, 'ST_VOICE_ANCILIARY - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102018, 102018, null, 'ST_VOICE_ANCILIARY - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102019, 102019, null, 'ST_VOICE_ANCILIARY - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102020, 102020, null, 'ST_VOICE_ANCILIARY - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102021, 102021, null, 'ST_VOICE_ANCILIARY - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102028, 102028, null, 'ST_VOICE_DISCARDED - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102029, 102029, null, 'ST_VOICE_DISCARDED - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102030, 102030, null, 'ST_VOICE_DOM - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102031, 102031, null, 'ST_VOICE_DOM - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102032, 102032, null, 'ST_VOICE_DOM - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102033, 102033, null, 'ST_VOICE_DOM - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102034, 102034, null, 'ST_VOICE_DOM - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102035, 102035, null, 'ST_VOICE_DOM - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102036, 102036, null, 'ST_VOICE_DQ - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102037, 102037, null, 'ST_VOICE_DQ - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102038, 102038, null, 'ST_VOICE_DQ - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102039, 102039, null, 'ST_VOICE_DQ - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102040, 102040, null, 'ST_VOICE_DQ - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102041, 102041, null, 'ST_VOICE_DQ - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102042, 102042, null, 'ST_VOICE_EXPIRING - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102043, 102043, null, 'ST_VOICE_EXPIRING - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102044, 102044, null, 'ST_VOICE_FO - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102045, 102045, null, 'ST_VOICE_FO - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102046, 102046, null, 'ST_VOICE_FO - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102047, 102047, null, 'ST_VOICE_FO - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102048, 102048, null, 'ST_VOICE_FO - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102049, 102049, null, 'ST_VOICE_FO - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102050, 102050, null, 'ST_VOICE_FT - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102051, 102051, null, 'ST_VOICE_FT - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102052, 102052, null, 'ST_VOICE_FT - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102053, 102053, null, 'ST_VOICE_FT - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102054, 102054, null, 'ST_VOICE_FT - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102055, 102055, null, 'ST_VOICE_FT - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102056, 102056, null, 'ST_VOICE_INBOUND - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102057, 102057, null, 'ST_VOICE_INBOUND - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102058, 102058, null, 'ST_VOICE_INBOUND - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102059, 102059, null, 'ST_VOICE_INBOUND - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102060, 102060, null, 'ST_VOICE_INBOUND - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102061, 102061, null, 'ST_VOICE_INBOUND - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102062, 102062, null, 'ST_VOICE_INTERNET - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102063, 102063, null, 'ST_VOICE_INTERNET - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102064, 102064, null, 'ST_VOICE_INTERNET - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102065, 102065, null, 'ST_VOICE_INTERNET - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102066, 102066, null, 'ST_VOICE_INTERNET - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102067, 102067, null, 'ST_VOICE_INTERNET - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102068, 102068, null, 'ST_VOICE_INTL - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102069, 102069, null, 'ST_VOICE_INTL - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102070, 102070, null, 'ST_VOICE_INTL - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102071, 102071, null, 'ST_VOICE_INTL - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102072, 102072, null, 'ST_VOICE_INTL - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102073, 102073, null, 'ST_VOICE_INTL - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102074, 102074, null, 'ST_VOICE_INTL_FREE - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102075, 102075, null, 'ST_VOICE_INTL_FREE - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102076, 102076, null, 'ST_VOICE_INTL_FREE - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102077, 102077, null, 'ST_VOICE_INTL_FREE - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102078, 102078, null, 'ST_VOICE_IN_BUNDLE - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102079, 102079, null, 'ST_VOICE_IN_BUNDLE - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102080, 102080, null, 'ST_VOICE_IN_BUNDLE - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102081, 102081, null, 'ST_VOICE_IN_BUNDLE - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102082, 102082, null, 'ST_VOICE_IN_BUNDLE - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102083, 102083, null, 'ST_VOICE_IN_BUNDLE - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102084, 102084, null, 'ST_VOICE_LOW_CALL - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102085, 102085, null, 'ST_VOICE_LOW_CALL - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102086, 102086, null, 'ST_VOICE_LOW_CALL - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102087, 102087, null, 'ST_VOICE_LOW_CALL - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102088, 102088, null, 'ST_VOICE_LOW_CALL - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102089, 102089, null, 'ST_VOICE_LOW_CALL - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102090, 102090, null, 'ST_VOICE_MT - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102091, 102091, null, 'ST_VOICE_MT - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102092, 102092, null, 'ST_VOICE_MT - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102093, 102093, null, 'ST_VOICE_MT - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102094, 102094, null, 'ST_VOICE_MT - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102095, 102095, null, 'ST_VOICE_MT - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102096, 102096, null, 'ST_VOICE_MT_INTL - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102097, 102097, null, 'ST_VOICE_MT_INTL - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102098, 102098, null, 'ST_VOICE_MT_INTL - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102099, 102099, null, 'ST_VOICE_MT_INTL - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102100, 102100, null, 'ST_VOICE_MT_INTL - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102101, 102101, null, 'ST_VOICE_MT_INTL - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102102, 102102, null, 'ST_VOICE_NGN - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102103, 102103, null, 'ST_VOICE_NGN - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102104, 102104, null, 'ST_VOICE_NGN - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102105, 102105, null, 'ST_VOICE_NGN - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102106, 102106, null, 'ST_VOICE_NGN - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102107, 102107, null, 'ST_VOICE_NGN - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102108, 102108, null, 'ST_VOICE_OUT_BUNDLE - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102109, 102109, null, 'ST_VOICE_OUT_BUNDLE - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102110, 102110, null, 'ST_VOICE_OUT_BUNDLE - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102111, 102111, null, 'ST_VOICE_OUT_BUNDLE - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102112, 102112, null, 'ST_VOICE_OUT_BUNDLE - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102113, 102113, null, 'ST_VOICE_OUT_BUNDLE - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102114, 102114, null, 'ST_VOICE_PARTNERS - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102115, 102115, null, 'ST_VOICE_PARTNERS - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102116, 102116, null, 'ST_VOICE_PARTNERS - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102117, 102117, null, 'ST_VOICE_PARTNERS - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102118, 102118, null, 'ST_VOICE_PREMIUM - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102119, 102119, null, 'ST_VOICE_PREMIUM - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102120, 102120, null, 'ST_VOICE_PREMIUM - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102121, 102121, null, 'ST_VOICE_PREMIUM - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102122, 102122, null, 'ST_VOICE_PREMIUM - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102123, 102123, null, 'ST_VOICE_PREMIUM - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102124, 102124, null, 'ST_VOICE_PREMIUM_INTL - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102125, 102125, null, 'ST_VOICE_PREMIUM_INTL - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102126, 102126, null, 'ST_VOICE_PREMIUM_INTL - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102127, 102127, null, 'ST_VOICE_PREMIUM_INTL - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102128, 102128, null, 'ST_VOICE_PREMIUM_INTL - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102129, 102129, null, 'ST_VOICE_PREMIUM_INTL - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102130, 102130, null, 'ST_VOICE_PROMOTIONAL - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102131, 102131, null, 'ST_VOICE_PROMOTIONAL - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102132, 102132, null, 'ST_VOICE_PROMOTIONAL - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102133, 102133, null, 'ST_VOICE_PROMOTIONAL - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102134, 102134, null, 'ST_VOICE_PROMOTIONAL - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102135, 102135, null, 'ST_VOICE_PROMOTIONAL - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102136, 102136, null, 'ST_VOICE_SUSPENSE - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102137, 102137, null, 'ST_VOICE_SUSPENSE - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102138, 102138, null, 'ST_VOICE_SUSPENSE - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102139, 102139, null, 'ST_VOICE_SUSPENSE - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102140, 102140, null, 'ST_VOICE_VOIP - EDR Count', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102141, 102141, null, 'ST_VOICE_VOIP - EDR Count (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102142, 102142, null, 'ST_VOICE_VOIP - EDR Duration', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102143, 102143, null, 'ST_VOICE_VOIP - EDR Duration (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102144, 102144, null, 'ST_VOICE_VOIP - EDR Value', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102145, 102145, null, 'ST_VOICE_VOIP - EDR Value (Daily)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102146, 102146, null, 'ST_DATA_PARTNERS - EDR Count (Daily) (Absolute)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102147, 102147, null, 'ST_VOICE_PARTNERS - EDR Count (Daily) (Absolute)', to_date('02-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102331, 102331, null, 'ST_DATA_IN_BUNDLE - EDR Bytes', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102332, 102332, null, 'ST_DATA_IN_BUNDLE - EDR Bytes (Daily)', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102333, 102333, null, 'ST_DATA_IN_BUNDLE - EDR Count', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102334, 102334, null, 'ST_DATA_IN_BUNDLE - EDR Count (Daily)', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102335, 102335, null, 'ST_DATA_IN_BUNDLE - EDR Value', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102336, 102336, null, 'ST_DATA_IN_BUNDLE - EDR Value (Daily)', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102337, 102337, null, 'ST_DATA_OUT_BUNDLE - EDR Bytes', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102338, 102338, null, 'ST_DATA_OUT_BUNDLE - EDR Bytes (Daily)', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102339, 102339, null, 'ST_DATA_OUT_BUNDLE - EDR Count', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102340, 102340, null, 'ST_DATA_OUT_BUNDLE - EDR Count (Daily)', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102341, 102341, null, 'ST_DATA_OUT_BUNDLE - EDR Value', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102342, 102342, null, 'ST_DATA_OUT_BUNDLE - EDR Value (Daily)', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102343, 102343, null, 'ST_MMS_IN_BUNDLE - EDR Bytes', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102344, 102344, null, 'ST_MMS_IN_BUNDLE - EDR Bytes (Daily)', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102345, 102345, null, 'ST_MMS_IN_BUNDLE - EDR Count', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102346, 102346, null, 'ST_MMS_IN_BUNDLE - EDR Count (Daily)', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102347, 102347, null, 'ST_MMS_IN_BUNDLE - EDR Value', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102348, 102348, null, 'ST_MMS_IN_BUNDLE - EDR Value (Daily) ', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102349, 102349, null, 'ST_MMS_OUT_BUNDLE - EDR Bytes', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102350, 102350, null, 'ST_MMS_OUT_BUNDLE - EDR Bytes (Daily)', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102351, 102351, null, 'ST_MMS_OUT_BUNDLE - EDR Count', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102352, 102352, null, 'ST_MMS_OUT_BUNDLE - EDR Count (Daily)', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102353, 102353, null, 'ST_MMS_OUT_BUNDLE - EDR Value', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102354, 102354, null, 'ST_MMS_OUT_BUNDLE - EDR Value (Daily)', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102355, 102355, null, 'ST_SMS_IN_BUNDLE - EDR Count', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102356, 102356, null, 'ST_SMS_IN_BUNDLE - EDR Count (Daily)', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102357, 102357, null, 'ST_SMS_IN_BUNDLE - EDR Value', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102358, 102358, null, 'ST_SMS_IN_BUNDLE - EDR Value (Daily)', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102359, 102359, null, 'ST_SMS_OUT_BUNDLE - EDR Count', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102360, 102360, null, 'ST_SMS_OUT_BUNDLE - EDR Count (Daily)', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102361, 102361, null, 'ST_SMS_OUT_BUNDLE - EDR Value', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102362, 102362, null, 'ST_SMS_OUT_BUNDLE - EDR Value (Daily)', to_date('13-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');




insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102001, 100001, 102001);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102002, 100001, 102002);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102003, 100001, 102003);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102004, 100001, 102004);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102005, 100001, 102005);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102006, 100001, 102006);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102007, 100001, 102007);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102008, 100001, 102008);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102009, 100001, 102009);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102010, 100001, 102010);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102011, 100001, 102011);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102012, 100001, 102012);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102013, 100001, 102013);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102014, 100001, 102014);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102015, 100001, 102015);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102016, 100001, 102016);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102017, 100001, 102017);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102018, 100001, 102018);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102019, 100001, 102019);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102020, 100001, 102020);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102021, 100001, 102021);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102028, 100001, 102028);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102029, 100001, 102029);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102030, 100001, 102030);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102031, 100001, 102031);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102032, 100001, 102032);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102033, 100001, 102033);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102034, 100001, 102034);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102035, 100001, 102035);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102036, 100001, 102036);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102037, 100001, 102037);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102038, 100001, 102038);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102039, 100001, 102039);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102040, 100001, 102040);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102041, 100001, 102041);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102042, 100001, 102042);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102043, 100001, 102043);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102044, 100001, 102044);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102045, 100001, 102045);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102046, 100001, 102046);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102047, 100001, 102047);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102048, 100001, 102048);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102049, 100001, 102049);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102050, 100001, 102050);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102051, 100001, 102051);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102052, 100001, 102052);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102053, 100001, 102053);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102054, 100001, 102054);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102055, 100001, 102055);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102056, 100001, 102056);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102057, 100001, 102057);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102058, 100001, 102058);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102059, 100001, 102059);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102060, 100001, 102060);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102061, 100001, 102061);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102062, 100001, 102062);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102063, 100001, 102063);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102064, 100001, 102064);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102065, 100001, 102065);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102066, 100001, 102066);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102067, 100001, 102067);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102068, 100001, 102068);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102069, 100001, 102069);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102070, 100001, 102070);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102071, 100001, 102071);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102072, 100001, 102072);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102073, 100001, 102073);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102074, 100001, 102074);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102075, 100001, 102075);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102076, 100001, 102076);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102077, 100001, 102077);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102078, 100001, 102078);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102079, 100001, 102079);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102080, 100001, 102080);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102081, 100001, 102081);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102082, 100001, 102082);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102083, 100001, 102083);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102084, 100001, 102084);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102085, 100001, 102085);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102086, 100001, 102086);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102087, 100001, 102087);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102088, 100001, 102088);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102089, 100001, 102089);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102090, 100001, 102090);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102091, 100001, 102091);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102092, 100001, 102092);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102093, 100001, 102093);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102094, 100001, 102094);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102095, 100001, 102095);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102096, 100001, 102096);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102097, 100001, 102097);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102098, 100001, 102098);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102099, 100001, 102099);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102100, 100001, 102100);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102101, 100001, 102101);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102102, 100001, 102102);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102103, 100001, 102103);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102104, 100001, 102104);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102105, 100001, 102105);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102106, 100001, 102106);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102107, 100001, 102107);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102108, 100001, 102108);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102109, 100001, 102109);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102110, 100001, 102110);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102111, 100001, 102111);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102112, 100001, 102112);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102113, 100001, 102113);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102114, 100001, 102114);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102115, 100001, 102115);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102116, 100001, 102116);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102117, 100001, 102117);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102118, 100001, 102118);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102119, 100001, 102119);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102120, 100001, 102120);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102121, 100001, 102121);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102122, 100001, 102122);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102123, 100001, 102123);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102124, 100001, 102124);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102125, 100001, 102125);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102126, 100001, 102126);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102127, 100001, 102127);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102128, 100001, 102128);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102129, 100001, 102129);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102130, 100001, 102130);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102131, 100001, 102131);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102132, 100001, 102132);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102133, 100001, 102133);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102134, 100001, 102134);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102135, 100001, 102135);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102136, 100001, 102136);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102137, 100001, 102137);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102138, 100001, 102138);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102139, 100001, 102139);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102140, 100001, 102140);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102141, 100001, 102141);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102142, 100001, 102142);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102143, 100001, 102143);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102144, 100001, 102144);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102145, 100001, 102145);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102331, 100001, 102331);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102332, 100001, 102332);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102333, 100001, 102333);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102334, 100001, 102334);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102335, 100001, 102335);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102336, 100001, 102336);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102337, 100001, 102337);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102338, 100001, 102338);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102339, 100001, 102339);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102340, 100001, 102340);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102341, 100001, 102341);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102342, 100001, 102342);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102343, 100001, 102343);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102344, 100001, 102344);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102345, 100001, 102345);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102346, 100001, 102346);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102347, 100001, 102347);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102348, 100001, 102348);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102349, 100001, 102349);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102350, 100001, 102350);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102351, 100001, 102351);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102352, 100001, 102352);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102353, 100001, 102353);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102354, 100001, 102354);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102355, 100001, 102355);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102356, 100001, 102356);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102357, 100001, 102357);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102358, 100001, 102358);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102359, 100001, 102359);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102360, 100001, 102360);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102361, 100001, 102361);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102362, 100001, 102362);





insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102001, 102001, 10, 35127, 102001, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_PARTNERS - EDR Bytes');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102002, 102002, 10, 35127, 102002, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_PARTNERS - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102003, 102003, 13, 35127, 102003, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_PARTNERS - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102004, 102004, 13, 35127, 102004, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_PARTNERS - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102005, 102005, 13, 35127, 102005, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DISCARDED - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102006, 102006, 13, 35127, 102006, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DISCARDED - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102007, 102007, 13, 35127, 102007, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_SMS - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102008, 102008, 3, 35127, 102008, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_SMS - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102009, 102009, 13, 35127, 102009, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_SUSPENSE - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102010, 102010, 13, 35127, 102010, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_SUSPENSE - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102011, 102011, 13, 35127, 102011, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102012, 102012, 4, 35127, 102012, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102013, 102013, 3, 35127, 102013, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102014, 102014, 13, 35127, 102014, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_AGED - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102015, 102015, 13, 35127, 102015, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_AGED - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102016, 102016, 13, 35127, 102016, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_ANCILIARY - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102017, 102017, 13, 35127, 102017, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_ANCILIARY - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102018, 102018, 4, 35127, 102018, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_ANCILIARY - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102019, 102019, 4, 35127, 102019, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_ANCILIARY - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102020, 102020, 3, 35127, 102020, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_ANCILIARY - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102021, 102021, 3, 35127, 102021, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_ANCILIARY - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102028, 102028, 13, 35127, 102028, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DISCARDED - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102029, 102029, 13, 35127, 102029, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DISCARDED - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102030, 102030, 13, 35127, 102030, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DOM - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102031, 102031, 13, 35127, 102031, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DOM - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102032, 102032, 4, 35127, 102032, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DOM - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102033, 102033, 4, 35127, 102033, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DOM - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102034, 102034, 3, 35127, 102034, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DOM - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102035, 102035, 3, 35127, 102035, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DOM - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102036, 102036, 13, 35127, 102036, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DQ - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102037, 102037, 13, 35127, 102037, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DQ - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102038, 102038, 4, 35127, 102038, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DQ - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102039, 102039, 4, 35127, 102039, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DQ - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102040, 102040, 3, 35127, 102040, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DQ - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102041, 102041, 3, 35127, 102041, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DQ - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102042, 102042, 13, 35127, 102042, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_EXPIRING - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102043, 102043, 13, 35127, 102043, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_EXPIRING - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102044, 102044, 13, 35127, 102044, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_FO - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102045, 102045, 13, 35127, 102045, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_FO - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102046, 102046, 4, 35127, 102046, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_FO - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102047, 102047, 4, 35127, 102047, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_FO - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102048, 102048, 3, 35127, 102048, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_FO - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102049, 102049, 3, 35127, 102049, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_FO - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102050, 102050, 13, 35127, 102050, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_FT - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102051, 102051, 13, 35127, 102051, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_FT - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102052, 102052, 4, 35127, 102052, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_FT - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102053, 102053, 4, 35127, 102053, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_FT - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102054, 102054, 3, 35127, 102054, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_FT - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102055, 102055, 3, 35127, 102055, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_FT - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102056, 102056, 13, 35127, 102056, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INBOUND - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102057, 102057, 13, 35127, 102057, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INBOUND - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102058, 102058, 4, 35127, 102058, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INBOUND - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102059, 102059, 4, 35127, 102059, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INBOUND - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102060, 102060, 3, 35127, 102060, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INBOUND - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102061, 102061, 3, 35127, 102061, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INBOUND - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102062, 102062, 13, 35127, 102062, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTERNET - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102063, 102063, 13, 35127, 102063, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTERNET - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102064, 102064, 4, 35127, 102064, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTERNET - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102065, 102065, 4, 35127, 102065, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTERNET - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102066, 102066, 3, 35127, 102066, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTERNET - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102067, 102067, 3, 35127, 102067, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTERNET - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102068, 102068, 13, 35127, 102068, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTL - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102069, 102069, 13, 35127, 102069, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTL - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102070, 102070, 4, 35127, 102070, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTL - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102071, 102071, 4, 35127, 102071, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTL - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102072, 102072, 3, 35127, 102072, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTL - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102073, 102073, 3, 35127, 102073, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTL - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102074, 102074, 13, 35127, 102074, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTL_FREE - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102075, 102075, 13, 35127, 102075, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTL_FREE - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102076, 102076, 4, 35127, 102076, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTL_FREE - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102077, 102077, 4, 35127, 102077, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTL_FREE - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102078, 102078, 13, 35127, 102078, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_IN_BUNDLE - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102079, 102079, 13, 35127, 102079, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_IN_BUNDLE - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102080, 102080, 4, 35127, 102080, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_IN_BUNDLE - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102081, 102081, 4, 35127, 102081, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_IN_BUNDLE - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102082, 102082, 3, 35127, 102082, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_IN_BUNDLE - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102083, 102083, 3, 35127, 102083, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_IN_BUNDLE - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102084, 102084, 13, 35127, 102084, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_LOW_CALL - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102085, 102085, 13, 35127, 102085, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_LOW_CALL - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102086, 102086, 4, 35127, 102086, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_LOW_CALL - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102087, 102087, 4, 35127, 102087, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_LOW_CALL - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102088, 102088, 3, 35127, 102088, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_LOW_CALL - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102089, 102089, 3, 35127, 102089, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_LOW_CALL - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102090, 102090, 13, 35127, 102090, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_MT - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102091, 102091, 13, 35127, 102091, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_MT - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102092, 102092, 4, 35127, 102092, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_MT - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102093, 102093, 4, 35127, 102093, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_MT - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102094, 102094, 3, 35127, 102094, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_MT - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102095, 102095, 3, 35127, 102095, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_MT - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102096, 102096, 13, 35127, 102096, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_MT_INTL - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102097, 102097, 13, 35127, 102097, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_MT_INTL - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102098, 102098, 4, 35127, 102098, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_MT_INTL - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102099, 102099, 4, 35127, 102099, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_MT_INTL - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102100, 102100, 3, 35127, 102100, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_MT_INTL - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102101, 102101, 3, 35127, 102101, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_MT_INTL - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102102, 102102, 13, 35127, 102102, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_NGN - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102103, 102103, 13, 35127, 102103, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_NGN - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102104, 102104, 4, 35127, 102104, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_NGN - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102105, 102105, 4, 35127, 102105, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_NGN - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102106, 102106, 3, 35127, 102106, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_NGN - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102107, 102107, 3, 35127, 102107, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_NGN - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102108, 102108, 13, 35127, 102108, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_OUT_BUNDLE - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102109, 102109, 13, 35127, 102109, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_OUT_BUNDLE - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102110, 102110, 4, 35127, 102110, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_OUT_BUNDLE - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102111, 102111, 4, 35127, 102111, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_OUT_BUNDLE - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102112, 102112, 3, 35127, 102112, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_OUT_BUNDLE - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102113, 102113, 3, 35127, 102113, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_OUT_BUNDLE - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102114, 102114, 13, 35127, 102114, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PARTNERS - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102115, 102115, 13, 35127, 102115, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PARTNERS - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102116, 102116, 4, 35127, 102116, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PARTNERS - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102117, 102117, 4, 35127, 102117, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PARTNERS - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102118, 102118, 13, 35127, 102118, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PREMIUM - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102119, 102119, 13, 35127, 102119, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PREMIUM - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102120, 102120, 4, 35127, 102120, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PREMIUM - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102121, 102121, 4, 35127, 102121, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PREMIUM - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102122, 102122, 3, 35127, 102122, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PREMIUM - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102123, 102123, 3, 35127, 102123, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PREMIUM - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102124, 102124, 13, 35127, 102124, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PREMIUM_INTL - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102125, 102125, 13, 35127, 102125, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PREMIUM_INTL - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102126, 102126, 4, 35127, 102126, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PREMIUM_INTL - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102127, 102127, 4, 35127, 102127, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PREMIUM_INTL - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102128, 102128, 3, 35127, 102128, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PREMIUM_INTL - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102129, 102129, 3, 35127, 102129, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PREMIUM_INTL - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102130, 102130, 13, 35127, 102130, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PROMOTIONAL - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102131, 102131, 13, 35127, 102131, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PROMOTIONAL - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102132, 102132, 4, 35127, 102132, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PROMOTIONAL - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102133, 102133, 4, 35127, 102133, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PROMOTIONAL - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102134, 102134, 3, 35127, 102134, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PROMOTIONAL - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102135, 102135, 3, 35127, 102135, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PROMOTIONAL - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102136, 102136, 13, 35127, 102136, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_SUSPENSE - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102137, 102137, 13, 35127, 102137, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_SUSPENSE - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102138, 102138, 4, 35127, 102138, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_SUSPENSE - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102139, 102139, 4, 35127, 102139, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_SUSPENSE - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102140, 102140, 13, 35127, 102140, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_VOIP - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102141, 102141, 13, 35127, 102141, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_VOIP - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102142, 102142, 4, 35127, 102142, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_VOIP - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102143, 102143, 4, 35127, 102143, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_VOIP - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102144, 102144, 3, 35127, 102144, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_VOIP - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102145, 102145, 3, 35127, 102145, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_VOIP - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102146, 102146, 13, 35123, null, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_PARTNERS - EDR Count (Daily) (Absolute)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102147, 102147, 13, 35123, null, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PARTNERS - EDR Count (Daily) (Absolute)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102331, 102331, 10, 35127, 102331, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_IN_BUNDLE - EDR Bytes');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102332, 102332, 10, 35127, 102332, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_IN_BUNDLE - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102333, 102333, 13, 35127, 102333, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_IN_BUNDLE - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102334, 102334, 13, 35127, 102334, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_IN_BUNDLE - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102335, 102335, 3, 35127, 102335, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_IN_BUNDLE - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102336, 102336, 3, 35127, 102336, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_IN_BUNDLE - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102337, 102337, 10, 35127, 102337, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_OUT_BUNDLE - EDR Bytes');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102338, 102338, 10, 35127, 102338, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_OUT_BUNDLE - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102339, 102339, 13, 35127, 102339, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_OUT_BUNDLE - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102340, 102340, 13, 35127, 102340, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_OUT_BUNDLE - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102341, 102341, 3, 35127, 102341, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_OUT_BUNDLE - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102342, 102342, 3, 35127, 102342, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_OUT_BUNDLE - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102343, 102343, 10, 35127, 102343, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_MMS_IN_BUNDLE - EDR Bytes');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102344, 102344, 10, 35127, 102344, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_MMS_IN_BUNDLE - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102345, 102345, 13, 35127, 102345, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_MMS_IN_BUNDLE - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102346, 102346, 13, 35127, 102346, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_MMS_IN_BUNDLE - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102347, 102347, 3, 35127, 102347, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_MMS_IN_BUNDLE - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102348, 102348, 3, 35127, 102348, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_MMS_IN_BUNDLE - EDR Value (Daily) ');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102349, 102349, 10, 35127, 102349, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_MMS_OUT_BUNDLE - EDR Bytes');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102350, 102350, 10, 35127, 102350, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_MMS_OUT_BUNDLE - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102351, 102351, 13, 35127, 102351, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_MMS_OUT_BUNDLE - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102352, 102352, 13, 35127, 102352, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_MMS_OUT_BUNDLE - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102353, 102353, 3, 35127, 102353, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_MMS_OUT_BUNDLE - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102354, 102354, 3, 35127, 102354, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_MMS_OUT_BUNDLE - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102355, 102355, 13, 35127, 102355, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_SMS_IN_BUNDLE - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102356, 102356, 13, 35127, 102356, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_SMS_IN_BUNDLE - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102357, 102357, 3, 35127, 102357, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_SMS_IN_BUNDLE - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102358, 102358, 3, 35127, 102358, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_SMS_IN_BUNDLE - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102359, 102359, 13, 35127, 102359, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_SMS_OUT_BUNDLE - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102360, 102360, 13, 35127, 102360, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_SMS_OUT_BUNDLE - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102361, 102361, 3, 35127, 102361, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_SMS_OUT_BUNDLE - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102362, 102362, 3, 35127, 102362, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_SMS_OUT_BUNDLE - EDR Value (Daily)');




insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102001, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100171', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102002, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100171', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102003, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100171', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102004, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100171', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102005, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100196', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102006, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100196', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102007, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100013', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102008, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100013', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102009, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100191', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102010, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100191', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102011, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100001', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102012, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100001', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102013, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100001', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102014, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100193', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102015, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100193', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102016, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100189', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102017, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100189', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102018, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100189', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102019, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100189', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102020, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100189', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102021, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100189', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102028, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100195', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102029, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100195', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102030, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100177', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102031, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100177', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102032, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100177', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102033, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100177', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102034, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100177', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102035, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100177', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102036, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100185', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102037, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100185', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102038, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100185', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102039, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100185', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102040, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100185', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102041, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100185', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102042, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100194', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102043, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100194', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102044, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100174', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102045, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100174', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102046, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100174', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102047, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100174', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102048, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100174', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102049, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100174', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102050, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100175', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102051, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100175', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102052, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100175', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102053, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100175', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102054, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100175', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102055, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100175', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102056, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100190', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102057, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100190', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102058, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100190', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102059, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100190', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102060, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100190', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102061, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100190', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102062, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100183', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102063, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100183', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102064, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100183', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102065, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100183', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102066, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100183', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102067, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100183', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102068, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100176', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102069, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100176', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102070, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100176', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102071, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100176', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102072, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100176', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102073, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100176', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102074, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100180', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102075, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100180', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102076, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100180', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102077, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100180', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102078, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100172', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102079, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100172', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102080, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100172', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102081, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100172', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102082, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100172', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102083, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100172', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102084, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100186', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102085, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100186', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102086, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100186', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102087, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100186', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102088, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100186', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102089, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100186', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102090, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100178', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102091, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100178', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102092, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100178', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102093, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100178', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102094, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100178', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102095, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100178', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102096, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100179', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102097, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100179', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102098, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100179', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102099, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100179', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102100, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100179', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102101, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100179', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102102, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100187', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102103, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100187', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102104, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100187', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102105, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100187', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102106, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100187', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102107, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100187', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102108, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100173', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102109, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100173', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102110, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100173', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102111, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100173', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102112, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100173', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102113, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100173', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102114, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100170', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102115, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100170', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102116, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100170', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102117, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100170', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102118, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100181', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102119, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100181', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102120, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100181', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102121, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100181', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102122, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100181', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102123, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100181', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102124, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100182', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102125, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100182', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102126, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100182', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102127, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100182', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102128, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100182', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102129, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100182', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102130, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100188', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102131, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100188', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102132, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100188', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102133, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100188', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102134, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100188', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102135, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100188', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102136, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100192', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102137, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100192', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102138, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100192', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102139, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100192', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102140, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100184', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102141, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100184', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102142, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100184', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102143, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100184', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102144, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100184', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102145, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100184', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102146, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100171', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102147, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100170', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102331, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100199', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102332, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100199', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102333, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100199', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102334, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100199', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102335, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100199', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102336, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100199', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102337, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100200', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102338, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100200', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102339, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100200', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102340, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100200', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102341, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100200', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102342, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100200', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102343, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100201', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102344, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100201', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102345, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100201', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102346, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100201', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102347, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100201', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102348, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100201', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102349, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100202', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102350, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100202', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102351, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100202', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102352, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100202', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102353, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100202', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102354, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100202', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102355, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100197', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102356, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100197', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102357, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100197', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102358, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100197', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102359, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100198', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102360, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100198', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102361, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100198', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102362, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100198', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');





insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100102, 102114, 101054, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100102, 102115, 101053, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100102, 102116, 101056, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100102, 102117, 101055, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100105, 102001, 101334, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100105, 102002, 101333, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100105, 102003, 101336, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100105, 102004, 101335, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100105, 102114, 101338, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100105, 102115, 101337, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100105, 102116, 101340, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100105, 102117, 101339, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102146, 101503, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102147, 101504, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100141, 102146, 101501, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100142, 102147, 101502, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100144, 102146, 101505, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100152, 102001, 101058, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100152, 102002, 101057, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100152, 102003, 101060, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100152, 102004, 101059, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 100000, 101034, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 100006, null, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 100029, 101038, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 100032, 101035, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 100037, 101040, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 100102, 101036, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 100800, 101033, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 100801, 100433, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 100802, 100434, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 102011, 101037, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 102012, 101039, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 102030, 101042, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 102031, 101041, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 102032, 101044, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 102033, 101043, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 102044, 101046, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 102045, 101045, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 102046, 101048, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 102047, 101047, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 102068, 101050, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 102069, 101049, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 102070, 101052, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100170, 102071, 101051, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 100000, 101002, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 100006, null, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 100029, 101006, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 100032, 101003, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 100037, 101008, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 100102, 101004, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 100800, 101001, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 100801, 100433, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 100802, 100434, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 102011, 101005, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 102012, 101007, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 102030, 101010, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 102031, 101009, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 102032, 101012, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 102033, 101011, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 102044, 101014, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 102045, 101013, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 102046, 101016, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 102047, 101015, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 102068, 101018, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 102069, 101017, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 102070, 101020, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100171, 102071, 101019, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100172, 100000, 101022, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100172, 100006, null, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100172, 100029, 101026, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100172, 100032, 101023, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100172, 100037, 101028, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100172, 100102, 101024, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100172, 100800, 101021, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100172, 100801, 100433, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100172, 100802, 100434, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100172, 102011, 101025, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100172, 102012, 101027, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100172, 102050, 101030, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100172, 102051, 101029, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100172, 102052, 101032, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100172, 102053, 101031, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 100000, 101220, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 100001, 101224, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 100006, null, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 100029, 101228, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 100032, 101221, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 100037, 101230, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 100102, 101222, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 100103, 101226, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 100111, 101232, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 100800, 101219, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 100801, 100433, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 100802, 100434, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102007, 101223, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102008, 101225, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102011, 101227, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102012, 101229, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102013, 101231, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102016, 101234, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102017, 101233, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102018, 101236, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102019, 101235, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102020, 101238, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102021, 101237, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102030, 101240, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102031, 101239, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102032, 101242, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102033, 101241, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102034, 101244, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102035, 101243, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102036, 101246, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102037, 101245, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102038, 101248, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102039, 101247, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102040, 101250, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102041, 101249, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102044, 101252, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102045, 101251, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102046, 101254, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102047, 101253, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102048, 101256, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102049, 101255, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102050, 101258, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102051, 101257, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102052, 101260, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102053, 101259, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102054, 101262, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102055, 101261, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102056, 101264, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102057, 101263, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102058, 101266, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102059, 101265, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102060, 101268, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102061, 101267, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102062, 101270, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102063, 101269, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102064, 101272, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102065, 101271, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102066, 101274, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102067, 101273, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102068, 101276, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102069, 101275, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102070, 101278, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102071, 101277, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102072, 101280, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102073, 101279, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102074, 101282, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102075, 101281, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102076, 101284, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102077, 101283, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102084, 101286, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102085, 101285, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102086, 101288, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102087, 101287, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102088, 101290, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102089, 101289, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102090, 101292, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102091, 101291, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102092, 101294, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102093, 101293, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102094, 101296, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102095, 101295, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102096, 101298, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102097, 101297, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102098, 101300, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102099, 101299, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102100, 101302, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102101, 101301, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102102, 101304, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102103, 101303, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102104, 101306, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102105, 101305, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102106, 101308, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102107, 101307, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102118, 101310, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102119, 101309, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102120, 101312, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102121, 101311, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102122, 101314, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102123, 101313, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102124, 101316, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102125, 101315, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102126, 101318, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102127, 101317, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102128, 101320, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102129, 101319, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102130, 101322, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102131, 101321, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102132, 101324, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102133, 101323, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102134, 101326, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102135, 101325, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102140, 101328, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102141, 101327, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102142, 101330, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102143, 101329, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102144, 101332, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100173, 102145, 101331, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100174, 100000, 101188, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100174, 100006, null, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100174, 100032, 101189, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100174, 100102, 101190, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100174, 100800, 101187, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100174, 100801, 100433, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100174, 100802, 100434, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100174, 102005, 101192, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100174, 102006, 101191, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100174, 102028, 101194, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100174, 102029, 101193, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 100000, 101062, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 100001, 101066, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 100006, null, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 100029, 101070, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 100032, 101063, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 100037, 101072, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 100102, 101064, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 100103, 101068, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 100111, 101074, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 100800, 101061, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 100801, 100433, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 100802, 100434, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102007, 101065, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102008, 101067, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102011, 101069, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102012, 101071, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102013, 101073, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102016, 101076, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102017, 101075, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102018, 101078, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102019, 101077, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102020, 101080, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102021, 101079, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102030, 101082, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102031, 101081, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102032, 101084, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102033, 101083, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102034, 101086, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102035, 101085, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102036, 101088, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102037, 101087, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102038, 101090, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102039, 101089, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102040, 101092, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102041, 101091, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102044, 101094, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102045, 101093, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102046, 101096, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102047, 101095, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102048, 101098, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102049, 101097, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102050, 101100, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102051, 101099, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102052, 101102, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102053, 101101, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102054, 101104, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102055, 101103, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102056, 101106, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102057, 101105, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102058, 101108, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102059, 101107, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102060, 101110, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102061, 101109, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102062, 101112, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102063, 101111, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102064, 101114, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102065, 101113, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102066, 101116, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102067, 101115, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102068, 101118, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102069, 101117, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102070, 101120, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102071, 101119, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102072, 101122, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102073, 101121, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102074, 101124, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102075, 101123, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102076, 101126, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102077, 101125, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102078, 101128, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102079, 101127, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102080, 101130, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102081, 101129, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102082, 101132, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102083, 101131, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102084, 101134, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102085, 101133, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102086, 101136, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102087, 101135, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102088, 101138, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102089, 101137, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102090, 101140, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102091, 101139, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102092, 101142, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102093, 101141, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102094, 101144, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102095, 101143, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102096, 101146, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102097, 101145, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102098, 101148, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102099, 101147, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102100, 101150, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102101, 101149, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102102, 101152, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102103, 101151, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102104, 101154, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102105, 101153, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102106, 101156, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102107, 101155, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102108, 101158, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102109, 101157, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102110, 101160, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102111, 101159, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102112, 101162, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102113, 101161, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102118, 101164, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102119, 101163, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102120, 101166, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102121, 101165, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102122, 101168, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102123, 101167, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102124, 101170, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102125, 101169, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102126, 101172, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102127, 101171, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102128, 101174, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102129, 101173, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102130, 101176, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102131, 101175, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102132, 101178, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102133, 101177, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102134, 101180, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102135, 101179, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102140, 101182, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102141, 101181, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102142, 101184, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102143, 101183, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102144, 101186, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100175, 102145, 101185, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 100000, 101342, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 100006, null, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 100029, 101346, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 100032, 101343, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 100037, 101348, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 100102, 101344, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 100800, 101341, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 100801, 100433, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 100802, 100434, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 102011, 101345, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 102012, 101347, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 102030, 101350, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 102031, 101349, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 102032, 101352, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 102033, 101351, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 102044, 101354, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 102045, 101353, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 102046, 101356, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 102047, 101355, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 102068, 101358, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 102069, 101357, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 102070, 101360, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100176, 102071, 101359, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100177, 100000, 101210, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100177, 100006, null, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100177, 100032, 101211, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100177, 100102, 101212, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100177, 100800, 101209, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100177, 100801, 100433, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100177, 100802, 100434, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100177, 102009, 101214, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100177, 102010, 101213, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100177, 102136, 101216, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100177, 102137, 101215, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100177, 102138, 101218, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100177, 102139, 101217, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 100000, 101196, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 100006, null, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 100032, 101197, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 100102, 101198, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 100800, 101195, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 100801, 100433, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 100802, 100434, null, null, null, 100001, 'N', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 102009, 101200, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 102010, 101199, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 102014, 101202, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 102015, 101201, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 102042, 101204, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 102043, 101203, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 102136, 101206, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 102137, 101205, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 102138, 101208, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100178, 102139, 101207, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102331, 102202, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102332, 102201, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102333, 102204, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102334, 102203, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102335, 102206, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102336, 102205, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102337, 102208, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102338, 102207, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102339, 102210, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102340, 102209, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102341, 102212, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102342, 102211, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102343, 102214, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102344, 102213, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102345, 102216, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102346, 102215, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102347, 102218, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102348, 102217, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102349, 102220, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102350, 102219, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102351, 102222, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102352, 102221, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102353, 102224, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102354, 102223, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102355, 102226, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102356, 102225, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102357, 102228, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102358, 102227, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102359, 102230, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102360, 102229, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102361, 102232, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102362, 102231, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102078, 102233, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102079, 102234, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102080, 102235, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102081, 102236, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102082, 102237, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102083, 102238, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102108, 102239, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102109, 102240, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102110, 102241, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102111, 102242, null, null, null, 100000, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102112, 102243, null, null, null, 100001, 'Y', 'Y');

insert into um.node_metric_jn (NODE_ID, METRIC_DEFINITION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, SOURCE_ID, SOURCE_TYPE_ID, FILE_MATCH_DEFINITION_ID, IS_REGENERATE, IS_ACTIVE)
values (100120, 102113, 102244, null, null, null, 100000, 'Y', 'Y');





insert into um.mrec_category_ref (MREC_CATEGORY_ID, CATEGORY, DESCRIPTION)
values (100021, 'Fixed Line', 'Fixed Line');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100150, 100013, 'T', 100001, 'MSS vs TAPOUT (Count) - ST_VOICE_PARTNERS - EDR Count', 'MSS vs TAPOUT (Count) - ST_VOICE_PARTNERS - EDR Count');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100151, 100013, 'T', 100001, 'MSS vs TAPOUT (Count) - ST_VOICE_PARTNERS - EDR Count (Daily)', 'MSS vs TAPOUT (Count) - ST_VOICE_PARTNERS - EDR Count (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100152, 100017, 'T', 100001, 'SGSN vs TAPOUT (Count) - ST_DATA_PARTNERS - EDR Count', 'SGSN vs TAPOUT (Count) - ST_DATA_PARTNERS - EDR Count');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100153, 100017, 'T', 100001, 'SGSN vs TAPOUT (Count) - ST_DATA_PARTNERS - EDR Count (Daily)', 'SGSN vs TAPOUT (Count) - ST_DATA_PARTNERS - EDR Count (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100154, 100017, 'T', 100001, 'SGSN vs TAPOUT (Bytes) - ST_DATA_PARTNERS - EDR Bytes', 'SGSN vs TAPOUT (Bytes) - ST_DATA_PARTNERS - EDR Bytes');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100155, 100017, 'T', 100001, 'SGSN vs TAPOUT (Bytes) - ST_DATA_PARTNERS - EDR Bytes (Daily)', 'SGSN vs TAPOUT (Bytes) - ST_DATA_PARTNERS - EDR Bytes (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100156, 100021, 'T', 100001, 'SS Rated vs SS Billed (Count) - ST_VOICE - EDR Count', 'SS Rated vs SS Billed (Count) - ST_VOICE - EDR Count');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100157, 100021, 'T', 100001, 'SS Rated vs SS Billed (Count) - ST_VOICE - EDR Count (Daily)', 'SS Rated vs SS Billed (Count) - ST_VOICE - EDR Count (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100158, 100021, 'T', 100001, 'SS Rated vs SS Billed (Value) - ST_VOICE - EDR Value', 'SS Rated vs SS Billed (Value) - ST_VOICE - EDR Value');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100159, 100021, 'T', 100001, 'SS Rated vs SS Billed (Value) - ST_VOICE - EDR Value (Daily)', 'SS Rated vs SS Billed (Value) - ST_VOICE - EDR Value (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100160, 100021, 'T', 100001, 'EIRCOM vs SS Rated (count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count (Daily)', 'EIRCOM vs SS Rated (count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100161, 100021, 'T', 100001, 'BT vs SS Rated (count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count (Daily)', 'BT vs SS Rated (count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100162, 100021, 'T', 100001, 'C&W vs SS Rated (count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count (Daily)', 'C&W vs SS Rated (count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100163, 100021, 'T', 100001, 'VOIP vs SS Rated (count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count (Daily)', 'VOIP vs SS Rated (count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100164, 100021, 'T', 100001, 'EIRCOM vs SS Rated (Count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count', 'EIRCOM vs SS Rated (Count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100165, 100021, 'T', 100001, 'BT vs SS Rated (Count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count', 'BT vs SS Rated (Count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100166, 100021, 'T', 100001, 'C&W vs SS Rated (Count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count', 'C&W vs SS Rated (Count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100167, 100021, 'T', 100001, 'VOIP vs SS Rated (Count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count', 'VOIP vs SS Rated (Count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100168, 100021, 'T', 100001, 'EIRCOM vs SS Billed (count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count (Daily)', 'EIRCOM vs SS Billed (count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100169, 100021, 'T', 100001, 'BT vs SS Billed (count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count (Daily)', 'BT vs SS Billed (count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100170, 100021, 'T', 100001, 'C&W vs SS Billed (count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count (Daily)', 'C&W vs SS Billed (count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100171, 100021, 'T', 100001, 'VOIP vs SS Billed (count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count (Daily)', 'VOIP vs SS Billed (count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100172, 100021, 'T', 100001, 'EIRCOM vs SS Billed (Count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count', 'EIRCOM vs SS Billed (Count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100173, 100021, 'T', 100001, 'BT vs SS Billed (Count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count', 'BT vs SS Billed (Count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100174, 100021, 'T', 100001, 'C&W vs SS Billed (Count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count', 'C&W vs SS Billed (Count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100175, 100021, 'T', 100001, 'VOIP vs SS Billed (Count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count', 'VOIP vs SS Billed (Count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count');


insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100150, 100150, null, 102150, null, null, 'MSS vs TAPOUT (Count) - ST_VOICE_PARTNERS - EDR Count', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100151, 100151, null, 102151, null, null, 'MSS vs TAPOUT (Count) - ST_VOICE_PARTNERS - EDR Count (Daily)', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100152, 100152, null, 102152, null, null, 'SGSN vs TAPOUT (Count) - ST_DATA_PARTNERS - EDR Count', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100153, 100153, null, 102153, null, null, 'SGSN vs TAPOUT (Count) - ST_DATA_PARTNERS - EDR Count (Daily)', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100154, 100154, null, 102154, null, null, 'SGSN vs TAPOUT (Bytes) - ST_DATA_PARTNERS - EDR Bytes', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100155, 100155, null, 102155, null, null, 'SGSN vs TAPOUT (Bytes) - ST_DATA_PARTNERS - EDR Bytes (Daily)', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100156, 100156, null, 102156, null, null, 'SS Rated vs SS Billed (Count) - ST_VOICE - EDR Count', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100157, 100157, null, 102157, null, null, 'SS Rated vs SS Billed (Count) - ST_VOICE - EDR Count (Daily)', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100158, 100158, null, 102158, null, null, 'SS Rated vs SS Billed (Value) - ST_VOICE - EDR Value', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100159, 100159, null, 102159, null, null, 'SS Rated vs SS Billed (Value) - ST_VOICE - EDR Value (Daily)', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100160, 100160, null, 102160, null, null, 'EIRCOM vs SS Rated (count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count (Daily)', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100161, 100161, null, 102161, null, null, 'BT vs SS Rated (count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count (Daily)', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100162, 100162, null, 102162, null, null, 'C&W vs SS Rated (count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count (Daily)', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100163, 100163, null, 102163, null, null, 'VOIP vs SS Rated (count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count (Daily)', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100164, 100164, null, 102164, null, null, 'EIRCOM vs SS Rated (Count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100165, 100165, null, 102165, null, null, 'BT vs SS Rated (Count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100166, 100166, null, 102166, null, null, 'C&W vs SS Rated (Count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100167, 100167, null, 102167, null, null, 'VOIP vs SS Rated (Count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100168, 100168, null, 102168, null, null, 'EIRCOM vs SS Billed (count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count (Daily)', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100169, 100169, null, 102169, null, null, 'BT vs SS Billed (count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count (Daily)', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100170, 100170, null, 102170, null, null, 'C&W vs SS Billed (count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count (Daily)', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100171, 100171, null, 102171, null, null, 'VOIP vs SS Billed (count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count (Daily)', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100172, 100172, null, 102172, null, null, 'EIRCOM vs SS Billed (Count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100173, 100173, null, 102173, null, null, 'BT vs SS Billed (Count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100174, 100174, null, 102174, null, null, 'C&W vs SS Billed (Count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100175, 100175, null, 102175, null, null, 'VOIP vs SS Billed (Count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count', '', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');


update um.mrec_version_ref 
set    parameters = '-forecast_comparison Y';

update um.mrec_version_ref 
set    parameters = '-forecast_comparison Y -source 100082'
where  description like 'EIRCOM%';

update um.mrec_version_ref 
set    parameters = '-forecast_comparison Y -source 100083'
where  description like 'BT%';

update um.mrec_version_ref 
set    parameters = '-forecast_comparison Y -source 100084'
where  description like 'C&W%';

update um.mrec_version_ref 
set    parameters = '-forecast_comparison Y -source 100085'
where  description like 'VOIP%';

-- Enable/Disable primary, unique and foreign key constraints 
alter table um.MREC_METRIC_REF
  disable constraint MREC_METRIC_REF_PK;

delete FROM um.mrec_metric_ref
WHERE rowid not in
(SELECT MIN(rowid)
FROM um.mrec_metric_ref
GROUP BY MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, mrec_set);


insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100150, 102114, 100105, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100150, 102114, 100102, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100151, 102114, 100105, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100151, 102114, 100102, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100152, 102003, 100152, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100152, 102003, 100105, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100153, 102003, 100152, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100153, 102003, 100105, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100154, 102001, 100105, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100154, 102001, 100152, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100155, 102001, 100152, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100155, 102001, 100105, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100156, 100029, 100173, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100156, 100029, 100175, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100157, 100029, 100173, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100157, 100029, 100175, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100158, 100111, 100173, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100158, 100111, 100175, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100159, 100111, 100173, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100159, 100111, 100175, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100160, 100029, 100170, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100160, 102136, 100177, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100160, 100029, 100173, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100160, 102028, 100174, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100161, 100029, 100170, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100161, 100029, 100173, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100161, 102136, 100177, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100161, 102028, 100174, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100162, 102028, 100174, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100162, 100029, 100170, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100162, 100029, 100173, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100162, 102136, 100177, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100163, 102136, 100177, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100163, 100029, 100173, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100163, 100029, 100170, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100163, 102028, 100174, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100164, 102136, 100177, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100164, 100029, 100173, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100164, 100029, 100170, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100164, 102028, 100174, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100165, 102136, 100177, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100165, 100029, 100173, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100165, 100029, 100170, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100165, 102028, 100174, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100166, 102136, 100177, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100166, 102028, 100174, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100166, 100029, 100170, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100166, 100029, 100173, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100167, 100029, 100173, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100167, 100029, 100170, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100167, 102028, 100174, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100167, 102136, 100177, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100168, 102136, 100177, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100168, 102028, 100174, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100168, 100029, 100175, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100168, 100029, 100170, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100169, 102136, 100177, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100169, 102028, 100174, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100169, 100029, 100170, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100169, 100029, 100175, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100170, 102028, 100174, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100170, 100029, 100170, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100170, 100029, 100175, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100170, 102136, 100177, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100171, 100029, 100170, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100171, 102136, 100177, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100171, 102028, 100174, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100171, 100029, 100175, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100172, 102136, 100177, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100172, 102028, 100174, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100172, 100029, 100170, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100172, 100029, 100175, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100173, 102028, 100174, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100173, 100029, 100170, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100173, 102136, 100177, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100173, 100029, 100175, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100174, 100029, 100170, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100174, 102028, 100174, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100174, 102136, 100177, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100174, 100029, 100175, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100175, 100029, 100170, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100175, 100029, 100175, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100175, 102136, 100177, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100175, 102028, 100174, -1);

-- Enable/Disable primary, unique and foreign key constraints 
alter table um.MREC_METRIC_REF
  enable constraint MREC_METRIC_REF_PK;

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100333, 'SS Billed: ST_SMS - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100001, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100334, 'SS Rated: ST_SMS - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100001, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100335, 'VOIP: ST_VOICE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100029, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100336, 'SS Billed: ST_VOICE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100029, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100337, 'SS Rated: ST_VOICE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100029, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100338, 'C&W: ST_VOICE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100029, 100172, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100339, 'BT: ST_VOICE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100029, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100340, 'Eircom: ST_VOICE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100029, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100341, 'VOIP: ST_VOICE - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100037, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100342, 'SS Billed: ST_VOICE - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100037, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100343, 'SS Rated: ST_VOICE - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100037, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100344, 'C&W: ST_VOICE - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100037, 100172, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100345, 'BT: ST_VOICE - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100037, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100346, 'Eircom: ST_VOICE - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100037, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100347, 'SS Billed: ST_SMS - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100103, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100348, 'SS Rated: ST_SMS - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100103, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100349, 'SS Billed: ST_VOICE - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100111, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100350, 'SS Rated: ST_VOICE - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100111, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100351, 'SS Rated Suspense History: ST_AGG_SUCCESS - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100800, 100178, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100352, 'SS Rated Suspense: ST_AGG_SUCCESS - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100800, 100177, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100353, 'VOIP: ST_AGG_SUCCESS - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100800, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100354, 'SS Billed: ST_AGG_SUCCESS - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100800, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100355, 'SS Discarded: ST_AGG_SUCCESS - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100800, 100174, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100356, 'SS Rated: ST_AGG_SUCCESS - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100800, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100357, 'C&W: ST_AGG_SUCCESS - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100800, 100172, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100358, 'BT: ST_AGG_SUCCESS - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100800, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100359, 'Eircom: ST_AGG_SUCCESS - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100800, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100360, 'SS Rated Suspense History: ST_AGG_FAILED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100801, 100178, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100361, 'SS Rated Suspense: ST_AGG_FAILED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100801, 100177, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100362, 'VOIP: ST_AGG_FAILED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100801, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100363, 'SS Billed: ST_AGG_FAILED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100801, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100364, 'SS Discarded: ST_AGG_FAILED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100801, 100174, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100365, 'SS Rated: ST_AGG_FAILED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100801, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100366, 'C&W: ST_AGG_FAILED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100801, 100172, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100367, 'BT: ST_AGG_FAILED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100801, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100368, 'Eircom: ST_AGG_FAILED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100801, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100369, 'SS Rated Suspense History: ST_AGG_REJECTED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100802, 100178, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100370, 'SS Rated Suspense: ST_AGG_REJECTED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100802, 100177, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100371, 'VOIP: ST_AGG_REJECTED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100802, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100372, 'SS Billed: ST_AGG_REJECTED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100802, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100373, 'SS Discarded: ST_AGG_REJECTED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100802, 100174, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100374, 'SS Rated: ST_AGG_REJECTED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100802, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100375, 'C&W: ST_AGG_REJECTED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100802, 100172, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100376, 'BT: ST_AGG_REJECTED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100802, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100377, 'Eircom: ST_AGG_REJECTED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100802, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100378, 'SGSN: ST_DATA_PARTNERS - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102001, 100152, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100379, 'Tapout: ST_DATA_PARTNERS - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102001, 100105, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100380, 'SGSN: ST_DATA_PARTNERS - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102002, 100152, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100381, 'Tapout: ST_DATA_PARTNERS - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102002, 100105, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100382, 'SGSN: ST_DATA_PARTNERS - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102003, 100152, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100383, 'Tapout: ST_DATA_PARTNERS - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102003, 100105, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100384, 'SGSN: ST_DATA_PARTNERS - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102004, 100152, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100385, 'Tapout: ST_DATA_PARTNERS - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102004, 100105, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100386, 'SS Discarded: ST_DISCARDED - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102005, 100174, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100387, 'SS Discarded: ST_DISCARDED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102006, 100174, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100388, 'SS Billed: ST_SMS - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102007, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100389, 'SS Rated: ST_SMS - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102007, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100390, 'SS Billed: ST_SMS - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102008, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100391, 'SS Rated: ST_SMS - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102008, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100392, 'SS Rated Suspense History: ST_SUSPENSE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102009, 100178, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100393, 'SS Rated Suspense: ST_SUSPENSE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102009, 100177, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100394, 'SS Rated Suspense History: ST_SUSPENSE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102010, 100178, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100395, 'SS Rated Suspense: ST_SUSPENSE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102010, 100177, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100396, 'VOIP: ST_VOICE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102011, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100397, 'SS Billed: ST_VOICE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102011, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100398, 'SS Rated: ST_VOICE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102011, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100399, 'C&W: ST_VOICE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102011, 100172, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100400, 'BT: ST_VOICE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102011, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100401, 'Eircom: ST_VOICE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102011, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100402, 'VOIP: ST_VOICE - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102012, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100403, 'SS Billed: ST_VOICE - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102012, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100404, 'SS Rated: ST_VOICE - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102012, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100405, 'C&W: ST_VOICE - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102012, 100172, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100406, 'BT: ST_VOICE - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102012, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100407, 'Eircom: ST_VOICE - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102012, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100408, 'SS Billed: ST_VOICE - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102013, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100409, 'SS Rated: ST_VOICE - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102013, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100410, 'SS Rated Suspense History: ST_VOICE_AGED - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102014, 100178, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100411, 'SS Rated Suspense History: ST_VOICE_AGED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102015, 100178, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100412, 'SS Billed: ST_VOICE_ANCILIARY - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102016, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100413, 'SS Rated: ST_VOICE_ANCILIARY - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102016, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100414, 'SS Billed: ST_VOICE_ANCILIARY - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102017, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100415, 'SS Rated: ST_VOICE_ANCILIARY - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102017, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100416, 'SS Billed: ST_VOICE_ANCILIARY - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102018, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100417, 'SS Rated: ST_VOICE_ANCILIARY - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102018, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100418, 'SS Billed: ST_VOICE_ANCILIARY - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102019, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100419, 'SS Rated: ST_VOICE_ANCILIARY - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102019, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100420, 'SS Billed: ST_VOICE_ANCILIARY - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102020, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100421, 'SS Rated: ST_VOICE_ANCILIARY - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102020, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100422, 'SS Billed: ST_VOICE_ANCILIARY - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102021, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100423, 'SS Rated: ST_VOICE_ANCILIARY - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102021, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100424, 'SS Discarded: ST_VOICE_DISCARDED - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102028, 100174, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100425, 'SS Discarded: ST_VOICE_DISCARDED - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102029, 100174, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100426, 'VOIP: ST_VOICE_DOM - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102030, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100427, 'SS Billed: ST_VOICE_DOM - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102030, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100428, 'SS Rated: ST_VOICE_DOM - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102030, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100429, 'BT: ST_VOICE_DOM - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102030, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100430, 'Eircom: ST_VOICE_DOM - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102030, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100431, 'VOIP: ST_VOICE_DOM - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102031, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100432, 'SS Billed: ST_VOICE_DOM - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102031, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100433, 'SS Rated: ST_VOICE_DOM - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102031, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100434, 'BT: ST_VOICE_DOM - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102031, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100435, 'Eircom: ST_VOICE_DOM - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102031, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100436, 'VOIP: ST_VOICE_DOM - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102032, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100437, 'SS Billed: ST_VOICE_DOM - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102032, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100438, 'SS Rated: ST_VOICE_DOM - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102032, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100439, 'BT: ST_VOICE_DOM - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102032, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100440, 'Eircom: ST_VOICE_DOM - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102032, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100441, 'VOIP: ST_VOICE_DOM - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102033, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100442, 'SS Billed: ST_VOICE_DOM - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102033, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100443, 'SS Rated: ST_VOICE_DOM - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102033, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100444, 'BT: ST_VOICE_DOM - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102033, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100445, 'Eircom: ST_VOICE_DOM - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102033, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100446, 'SS Billed: ST_VOICE_DOM - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102034, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100447, 'SS Rated: ST_VOICE_DOM - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102034, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100448, 'SS Billed: ST_VOICE_DOM - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102035, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100449, 'SS Rated: ST_VOICE_DOM - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102035, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100450, 'SS Billed: ST_VOICE_DQ - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102036, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100451, 'SS Rated: ST_VOICE_DQ - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102036, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100452, 'SS Billed: ST_VOICE_DQ - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102037, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100453, 'SS Rated: ST_VOICE_DQ - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102037, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100454, 'SS Billed: ST_VOICE_DQ - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102038, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100455, 'SS Rated: ST_VOICE_DQ - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102038, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100456, 'SS Billed: ST_VOICE_DQ - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102039, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100457, 'SS Rated: ST_VOICE_DQ - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102039, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100458, 'SS Billed: ST_VOICE_DQ - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102040, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100459, 'SS Rated: ST_VOICE_DQ - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102040, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100460, 'SS Billed: ST_VOICE_DQ - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102041, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100461, 'SS Rated: ST_VOICE_DQ - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102041, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100462, 'SS Rated Suspense History: ST_VOICE_EXPIRING - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102042, 100178, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100463, 'SS Rated Suspense History: ST_VOICE_EXPIRING - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102043, 100178, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100464, 'VOIP: ST_VOICE_FO - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102044, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100465, 'SS Billed: ST_VOICE_FO - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102044, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100466, 'SS Rated: ST_VOICE_FO - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102044, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100467, 'BT: ST_VOICE_FO - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102044, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100468, 'Eircom: ST_VOICE_FO - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102044, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100469, 'VOIP: ST_VOICE_FO - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102045, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100470, 'SS Billed: ST_VOICE_FO - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102045, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100471, 'SS Rated: ST_VOICE_FO - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102045, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100472, 'BT: ST_VOICE_FO - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102045, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100473, 'Eircom: ST_VOICE_FO - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102045, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100474, 'VOIP: ST_VOICE_FO - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102046, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100475, 'SS Billed: ST_VOICE_FO - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102046, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100476, 'SS Rated: ST_VOICE_FO - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102046, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100477, 'BT: ST_VOICE_FO - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102046, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100478, 'Eircom: ST_VOICE_FO - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102046, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100479, 'VOIP: ST_VOICE_FO - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102047, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100480, 'SS Billed: ST_VOICE_FO - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102047, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100481, 'SS Rated: ST_VOICE_FO - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102047, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100482, 'BT: ST_VOICE_FO - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102047, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100483, 'Eircom: ST_VOICE_FO - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102047, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100484, 'SS Billed: ST_VOICE_FO - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102048, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100485, 'SS Rated: ST_VOICE_FO - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102048, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100486, 'SS Billed: ST_VOICE_FO - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102049, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100487, 'SS Rated: ST_VOICE_FO - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102049, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100488, 'SS Billed: ST_VOICE_FT - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102050, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100489, 'SS Rated: ST_VOICE_FT - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102050, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100490, 'C&W: ST_VOICE_FT - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102050, 100172, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100491, 'SS Billed: ST_VOICE_FT - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102051, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100492, 'SS Rated: ST_VOICE_FT - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102051, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100493, 'C&W: ST_VOICE_FT - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102051, 100172, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100494, 'SS Billed: ST_VOICE_FT - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102052, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100495, 'SS Rated: ST_VOICE_FT - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102052, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100496, 'C&W: ST_VOICE_FT - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102052, 100172, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100497, 'SS Billed: ST_VOICE_FT - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102053, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100498, 'SS Rated: ST_VOICE_FT - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102053, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100499, 'C&W: ST_VOICE_FT - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102053, 100172, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100500, 'SS Billed: ST_VOICE_FT - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102054, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100501, 'SS Rated: ST_VOICE_FT - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102054, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100502, 'SS Billed: ST_VOICE_FT - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102055, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100503, 'SS Rated: ST_VOICE_FT - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102055, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100504, 'SS Billed: ST_VOICE_INBOUND - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102056, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100505, 'SS Rated: ST_VOICE_INBOUND - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102056, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100506, 'SS Billed: ST_VOICE_INBOUND - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102057, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100507, 'SS Rated: ST_VOICE_INBOUND - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102057, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100508, 'SS Billed: ST_VOICE_INBOUND - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102058, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100509, 'SS Rated: ST_VOICE_INBOUND - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102058, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100510, 'SS Billed: ST_VOICE_INBOUND - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102059, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100511, 'SS Rated: ST_VOICE_INBOUND - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102059, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100512, 'SS Billed: ST_VOICE_INBOUND - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102060, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100513, 'SS Rated: ST_VOICE_INBOUND - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102060, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100514, 'SS Billed: ST_VOICE_INBOUND - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102061, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100515, 'SS Rated: ST_VOICE_INBOUND - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102061, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100516, 'SS Billed: ST_VOICE_INTERNET - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102062, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100517, 'SS Rated: ST_VOICE_INTERNET - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102062, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100518, 'SS Billed: ST_VOICE_INTERNET - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102063, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100519, 'SS Rated: ST_VOICE_INTERNET - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102063, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100520, 'SS Billed: ST_VOICE_INTERNET - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102064, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100521, 'SS Rated: ST_VOICE_INTERNET - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102064, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100522, 'SS Billed: ST_VOICE_INTERNET - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102065, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100523, 'SS Rated: ST_VOICE_INTERNET - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102065, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100524, 'SS Billed: ST_VOICE_INTERNET - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102066, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100525, 'SS Rated: ST_VOICE_INTERNET - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102066, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100526, 'SS Billed: ST_VOICE_INTERNET - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102067, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100527, 'SS Rated: ST_VOICE_INTERNET - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102067, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100528, 'VOIP: ST_VOICE_INTL - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102068, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100529, 'SS Billed: ST_VOICE_INTL - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102068, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100530, 'SS Rated: ST_VOICE_INTL - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102068, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100531, 'BT: ST_VOICE_INTL - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102068, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100532, 'Eircom: ST_VOICE_INTL - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102068, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100533, 'VOIP: ST_VOICE_INTL - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102069, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100534, 'SS Billed: ST_VOICE_INTL - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102069, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100535, 'SS Rated: ST_VOICE_INTL - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102069, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100536, 'BT: ST_VOICE_INTL - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102069, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100537, 'Eircom: ST_VOICE_INTL - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102069, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100538, 'VOIP: ST_VOICE_INTL - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102070, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100539, 'SS Billed: ST_VOICE_INTL - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102070, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100540, 'SS Rated: ST_VOICE_INTL - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102070, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100541, 'BT: ST_VOICE_INTL - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102070, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100542, 'Eircom: ST_VOICE_INTL - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102070, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100543, 'VOIP: ST_VOICE_INTL - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102071, 100176, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100544, 'SS Billed: ST_VOICE_INTL - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102071, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100545, 'SS Rated: ST_VOICE_INTL - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102071, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100546, 'BT: ST_VOICE_INTL - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102071, 100171, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100547, 'Eircom: ST_VOICE_INTL - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102071, 100170, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100548, 'SS Billed: ST_VOICE_INTL - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102072, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100549, 'SS Rated: ST_VOICE_INTL - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102072, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100550, 'SS Billed: ST_VOICE_INTL - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102073, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100551, 'SS Rated: ST_VOICE_INTL - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102073, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100552, 'SS Billed: ST_VOICE_INTL_FREE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102074, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100553, 'SS Rated: ST_VOICE_INTL_FREE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102074, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100554, 'SS Billed: ST_VOICE_INTL_FREE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102075, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100555, 'SS Rated: ST_VOICE_INTL_FREE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102075, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100556, 'SS Billed: ST_VOICE_INTL_FREE - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102076, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100557, 'SS Rated: ST_VOICE_INTL_FREE - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102076, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100558, 'SS Billed: ST_VOICE_INTL_FREE - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102077, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100559, 'SS Rated: ST_VOICE_INTL_FREE - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102077, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100560, 'SS Billed: ST_VOICE_IN_BUNDLE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102078, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100561, 'SS Billed: ST_VOICE_IN_BUNDLE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102079, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100562, 'SS Billed: ST_VOICE_IN_BUNDLE - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102080, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100563, 'SS Billed: ST_VOICE_IN_BUNDLE - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102081, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100564, 'SS Billed: ST_VOICE_IN_BUNDLE - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102082, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100565, 'SS Billed: ST_VOICE_IN_BUNDLE - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102083, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100566, 'SS Billed: ST_VOICE_LOW_CALL - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102084, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100567, 'SS Rated: ST_VOICE_LOW_CALL - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102084, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100568, 'SS Billed: ST_VOICE_LOW_CALL - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102085, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100569, 'SS Rated: ST_VOICE_LOW_CALL - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102085, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100570, 'SS Billed: ST_VOICE_LOW_CALL - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102086, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100571, 'SS Rated: ST_VOICE_LOW_CALL - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102086, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100572, 'SS Billed: ST_VOICE_LOW_CALL - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102087, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100573, 'SS Rated: ST_VOICE_LOW_CALL - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102087, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100574, 'SS Billed: ST_VOICE_LOW_CALL - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102088, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100575, 'SS Rated: ST_VOICE_LOW_CALL - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102088, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100576, 'SS Billed: ST_VOICE_LOW_CALL - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102089, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100577, 'SS Rated: ST_VOICE_LOW_CALL - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102089, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100578, 'SS Billed: ST_VOICE_MT - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102090, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100579, 'SS Rated: ST_VOICE_MT - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102090, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100580, 'SS Billed: ST_VOICE_MT - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102091, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100581, 'SS Rated: ST_VOICE_MT - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102091, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100582, 'SS Billed: ST_VOICE_MT - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102092, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100583, 'SS Rated: ST_VOICE_MT - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102092, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100584, 'SS Billed: ST_VOICE_MT - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102093, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100585, 'SS Rated: ST_VOICE_MT - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102093, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100586, 'SS Billed: ST_VOICE_MT - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102094, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100587, 'SS Rated: ST_VOICE_MT - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102094, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100588, 'SS Billed: ST_VOICE_MT - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102095, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100589, 'SS Rated: ST_VOICE_MT - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102095, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100590, 'SS Billed: ST_VOICE_MT_INTL - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102096, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100591, 'SS Rated: ST_VOICE_MT_INTL - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102096, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100592, 'SS Billed: ST_VOICE_MT_INTL - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102097, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100593, 'SS Rated: ST_VOICE_MT_INTL - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102097, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100594, 'SS Billed: ST_VOICE_MT_INTL - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102098, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100595, 'SS Rated: ST_VOICE_MT_INTL - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102098, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100596, 'SS Billed: ST_VOICE_MT_INTL - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102099, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100597, 'SS Rated: ST_VOICE_MT_INTL - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102099, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100598, 'SS Billed: ST_VOICE_MT_INTL - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102100, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100599, 'SS Rated: ST_VOICE_MT_INTL - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102100, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100600, 'SS Billed: ST_VOICE_MT_INTL - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102101, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100601, 'SS Rated: ST_VOICE_MT_INTL - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102101, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100602, 'SS Billed: ST_VOICE_NGN - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102102, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100603, 'SS Rated: ST_VOICE_NGN - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102102, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100604, 'SS Billed: ST_VOICE_NGN - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102103, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100605, 'SS Rated: ST_VOICE_NGN - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102103, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100606, 'SS Billed: ST_VOICE_NGN - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102104, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100607, 'SS Rated: ST_VOICE_NGN - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102104, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100608, 'SS Billed: ST_VOICE_NGN - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102105, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100609, 'SS Rated: ST_VOICE_NGN - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102105, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100610, 'SS Billed: ST_VOICE_NGN - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102106, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100611, 'SS Rated: ST_VOICE_NGN - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102106, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100612, 'SS Billed: ST_VOICE_NGN - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102107, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100613, 'SS Rated: ST_VOICE_NGN - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102107, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100614, 'SS Billed: ST_VOICE_OUT_BUNDLE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102108, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100615, 'SS Billed: ST_VOICE_OUT_BUNDLE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102109, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100616, 'SS Billed: ST_VOICE_OUT_BUNDLE - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102110, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100617, 'SS Billed: ST_VOICE_OUT_BUNDLE - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102111, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100618, 'SS Billed: ST_VOICE_OUT_BUNDLE - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102112, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100619, 'SS Billed: ST_VOICE_OUT_BUNDLE - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102113, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100620, 'Tapout: ST_VOICE_PARTNERS - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102114, 100105, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100621, 'MSS: ST_VOICE_PARTNERS - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102114, 100102, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100622, 'Tapout: ST_VOICE_PARTNERS - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102115, 100105, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100623, 'MSS: ST_VOICE_PARTNERS - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102115, 100102, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100624, 'Tapout: ST_VOICE_PARTNERS - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102116, 100105, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100625, 'MSS: ST_VOICE_PARTNERS - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102116, 100102, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100626, 'Tapout: ST_VOICE_PARTNERS - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102117, 100105, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100627, 'MSS: ST_VOICE_PARTNERS - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102117, 100102, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100628, 'SS Billed: ST_VOICE_PREMIUM - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102118, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100629, 'SS Rated: ST_VOICE_PREMIUM - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102118, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100630, 'SS Billed: ST_VOICE_PREMIUM - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102119, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100631, 'SS Rated: ST_VOICE_PREMIUM - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102119, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100632, 'SS Billed: ST_VOICE_PREMIUM - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102120, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100633, 'SS Rated: ST_VOICE_PREMIUM - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102120, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100634, 'SS Billed: ST_VOICE_PREMIUM - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102121, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100635, 'SS Rated: ST_VOICE_PREMIUM - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102121, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100636, 'SS Billed: ST_VOICE_PREMIUM - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102122, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100637, 'SS Rated: ST_VOICE_PREMIUM - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102122, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100638, 'SS Billed: ST_VOICE_PREMIUM - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102123, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100639, 'SS Rated: ST_VOICE_PREMIUM - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102123, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100640, 'SS Billed: ST_VOICE_PREMIUM_INTL - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102124, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100641, 'SS Rated: ST_VOICE_PREMIUM_INTL - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102124, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100642, 'SS Billed: ST_VOICE_PREMIUM_INTL - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102125, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100643, 'SS Rated: ST_VOICE_PREMIUM_INTL - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102125, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100644, 'SS Billed: ST_VOICE_PREMIUM_INTL - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102126, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100645, 'SS Rated: ST_VOICE_PREMIUM_INTL - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102126, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100646, 'SS Billed: ST_VOICE_PREMIUM_INTL - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102127, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100647, 'SS Rated: ST_VOICE_PREMIUM_INTL - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102127, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100648, 'SS Billed: ST_VOICE_PREMIUM_INTL - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102128, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100649, 'SS Rated: ST_VOICE_PREMIUM_INTL - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102128, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100650, 'SS Billed: ST_VOICE_PREMIUM_INTL - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102129, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100651, 'SS Rated: ST_VOICE_PREMIUM_INTL - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102129, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100652, 'SS Billed: ST_VOICE_PROMOTIONAL - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102130, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100653, 'SS Rated: ST_VOICE_PROMOTIONAL - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102130, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100654, 'SS Billed: ST_VOICE_PROMOTIONAL - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102131, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100655, 'SS Rated: ST_VOICE_PROMOTIONAL - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102131, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100656, 'SS Billed: ST_VOICE_PROMOTIONAL - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102132, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100657, 'SS Rated: ST_VOICE_PROMOTIONAL - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102132, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100658, 'SS Billed: ST_VOICE_PROMOTIONAL - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102133, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100659, 'SS Rated: ST_VOICE_PROMOTIONAL - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102133, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100660, 'SS Billed: ST_VOICE_PROMOTIONAL - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102134, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100661, 'SS Rated: ST_VOICE_PROMOTIONAL - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102134, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100662, 'SS Billed: ST_VOICE_PROMOTIONAL - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102135, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100663, 'SS Rated: ST_VOICE_PROMOTIONAL - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102135, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100664, 'SS Rated Suspense History: ST_VOICE_SUSPENSE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102136, 100178, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100665, 'SS Rated Suspense: ST_VOICE_SUSPENSE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102136, 100177, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100666, 'SS Rated Suspense History: ST_VOICE_SUSPENSE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102137, 100178, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100667, 'SS Rated Suspense: ST_VOICE_SUSPENSE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102137, 100177, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100668, 'SS Rated Suspense History: ST_VOICE_SUSPENSE - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102138, 100178, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100669, 'SS Rated Suspense: ST_VOICE_SUSPENSE - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102138, 100177, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100670, 'SS Rated Suspense History: ST_VOICE_SUSPENSE - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102139, 100178, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100671, 'SS Rated Suspense: ST_VOICE_SUSPENSE - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102139, 100177, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100672, 'SS Billed: ST_VOICE_VOIP - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102140, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100673, 'SS Rated: ST_VOICE_VOIP - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102140, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100674, 'SS Billed: ST_VOICE_VOIP - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102141, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100675, 'SS Rated: ST_VOICE_VOIP - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102141, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100676, 'SS Billed: ST_VOICE_VOIP - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102142, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100677, 'SS Rated: ST_VOICE_VOIP - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102142, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100678, 'SS Billed: ST_VOICE_VOIP - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102143, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100679, 'SS Rated: ST_VOICE_VOIP - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102143, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100680, 'SS Billed: ST_VOICE_VOIP - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102144, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100681, 'SS Rated: ST_VOICE_VOIP - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102144, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100682, 'SS Billed: ST_VOICE_VOIP - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102145, 100175, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100683, 'SS Rated: ST_VOICE_VOIP - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102145, 100173, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100684, 'WAP ICCS: ST_DATA_PARTNERS - EDR Count (Daily) (Absolute) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102146, 100144, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100685, 'GPRS ICCS: ST_DATA_PARTNERS - EDR Count (Daily) (Absolute) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102146, 100141, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100686, 'ICCS Unbilled: ST_DATA_PARTNERS - EDR Count (Daily) (Absolute) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102146, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100687, 'GSM: ST_VOICE_PARTNERS - EDR Count (Daily) (Absolute) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102147, 100142, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100688, 'ICCS Unbilled: ST_VOICE_PARTNERS - EDR Count (Daily) (Absolute) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102147, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102331, 'ICCS Unbilled: ST_VOICE_IN_BUNDLE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102078, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102332, 'ICCS Unbilled: ST_VOICE_IN_BUNDLE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102079, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102333, 'ICCS Unbilled: ST_VOICE_IN_BUNDLE - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102080, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102334, 'ICCS Unbilled: ST_VOICE_IN_BUNDLE - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102081, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102335, 'ICCS Unbilled: ST_VOICE_IN_BUNDLE - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102082, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102336, 'ICCS Unbilled: ST_VOICE_IN_BUNDLE - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102083, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102337, 'ICCS Unbilled: ST_VOICE_OUT_BUNDLE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102108, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102338, 'ICCS Unbilled: ST_VOICE_OUT_BUNDLE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102109, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102339, 'ICCS Unbilled: ST_VOICE_OUT_BUNDLE - EDR Duration Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102110, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102340, 'ICCS Unbilled: ST_VOICE_OUT_BUNDLE - EDR Duration (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102111, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102341, 'ICCS Unbilled: ST_VOICE_OUT_BUNDLE - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102112, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102342, 'ICCS Unbilled: ST_VOICE_OUT_BUNDLE - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102113, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102343, 'ICCS Unbilled: ST_DATA_IN_BUNDLE - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102331, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102344, 'ICCS Unbilled: ST_DATA_IN_BUNDLE - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102332, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102345, 'ICCS Unbilled: ST_DATA_IN_BUNDLE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102333, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102346, 'ICCS Unbilled: ST_DATA_IN_BUNDLE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102334, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102347, 'ICCS Unbilled: ST_DATA_IN_BUNDLE - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102335, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102348, 'ICCS Unbilled: ST_DATA_IN_BUNDLE - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102336, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102349, 'ICCS Unbilled: ST_DATA_OUT_BUNDLE - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102337, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102350, 'ICCS Unbilled: ST_DATA_OUT_BUNDLE - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102338, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102351, 'ICCS Unbilled: ST_DATA_OUT_BUNDLE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102339, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102352, 'ICCS Unbilled: ST_DATA_OUT_BUNDLE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102340, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102353, 'ICCS Unbilled: ST_DATA_OUT_BUNDLE - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102341, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102354, 'ICCS Unbilled: ST_DATA_OUT_BUNDLE - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102342, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102355, 'ICCS Unbilled: ST_MMS_IN_BUNDLE - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102343, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102356, 'ICCS Unbilled: ST_MMS_IN_BUNDLE - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102344, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102357, 'ICCS Unbilled: ST_MMS_IN_BUNDLE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102345, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102358, 'ICCS Unbilled: ST_MMS_IN_BUNDLE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102346, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102359, 'ICCS Unbilled: ST_MMS_IN_BUNDLE - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102347, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102360, 'ICCS Unbilled: ST_MMS_IN_BUNDLE - EDR Value (Daily)  Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102348, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102361, 'ICCS Unbilled: ST_MMS_OUT_BUNDLE - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102349, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102362, 'ICCS Unbilled: ST_MMS_OUT_BUNDLE - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102350, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102363, 'ICCS Unbilled: ST_MMS_OUT_BUNDLE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102351, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102364, 'ICCS Unbilled: ST_MMS_OUT_BUNDLE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102352, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102365, 'ICCS Unbilled: ST_MMS_OUT_BUNDLE - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102353, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102366, 'ICCS Unbilled: ST_MMS_OUT_BUNDLE - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102354, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102367, 'ICCS Unbilled: ST_SMS_IN_BUNDLE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102355, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102368, 'ICCS Unbilled: ST_SMS_IN_BUNDLE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102356, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102369, 'ICCS Unbilled: ST_SMS_IN_BUNDLE - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102357, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102370, 'ICCS Unbilled: ST_SMS_IN_BUNDLE - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102358, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102371, 'ICCS Unbilled: ST_SMS_OUT_BUNDLE - EDR Count Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102359, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102372, 'ICCS Unbilled: ST_SMS_OUT_BUNDLE - EDR Count (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102360, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102373, 'ICCS Unbilled: ST_SMS_OUT_BUNDLE - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102361, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102374, 'ICCS Unbilled: ST_SMS_OUT_BUNDLE - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102362, 100120, null, null, null, null, null, 'Y', 'Y', 'Y', 'Y', 'Y', 450, 175, '', '');




insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100150, 'MSS vs TAPOUT (Count) - ST_VOICE_PARTNERS - EDR Count', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100150', 100150, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100151, 'MSS vs TAPOUT (Count) - ST_VOICE_PARTNERS - EDR Count (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100151', 100151, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100152, 'SGSN vs TAPOUT (Count) - ST_DATA_PARTNERS - EDR Count', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100152', 100152, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100153, 'SGSN vs TAPOUT (Count) - ST_DATA_PARTNERS - EDR Count (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100153', 100153, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100154, 'SGSN vs TAPOUT (Bytes) - ST_DATA_PARTNERS - EDR Bytes', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100154', 100154, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100155, 'SGSN vs TAPOUT (Bytes) - ST_DATA_PARTNERS - EDR Bytes (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100155', 100155, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100156, 'SS Rated vs SS Billed (Count) - ST_VOICE - EDR Count', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100156', 100156, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100157, 'SS Rated vs SS Billed (Count) - ST_VOICE - EDR Count (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100157', 100157, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100158, 'SS Rated vs SS Billed (Value) - ST_VOICE - EDR Value', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100158', 100158, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100159, 'SS Rated vs SS Billed (Value) - ST_VOICE - EDR Value (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100159', 100159, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100160, 'EIRCOM vs SS Rated (count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100160', 100160, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100161, 'BT vs SS Rated (count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100161', 100161, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100162, 'C&W vs SS Rated (count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100162', 100162, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100163, 'VOIP vs SS Rated (count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100163', 100163, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100164, 'EIRCOM vs SS Rated (Count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100164', 100164, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100165, 'BT vs SS Rated (Count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100165', 100165, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100166, 'C&W vs SS Rated (Count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100166', 100166, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100167, 'VOIP vs SS Rated (Count) - ST_VOICE + ST_VOICE_SUSPENSE - EDR Count', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100167', 100167, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100168, 'EIRCOM vs SS Billed (count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100168', 100168, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100169, 'BT vs SS Billed (count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100169', 100169, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100170, 'C&W vs SS Billed (count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100170', 100170, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100171, 'VOIP vs SS Billed (count) - ST_VOICE - ST_VOICE_SUSPENSE? ST_VOICE_DISCARDED - EDR Count (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100171', 100171, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100172, 'EIRCOM vs SS Billed (Count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100172', 100172, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100173, 'BT vs SS Billed (Count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100173', 100173, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100174, 'C&W vs SS Billed (Count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100174', 100174, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100175, 'VOIP vs SS Billed (Count) - ST_VOICE - ST_VOICE_SUSPENSE - ST_VOICE_DISCARDED - EDR Count', '/um/um/mrecChartSetup.do?mrecType=TIME&mrecDefinitionId_time=100175', 100175, null, '14', '0', 'R', 450, 175, '', '');


update um.node_metric_jn
set file_match_definition_id = 100002
where  metric_definition_id in (100800,100801,100802);
 

alter table um.agg_f_mrec_chart add mrec_perc number;
alter table um.agg_f_mrec_chart add is_comparator varchar2(1);
alter table um.agg_f_mrec_chart add forecast number;
alter table um.agg_f_mrec_chart add forecast_perc number;
alter table um.agg_f_mrec_chart add mrec_perc_plus number;
alter table um.agg_f_mrec_chart add forecast_perc_plus number;
alter table um.agg_f_mrec_chart add frec number;
alter table um.agg_f_mrec_chart add frec_perc number;




update um.node_metric_jn nmj
set    nmj.file_match_definition_id = 100001
where  exists (select 1
               from   um.metric_definition_ref d
               where d.metric_definition_id = nmj.metric_definition_id
               and   d.name like '%BUNDLE%Daily%'
               )
and   file_match_definition_id = 100000 ;   
    

update um.node_metric_jn nmj
set    nmj.file_match_definition_id = 100000
where  exists  (select 1
               from   um.metric_definition_ref d
               where d.metric_definition_id = nmj.metric_definition_id
               and   d.name like '%BUNDLE%'
               and   d.name not like '%Daily%'
               )
and   file_match_definition_id = 100001;   
    
commit;

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102401, 'ST_DATA_PARTNERS - EDR Value', 'ST_DATA_PARTNERS - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102402, 'ST_DATA_PARTNERS - EDR Value (Daily)', 'ST_DATA_PARTNERS - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102403, 'ST_DISCARDED - EDR Value', 'ST_DISCARDED - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102404, 'ST_DISCARDED - EDR Value (Daily)', 'ST_DISCARDED - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102405, 'ST_SUSPENSE - EDR Value', 'ST_SUSPENSE - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102406, 'ST_SUSPENSE - EDR Value (Daily)', 'ST_SUSPENSE - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102407, 'ST_VOICE_AGED - EDR Duration', 'ST_VOICE_AGED - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102408, 'ST_VOICE_AGED - EDR Duration (Daily)', 'ST_VOICE_AGED - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102409, 'ST_VOICE_AGED - EDR Value', 'ST_VOICE_AGED - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102410, 'ST_VOICE_AGED - EDR Value (Daily)', 'ST_VOICE_AGED - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102411, 'ST_VOICE_DISCARDED - EDR Value', 'ST_VOICE_DISCARDED - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102412, 'ST_VOICE_DISCARDED - EDR Value (Daily)', 'ST_VOICE_DISCARDED - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102413, 'ST_VOICE_EXPIRING - EDR Duration', 'ST_VOICE_EXPIRING - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102414, 'ST_VOICE_EXPIRING - EDR Duration (Daily)', 'ST_VOICE_EXPIRING - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102415, 'ST_VOICE_EXPIRING - EDR Value', 'ST_VOICE_EXPIRING - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102416, 'ST_VOICE_EXPIRING - EDR Value (Daily)', 'ST_VOICE_EXPIRING - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102417, 'ST_VOICE_INTL_FREE - EDR Value', 'ST_VOICE_INTL_FREE - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102418, 'ST_VOICE_INTL_FREE - EDR Value (Daily)', 'ST_VOICE_INTL_FREE - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102419, 'ST_VOICE_PARTNERS - EDR Value', 'ST_VOICE_PARTNERS - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102420, 'ST_VOICE_PARTNERS - EDR Value (Daily)', 'ST_VOICE_PARTNERS - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102421, 'ST_VOICE_SUSPENSE - EDR Value', 'ST_VOICE_SUSPENSE - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102422, 'ST_VOICE_SUSPENSE - EDR Value (Daily)', 'ST_VOICE_SUSPENSE - EDR Value (Daily)', 7, 100000, 100000);




insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102401, 102401, null, 'ST_DATA_PARTNERS - EDR Value', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102402, 102402, null, 'ST_DATA_PARTNERS - EDR Value (Daily)', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102403, 102403, null, 'ST_DISCARDED - EDR Value', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102404, 102404, null, 'ST_DISCARDED - EDR Value (Daily)', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102405, 102405, null, 'ST_SUSPENSE - EDR Value', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102406, 102406, null, 'ST_SUSPENSE - EDR Value (Daily)', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102407, 102407, null, 'ST_VOICE_AGED - EDR Duration', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102408, 102408, null, 'ST_VOICE_AGED - EDR Duration (Daily)', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102409, 102409, null, 'ST_VOICE_AGED - EDR Value', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102410, 102410, null, 'ST_VOICE_AGED - EDR Value (Daily)', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102411, 102411, null, 'ST_VOICE_DISCARDED - EDR Value', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102412, 102412, null, 'ST_VOICE_DISCARDED - EDR Value (Daily)', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102413, 102413, null, 'ST_VOICE_EXPIRING - EDR Duration', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102414, 102414, null, 'ST_VOICE_EXPIRING - EDR Duration (Daily)', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102415, 102415, null, 'ST_VOICE_EXPIRING - EDR Value', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102416, 102416, null, 'ST_VOICE_EXPIRING - EDR Value (Daily)', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102417, 102417, null, 'ST_VOICE_INTL_FREE - EDR Value', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102418, 102418, null, 'ST_VOICE_INTL_FREE - EDR Value (Daily)', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102419, 102419, null, 'ST_VOICE_PARTNERS - EDR Value', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102420, 102420, null, 'ST_VOICE_PARTNERS - EDR Value (Daily)', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102421, 102421, null, 'ST_VOICE_SUSPENSE - EDR Value', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102422, 102422, null, 'ST_VOICE_SUSPENSE - EDR Value (Daily)', to_date('23-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');




insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102401, 100001, 102401);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102402, 100001, 102402);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102403, 100001, 102403);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102404, 100001, 102404);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102405, 100001, 102405);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102406, 100001, 102406);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102407, 100001, 102407);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102408, 100001, 102408);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102409, 100001, 102409);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102410, 100001, 102410);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102411, 100001, 102411);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102412, 100001, 102412);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102413, 100001, 102413);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102414, 100001, 102414);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102415, 100001, 102415);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102416, 100001, 102416);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102417, 100001, 102417);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102418, 100001, 102418);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102419, 100001, 102419);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102420, 100001, 102420);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102421, 100001, 102421);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102422, 100001, 102422);



insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102401, 102401, 3, 35127, 102401, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_PARTNERS - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102402, 102402, 3, 35127, 102402, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_PARTNERS - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102403, 102403, 3, 35127, 102403, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DISCARDED - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102404, 102404, 3, 35127, 102404, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DISCARDED - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102405, 102405, 3, 35127, 102405, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_SUSPENSE - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102406, 102406, 3, 35127, 102406, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_SUSPENSE - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102407, 102407, 4, 35127, 102407, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_AGED - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102408, 102408, 4, 35127, 102408, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_AGED - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102409, 102409, 3, 35127, 102409, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_AGED - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102410, 102410, 3, 35127, 102410, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_AGED - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102411, 102411, 3, 35127, 102411, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DISCARDED - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102412, 102412, 3, 35127, 102412, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DISCARDED - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102413, 102413, 4, 35127, 102413, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_EXPIRING - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102414, 102414, 4, 35127, 102414, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_EXPIRING - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102415, 102415, 3, 35127, 102415, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_EXPIRING - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102416, 102416, 3, 35127, 102416, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_EXPIRING - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102417, 102417, 3, 35127, 102417, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTL_FREE - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102418, 102418, 3, 35127, 102418, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_INTL_FREE - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102419, 102419, 3, 35127, 102419, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PARTNERS - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102420, 102420, 3, 35127, 102420, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_PARTNERS - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102421, 102421, 3, 35127, 102421, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_SUSPENSE - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102422, 102422, 3, 35127, 102422, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_SUSPENSE - EDR Value (Daily)');



insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102401, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100171', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102402, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100171', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102403, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100196', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102404, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100196', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102405, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100191', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102406, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100191', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102407, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100193', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102408, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100193', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102409, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100193', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102410, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100193', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102411, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100195', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102412, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100195', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102413, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100194', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102414, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100194', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102415, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100194', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102416, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100194', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102417, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100180', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102418, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100180', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102419, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100170', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102420, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100170', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102421, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100192', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102422, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100192', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');





insert into um.node_metric_jn values (100171,100036,102402,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100171,100110,102403,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100171,102013,102404,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100171,100111,102405,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100171,102035,102406,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100171,102034,102407,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100171,102049,102408,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100171,102048,102409,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100171,102073,102410,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100171,102072,102411,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100172,100036,102413,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100172,100110,102414,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100172,102013,102415,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100172,100111,102416,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100172,102055,102417,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100172,102054,102418,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100170,100036,102420,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100170,100110,102421,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100170,102013,102422,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100170,100111,102423,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100170,102035,102424,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100170,102034,102425,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100170,102049,102426,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100170,102048,102427,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100170,102073,102428,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100170,102072,102429,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100120,102402,102430,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100120,102401,102431,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100120,102420,102432,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100120,102419,102433,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100152,102402,102434,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100152,102401,102435,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100175,100036,102437,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100175,100110,102438,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100175,102418,102439,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100175,102417,102440,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100174,102404,102441,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100174,102403,102442,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100174,100036,102444,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100174,100110,102445,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100174,102412,102446,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100174,102411,102447,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100178,102406,102448,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100178,102405,102449,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100178,100036,102451,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100178,100110,102452,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100178,102408,102453,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100178,102407,102454,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100178,102410,102455,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100178,102409,102456,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100178,102414,102457,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100178,102413,102458,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100178,102416,102459,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100178,102415,102460,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100178,102422,102461,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100178,102421,102462,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100177,102406,102463,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100177,102405,102464,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100177,100036,102466,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100177,100110,102467,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100177,102422,102468,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100177,102421,102469,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100173,100036,102471,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100173,100110,102472,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100173,102418,102473,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100173,102417,102474,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100105,102402,102475,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100105,102401,102476,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100105,102420,102477,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100105,102419,102478,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100176,100036,102480,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100176,100110,102481,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100176,102013,102482,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100176,100111,102483,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100176,102035,102484,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100176,102034,102485,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100176,102049,102486,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100176,102048,102487,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100176,102073,102488,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100176,102072,102489,null,null,null,100000,'Y','Y');

insert into  um.node_metric_jn values (100141,102001,null,null,null,null,100000,'Y','Y');
insert into  um.node_metric_jn values (100141,102401,null,null,null,null,100000,'Y','Y');
insert into  um.node_metric_jn values (100141,102003,null,null,null,null,100000,'Y','Y');
insert into  um.node_metric_jn values (100141,102002,null,null,null,null,100001,'Y','Y');
insert into  um.node_metric_jn values (100141,102402,null,null,null,null,100001,'Y','Y');
insert into  um.node_metric_jn values (100142,102117,null,null,null,null,100001,'Y','Y');
insert into  um.node_metric_jn values (100142,102419,null,null,null,null,100000,'Y','Y');
insert into  um.node_metric_jn values (100142,102420,null,null,null,null,100001,'Y','Y');
insert into  um.node_metric_jn values (100142,102116,null,null,null,null,100000,'Y','Y');
insert into  um.node_metric_jn values (100144,102402,null,null,null,null,100001,'Y','Y');
insert into  um.node_metric_jn values (100144,102003,null,null,null,null,100000,'Y','Y');
insert into  um.node_metric_jn values (100144,102002,null,null,null,null,100001,'Y','Y');
insert into  um.node_metric_jn values (100144,102001,null,null,null,null,100000,'Y','Y');
insert into  um.node_metric_jn values (100144,102401,null,null,null,null,100000,'Y','Y');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100203, 'ST_OTHER_SUSPENSE', 'Other Suspense');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100204, 'ST_OTHER_DISCARDED', 'Other Discarded');


update um.mrec_metric_ref mm
set    mm.node_id = 100171
where  mm.mrec_version_id = 100161
and    mm.node_id = 100170;

update um.mrec_metric_ref mm
set    mm.node_id = 100172
where  mm.mrec_version_id = 100162
and    mm.node_id = 100170;

update um.mrec_metric_ref mm
set    mm.node_id = 100176
where  mm.mrec_version_id = 100163
and    mm.node_id = 100170;



update um.mrec_metric_ref mm
set    mm.node_id = 100171
where  mm.mrec_version_id = 100165
and    mm.node_id = 100170;

update um.mrec_metric_ref mm
set    mm.node_id = 100172
where  mm.mrec_version_id = 100166
and    mm.node_id = 100170;

update um.mrec_metric_ref mm
set    mm.node_id = 100176
where  mm.mrec_version_id = 100167
and    mm.node_id = 100170;



update um.mrec_metric_ref mm
set    mm.node_id = 100171
where  mm.mrec_version_id = 100169
and    mm.node_id = 100170;

update um.mrec_metric_ref mm
set    mm.node_id = 100172
where  mm.mrec_version_id = 100170
and    mm.node_id = 100170;

update um.mrec_metric_ref mm
set    mm.node_id = 100176
where  mm.mrec_version_id = 100171
and    mm.node_id = 100170;




update um.mrec_metric_ref mm
set    mm.node_id = 100171
where  mm.mrec_version_id = 100173
and    mm.node_id = 100170;

update um.mrec_metric_ref mm
set    mm.node_id = 100172
where  mm.mrec_version_id = 100174
and    mm.node_id = 100170;

update um.mrec_metric_ref mm
set    mm.node_id = 100176
where  mm.mrec_version_id = 100175
and    mm.node_id = 100170;


insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102451, 'ST_DISCARDED - EDR Duration', 'ST_DISCARDED - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102452, 'ST_DISCARDED - EDR Duration (Daily)', 'ST_DISCARDED - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102453, 'ST_SUSPENSE - EDR Duration', 'ST_SUSPENSE - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102454, 'ST_SUSPENSE - EDR Duration (Daily)', 'ST_SUSPENSE - EDR Duration (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102455, 'ST_VOICE_DISCARDED - EDR Duration', 'ST_VOICE_DISCARDED - EDR Duration', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102456, 'ST_VOICE_DISCARDED - EDR Duration (Daily)', 'ST_VOICE_DISCARDED - EDR Duration (Daily)', 7, 100000, 100000);



insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102451, 102451, null, 'ST_DISCARDED - EDR Duration', to_date('27-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102452, 102452, null, 'ST_DISCARDED - EDR Duration (Daily)', to_date('27-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102453, 102453, null, 'ST_SUSPENSE - EDR Duration', to_date('27-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102454, 102454, null, 'ST_SUSPENSE - EDR Duration (Daily)', to_date('27-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102455, 102455, null, 'ST_VOICE_DISCARDED - EDR Duration', to_date('27-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102456, 102456, null, 'ST_VOICE_DISCARDED - EDR Duration (Daily)', to_date('27-10-2014', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');





insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102451, 100001, 102451);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102452, 100001, 102452);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102453, 100001, 102453);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102454, 100001, 102454);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102455, 100001, 102455);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102456, 100001, 102456);



insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102451, 102451, 4, 35127, 102451, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DISCARDED - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102452, 102452, 4, 35127, 102452, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DISCARDED - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102453, 102453, 4, 35127, 102453, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_SUSPENSE - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102454, 102454, 4, 35127, 102454, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_SUSPENSE - EDR Duration (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102455, 102455, 4, 35127, 102455, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DISCARDED - EDR Duration');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102456, 102456, 4, 35127, 102456, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_VOICE_DISCARDED - EDR Duration (Daily)');



insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102451, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100196', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102452, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100196', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102453, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100191', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102454, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100191', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102455, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100195', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102456, 'D', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100195', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');



commit;



update um.node_metric_jn nmj set nmj.threshold_definition_id = 102502 where nmj.node_id = 100141 and nmj.metric_definition_id = 102001;
update um.node_metric_jn nmj set nmj.threshold_definition_id = 102519 where nmj.node_id = 100144 and nmj.metric_definition_id = 102001;
update um.node_metric_jn nmj set nmj.threshold_definition_id = 102501 where nmj.node_id = 100141 and nmj.metric_definition_id = 102002;
update um.node_metric_jn nmj set nmj.threshold_definition_id = 102518 where nmj.node_id = 100144 and nmj.metric_definition_id = 102002;
update um.node_metric_jn nmj set nmj.threshold_definition_id = 102503 where nmj.node_id = 100141 and nmj.metric_definition_id = 102003;
update um.node_metric_jn nmj set nmj.threshold_definition_id = 102520 where nmj.node_id = 100144 and nmj.metric_definition_id = 102003;
update um.node_metric_jn nmj set nmj.threshold_definition_id = 102507 where nmj.node_id = 100142 and nmj.metric_definition_id = 102116;
update um.node_metric_jn nmj set nmj.threshold_definition_id = 102506 where nmj.node_id = 100142 and nmj.metric_definition_id = 102117;
update um.node_metric_jn nmj set nmj.threshold_definition_id = 102505 where nmj.node_id = 100141 and nmj.metric_definition_id = 102401;
update um.node_metric_jn nmj set nmj.threshold_definition_id = 102522 where nmj.node_id = 100144 and nmj.metric_definition_id = 102401;
update um.node_metric_jn nmj set nmj.threshold_definition_id = 102504 where nmj.node_id = 100141 and nmj.metric_definition_id = 102402;
update um.node_metric_jn nmj set nmj.threshold_definition_id = 102521 where nmj.node_id = 100144 and nmj.metric_definition_id = 102402;
update um.node_metric_jn nmj set nmj.threshold_definition_id = 102509 where nmj.node_id = 100142 and nmj.metric_definition_id = 102419;
update um.node_metric_jn nmj set nmj.threshold_definition_id = 102508 where nmj.node_id = 100142 and nmj.metric_definition_id = 102420;
insert into um.node_metric_jn values (100174,102451,102511,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100174,102452,102510,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100177,102453,102517,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100178,102453,102515,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100177,102454,102516,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100178,102454,102514,null,null,null,100001,'Y','Y');
insert into um.node_metric_jn values (100174,102455,102513,null,null,null,100000,'Y','Y');
insert into um.node_metric_jn values (100174,102456,102512,null,null,null,100001,'Y','Y');

commit;


insert into um.source_ref (SOURCE_ID, SOURCE_TYPE_ID, REGION_ID, SYSTEM_ID, COUNTRY_ID, NAME, IDENTIFIER)
values (100086, 100083, -1, -1, -1, 'BT WLR', 'BT WLR');

insert into um.source_ref (SOURCE_ID, SOURCE_TYPE_ID, REGION_ID, SYSTEM_ID, COUNTRY_ID, NAME, IDENTIFIER)
values (100087, 100082, -1, -1, -1, 'Eircom WLR', 'Eircom WLR');



insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100170, 'DS90', 100082);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100171, 'DS91', 100083);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100172, 'DS92', 100084);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100173, 'BT WLR', 100086);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100173, 'Eircom WLR', 100087);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100174, 'BT WLR', 100086);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100174, 'Eircom WLR', 100087);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100175, 'BT WLR', 100086);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100175, 'Eircom WLR', 100087);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100177, 'BT WLR', 100086);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100177, 'Eircom WLR', 100087);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100178, 'BT WLR', 100086);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100178, 'Eircom WLR', 100087);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100176, 'DS96', 100085);

commit;


insert into um.sql_ref (SQL_ID, SQL, SQL_TYPE, LABEL, DESCRIPTION)
values (100004, 'begin um.unload_old_ss_suspense; end;', 'GDL', 'Unload Previous SS suspense records', 'Unload Previous SS suspense records');

grant execute on um.unload_old_ss_suspense to gdl;

alter table um.f_file_staging modify edr_bytes number;
alter table um.f_file modify edr_bytes number;
alter table um.f_file_staging modify edr_value number;
alter table um.f_file modify edr_value number;

update um.cd_metric_ref
set    is_min = null,
       is_max = null,
       is_average = null,
       is_moving_average = null
where  instance_id between 100332 and 102374;

commit;

exit; 
