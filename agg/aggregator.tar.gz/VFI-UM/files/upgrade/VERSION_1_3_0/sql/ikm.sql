update ikm.jam_topic_version
set    version_content = replace(version_content,'[[Interconnect Guide|Interconnect]]','[[Interconnect Guide|Interconnect]]' || chr(10) || '<br>' || chr(10) || '* [[Fixed Line Guide|Fixed Line]]')
where  topic_version_id = 37028;

update ikm.jam_topic_version
set    version_content = replace(version_content,'[[Fixed Line Guide|FixedLine]]','[[Fixed Line Guide|FixedLine]]' || chr(10) || '<br>' || chr(10) || '* [Partners Guide|[MVNO/Wholesale Partners]]')
where  topic_version_id = 37028;

update ikm.jam_topic_version
set    version_content = replace(version_content,'* Introduction','* Introduction' || chr(10) || '<br>' || chr(10) || '* [[VFI Custom Screens|VFI Custom Screens]]')
where  topic_version_id = 37028;

update ikm.jam_topic_version
set    version_content = replace(version_content,'[[VFI Custom Screens|VFI Custom Screens]]','[[VFI Custom Screens|VFI Custom Screens]]' || chr(10) || '<br>' || chr(10) || '* [[VFI Operations Guide|VFI Operations]]')
where  topic_version_id = 37028;


update ikm.jam_topic_version
set    version_content = replace(version_content,'[[Interconnect Guide|Interconnect]]','[[Interconnect Guide|Interconnect]]' || chr(10) || '<br>' || chr(10) || '* [[Fixed Line Guide|Fixed Line]]')
where  topic_version_id = 37026;

update ikm.jam_topic_version
set    version_content = replace(version_content,'[[Fixed Line Guide|Fixed Line]]','[[Fixed Line Guide|Fixed Line]]' || chr(10) || '<br>' || chr(10) || '* [[Partners Guide|[MVNO/Wholesale Partners]]')
where  topic_version_id = 37026;

update ikm.jam_topic_version
set    version_content = replace(version_content,'* Introduction','* Introduction' || chr(10) || '<br>' || chr(10) || '* [[VFI Custom Screens|VFI Custom Screens]]')
where  topic_version_id = 37026;

update ikm.jam_topic_version
set    version_content = replace(version_content,'[[VFI Custom Screens|VFI Custom Screens]]','[[VFI Custom Screens|VFI Custom Screens]]' || chr(10) || '<br>' || chr(10) || '* [[VFI Operations Guide|VFI Operations]]')
where  topic_version_id = 37026;

commit;

exit
