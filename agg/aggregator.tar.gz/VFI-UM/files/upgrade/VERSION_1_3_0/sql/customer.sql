
create table customer.stg_agg_data_ds90
(
  CURRENTDIR      VARCHAR2(200),
  EDRFILENAME   VARCHAR2(100),
  NEID          VARCHAR2(100),
  UMIDENTIFIER  VARCHAR2(50),
  USAGETYPE     VARCHAR2(10),
  TIMESLOT      DATE,
  SERVICETYPE   VARCHAR2(100),
  EVENTCOUNT    INTEGER,
  SUMDURATION   INTEGER,
  SUMBYTES      NUMBER,
  SUMVALUE      NUMBER,
  LOG_RECORD_ID INTEGER,
  PROCESSDATE DATE
)
tablespace customer_data;

create table customer.stg_agg_data_ds91
(
  CURRENTDIR      VARCHAR2(200),
  EDRFILENAME   VARCHAR2(100),
  NEID          VARCHAR2(100),
  UMIDENTIFIER  VARCHAR2(50),
  USAGETYPE     VARCHAR2(10),
  TIMESLOT      DATE,
  SERVICETYPE   VARCHAR2(100),
  EVENTCOUNT    INTEGER,
  SUMDURATION   INTEGER,
  SUMBYTES      NUMBER,
  SUMVALUE      NUMBER,
  LOG_RECORD_ID INTEGER,
  PROCESSDATE DATE
)
tablespace customer_data;

create table customer.stg_agg_data_ds92
(
  CURRENTDIR      VARCHAR2(200),
  EDRFILENAME   VARCHAR2(100),
  NEID          VARCHAR2(100),
  UMIDENTIFIER  VARCHAR2(50),
  USAGETYPE     VARCHAR2(10),
  TIMESLOT      DATE,
  SERVICETYPE   VARCHAR2(100),
  EVENTCOUNT    INTEGER,
  SUMDURATION   INTEGER,
  SUMBYTES      NUMBER,
  SUMVALUE      NUMBER,
  LOG_RECORD_ID INTEGER,
  PROCESSDATE DATE
)
tablespace customer_data;

create table customer.stg_agg_data_ds93
(
  CURRENTDIR      VARCHAR2(200),
  EDRFILENAME   VARCHAR2(100),
  NEID          VARCHAR2(100),
  UMIDENTIFIER  VARCHAR2(50),
  USAGETYPE     VARCHAR2(10),
  TIMESLOT      DATE,
  SERVICETYPE   VARCHAR2(100),
  EVENTCOUNT    INTEGER,
  SUMDURATION   INTEGER,
  SUMBYTES      NUMBER,
  SUMVALUE      NUMBER,
  LOG_RECORD_ID INTEGER,
  PROCESSDATE DATE
)
tablespace customer_data;

create table customer.stg_agg_data_ds94
(
  CURRENTDIR      VARCHAR2(200),
  EDRFILENAME   VARCHAR2(100),
  NEID          VARCHAR2(100),
  UMIDENTIFIER  VARCHAR2(50),
  USAGETYPE     VARCHAR2(10),
  TIMESLOT      DATE,
  SERVICETYPE   VARCHAR2(100),
  EVENTCOUNT    INTEGER,
  SUMDURATION   INTEGER,
  SUMBYTES      NUMBER,
  SUMVALUE      NUMBER,
  LOG_RECORD_ID INTEGER,
  PROCESSDATE DATE
)
tablespace customer_data;

create table customer.stg_agg_data_ds95
(
  CURRENTDIR      VARCHAR2(200),
  EDRFILENAME   VARCHAR2(100),
  NEID          VARCHAR2(100),
  UMIDENTIFIER  VARCHAR2(50),
  USAGETYPE     VARCHAR2(10),
  TIMESLOT      DATE,
  SERVICETYPE   VARCHAR2(100),
  EVENTCOUNT    INTEGER,
  SUMDURATION   INTEGER,
  SUMBYTES      NUMBER,
  SUMVALUE      NUMBER,
  LOG_RECORD_ID INTEGER,
  PROCESSDATE DATE
)
tablespace customer_data;

create table customer.stg_agg_data_ds96
(
  CURRENTDIR      VARCHAR2(200),
  EDRFILENAME   VARCHAR2(100),
  NEID          VARCHAR2(100),
  UMIDENTIFIER  VARCHAR2(50),
  USAGETYPE     VARCHAR2(10),
  TIMESLOT      DATE,
  SERVICETYPE   VARCHAR2(100),
  EVENTCOUNT    INTEGER,
  SUMDURATION   INTEGER,
  SUMBYTES      NUMBER,
  SUMVALUE      NUMBER,
  LOG_RECORD_ID INTEGER,
  PROCESSDATE DATE
)
tablespace customer_data;

create table customer.stg_agg_data_ds98
(
  CURRENTDIR      VARCHAR2(200),
  EDRFILENAME   VARCHAR2(100),
  NEID          VARCHAR2(100),
  UMIDENTIFIER  VARCHAR2(50),
  USAGETYPE     VARCHAR2(10),
  TIMESLOT      DATE,
  SERVICETYPE   VARCHAR2(100),
  EVENTCOUNT    INTEGER,
  SUMDURATION   INTEGER,
  SUMBYTES      NUMBER,
  SUMVALUE      NUMBER,
  LOG_RECORD_ID INTEGER,
  PROCESSDATE DATE
)
tablespace customer_data;

create table customer.stg_agg_data_ds99
(
  CURRENTDIR      VARCHAR2(200),
  EDRFILENAME   VARCHAR2(100),
  NEID          VARCHAR2(100),
  UMIDENTIFIER  VARCHAR2(50),
  USAGETYPE     VARCHAR2(10),
  TIMESLOT      DATE,
  SERVICETYPE   VARCHAR2(100),
  EVENTCOUNT    INTEGER,
  SUMDURATION   INTEGER,
  SUMBYTES      NUMBER,
  SUMVALUE      NUMBER,
  LOG_RECORD_ID INTEGER,
  PROCESSDATE DATE
)
tablespace customer_data;


grant insert, update, references, select on customer.stg_agg_data_ds90 to gdl;
grant insert, update, references, select on customer.stg_agg_data_ds91 to gdl;
grant insert, update, references, select on customer.stg_agg_data_ds92 to gdl;
grant insert, update, references, select on customer.stg_agg_data_ds93 to gdl;
grant insert, update, references, select on customer.stg_agg_data_ds94 to gdl;
grant insert, update, references, select on customer.stg_agg_data_ds95 to gdl;
grant insert, update, references, select on customer.stg_agg_data_ds96 to gdl;
grant insert, update, references, select on customer.stg_agg_data_ds98 to gdl;
grant insert, update, references, select on customer.stg_agg_data_ds99 to gdl;


insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY)
values ('DS90', 'day', 25, 0.1, 1);

insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY)
values ('DS91', 'day', 25, 0.1, 1);

insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY)
values ('DS92', 'day', 25, 0.1, 1);

insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY)
values ('DS93', 'day', 25, 0.1, 1);

insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY)
values ('DS94', 'day', 25, 0.1, 1);

insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY)
values ('DS95', 'day', 25, 0.1, 1);

insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY)
values ('DS96', 'day', 25, 0.1, 1);

insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY)
values ('DS98', 'day', 25, 0.1, 1);

insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY)
values ('DS99', 'day', 25, 0.1, 1);


create table customer.partners (
      partner_id               integer,
      partner_name             varchar2(50),
      type                     varchar2(50),                                    
      description              varchar2(200),
      prefix                   varchar2(10),
      imsi_start_range         varchar2(20),
      imsi_end_range           varchar2(20),
      source_id                integer
);

alter table customer.partners add constraint partners_pk primary key (partner_id) ;
alter table customer.partners add constraint partners_uk_1 unique (partner_name) ;
alter table customer.partners add constraint partners_ck_1 check (type in ('MVNO','WHOLESALE')) ;
alter table customer.partners add constraint partners_fk_1 foreign key (source_id) references um.source_ref (source_id);
   
grant select, insert, delete, update on customer.partners to um;  
grant select, insert, delete, update on customer.partners to web;



insert into customer.partners (PARTNER_ID, PARTNER_NAME, TYPE, DESCRIPTION, PREFIX, IMSI_START_RANGE, IMSI_END_RANGE, SOURCE_ID)
values (1, 'Just Mobile', 'MVNO', 'Just Mobile', 'JM', '272011110000000', '272011119999999', 100072);

insert into customer.partners (PARTNER_ID, PARTNER_NAME, TYPE, DESCRIPTION, PREFIX, IMSI_START_RANGE, IMSI_END_RANGE, SOURCE_ID)
values (2, 'Postfone', 'MVNO', 'Postfone', 'AP', '272011100000000', '272011109999999', 100073);

insert into customer.partners (PARTNER_ID, PARTNER_NAME, TYPE, DESCRIPTION, PREFIX, IMSI_START_RANGE, IMSI_END_RANGE, SOURCE_ID)
values (3, 'e-Mobile', 'MVNO', 'e-Mobile', '', '272032000000000', '272032099999999', 100074);

insert into customer.partners (PARTNER_ID, PARTNER_NAME, TYPE, DESCRIPTION, PREFIX, IMSI_START_RANGE, IMSI_END_RANGE, SOURCE_ID)
values (4, 'Meteor  ', 'MVNO', 'Meteor  ', '', '272030000000000', '272039999999999', 100075);

insert into customer.partners (PARTNER_ID, PARTNER_NAME, TYPE, DESCRIPTION, PREFIX, IMSI_START_RANGE, IMSI_END_RANGE, SOURCE_ID)
values (5, 'Hutchinson', 'MVNO', 'Hutchinson', '', '272050000000000', '272059999999999', 100076);

insert into customer.partners (PARTNER_ID, PARTNER_NAME, TYPE, DESCRIPTION, PREFIX, IMSI_START_RANGE, IMSI_END_RANGE, SOURCE_ID)
values (6, 'Tesco', 'MVNO', 'Tesco', '', '272110000000000', '272119999999999', 100077);

insert into customer.partners (PARTNER_ID, PARTNER_NAME, TYPE, DESCRIPTION, PREFIX, IMSI_START_RANGE, IMSI_END_RANGE, SOURCE_ID)
values (7, 'Lyca Mobile', 'MVNO', 'Lyca Mobile', 'LY', '272130000000000', '272139999999999', 100078);

insert into customer.partners (PARTNER_ID, PARTNER_NAME, TYPE, DESCRIPTION, PREFIX, IMSI_START_RANGE, IMSI_END_RANGE, SOURCE_ID)
values (8, 'UPC', 'MVNO', 'UPC', '', '272150000000000', '272159999999999', 100079);

insert into customer.partners (PARTNER_ID, PARTNER_NAME, TYPE, DESCRIPTION, PREFIX, IMSI_START_RANGE, IMSI_END_RANGE, SOURCE_ID)
values (9, 'Carphone Warehouse', 'MVNO', 'Carphone Warehouse', '', '272160000000000', '272169999999999', 100080);


create or replace view customer.v_agg_partners as
select  partner_name, prefix, imsi_start_range, imsi_end_range, upper(replace(trim(partner_name),' ','_')) source_desc 
from	  customer.partners;


grant select, insert, delete, update on customer.v_agg_partners to web;

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100169);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100161);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100170);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100162);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100168);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100160);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100151);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100155);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100153);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100157);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100159);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100171);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100163);



commit;


 
alter table customer.STG_AGG_DATA_DS81 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS81 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS80 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS80 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS8 modify sumbytes number;  
alter table customer.STG_AGG_DATA_DS8 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS78 modify sumbytes number;  
alter table customer.STG_AGG_DATA_DS78 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS76 modify sumbytes number;  
alter table customer.STG_AGG_DATA_DS76 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS75 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS75 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS74 modify sumbytes number;  
alter table customer.STG_AGG_DATA_DS74 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS73 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS73 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS72 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS72 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS71 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS71 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS70 modify sumbytes number;  
alter table customer.STG_AGG_DATA_DS70 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS65 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS65 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS64 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS64 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS6 modify sumbytes number; 
alter table customer.STG_AGG_DATA_DS6 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS56 modify sumbytes number;  
alter table customer.STG_AGG_DATA_DS56 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS55 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS55 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS54 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS54 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS53 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS53 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS5 modify sumbytes number;  
alter table customer.STG_AGG_DATA_DS5 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS49 modify sumbytes number; 
alter table customer.STG_AGG_DATA_DS49 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS48 modify sumbytes number;  
alter table customer.STG_AGG_DATA_DS48 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS47 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS47 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS45 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS45 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS44 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS44 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS40 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS40 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS4 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS4 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS39 modify sumbytes number;  
alter table customer.STG_AGG_DATA_DS39 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS33 modify sumbytes number;  
alter table customer.STG_AGG_DATA_DS33 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS28 modify sumbytes number;  
alter table customer.STG_AGG_DATA_DS28 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS23 modify sumbytes number; 
 alter table customer.STG_AGG_DATA_DS23 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS21 modify sumbytes number;	
alter table customer.STG_AGG_DATA_DS21 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS20 modify sumbytes number;	
alter table customer.STG_AGG_DATA_DS20 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS12 modify sumbytes number;	
alter table customer.STG_AGG_DATA_DS12 modify sumvalue number;
alter table customer.STG_AGG_DATA_DS11 modify sumbytes number;	
alter table customer.STG_AGG_DATA_DS11 modify sumvalue number;


exit
