set scan off
set define off

-----------


insert into utils.ble_ref (BLE_ID, BLE_TYPE_ID, NAME, DESCRIPTION, DB_POOL)
values (100010, 35001, 'Add Source Data for MVNO & Wholesale Partners', 'Add Source Data for MVNO & Wholesale Partners', 'UMCP');

insert into utils.ble_version_ref (BLE_VERSION_ID, BLE_ID, NAME, DESCRIPTION, PARENT_VERSION_ID, STATUS, CREATOR_ID, CREATE_DATE, VALID_FROM, VALID_TO)
values (100010, 100010, 'Add Source Data for MVNO & Wholesale Partners', 'Add Source Data for MVNO & Wholesale Partners', null, 'A', 4000, to_date('03-10-2014', 'dd-mm-yyyy'), to_date('03-10-2014', 'dd-mm-yyyy'), to_date('01-10-2025', 'dd-mm-yyyy'));


insert into utils.ble_step_ref (BLE_STEP_ID, BLE_VERSION_ID, EXECUTION_ORDER, NAME, DESCRIPTION, SQL_STATEMENT, IS_COMMIT)
values (10001001, 100010, 1, 'Add partner sources', 'Add partner sources', '<CLOB>', 'N');


update utils.ble_step_ref
set    sql_statement = 
'declare ' ||
' ' ||
'	cursor c_new_partners is  ' ||
'	select 	partner_id, partner_name, type, upper(replace(trim(partner_name),'' '',''_'')) source_name ' ||
'	from	  customer.partners ' ||
'	where   source_id is null; ' ||
'   ' ||
'  cursor c_nodes is ' ||
'  select node_id ' ||
'  from   dgf.node_ref ' || 
'  where  description in (''DS20'',''DS28'',''DS39'',''DS4'',''DS55'',''DS6'',''DS72''); ' ||
'   ' ||
'	v_mvno_source_type_id CONSTANT number := 100100; ' ||
'  v_wholesale_source_type_id CONSTANT number := 100100; ' ||
' ' ||
'	v_new_source_id number; ' ||
'  v_source_id     number; ' ||
'  	 ' ||
'begin ' ||
' ' ||
'	v_new_source_id := 1; ' ||
' ' ||
'	for r_new_partners in c_new_partners loop ' ||
'	 ' ||
'    select nvl(max(source_id),-1) ' ||
'    into   v_source_id ' ||
'    from   um.source_ref s ' ||
'    where  s.name = r_new_partners.partner_name; ' ||
'   ' ||
'    if v_source_id > 0 then  ' ||
'   ' ||
'        v_new_source_id := v_source_id; ' ||
'    ' ||
'   else ' ||
'       ' ||
'        select max(source_id) + 1 ' ||
'        into	v_new_source_id ' ||
'        from	um.source_ref s ' ||
'        where  s.source_id < 200000; ' ||	    
'       ' ||
'        if r_new_partners.type = ''MVNO'' then ' ||
'            insert into um.source_ref values (v_new_source_id, v_mvno_source_type_id, -1, -1, -1, r_new_partners.partner_name, r_new_partners.source_name); ' ||
'        else ' ||
'            insert into um.source_ref values (v_new_source_id, v_wholesale_source_type_id, -1, -1, -1, r_new_partners.partner_name, r_new_partners.source_name); ' ||
'        end if; ' ||
'     ' ||
'    end if; ' ||
'      ' ||
'    for r_nodes in c_nodes loop         ' ||
'       ' ||
'         insert into um.source_desc_ref  ' ||
'         select r_nodes.node_id,r_new_partners.source_name,v_new_source_id ' ||
'         from   dual ' ||
'         where  not exists (select 1 ' ||
'                            from   um.source_desc_ref sd ' ||
'                            where  sd.node_id = r_nodes.node_id ' ||
'                            and    sd.source_description = r_new_partners.source_name); ' ||
'                             ' ||
'    end loop; ' ||
'         ' ||
'    update customer.partners p ' ||
'    set    p.source_id = v_new_source_id ' ||
'    where  p.partner_id = r_new_partners.partner_id; ' ||
'     ' ||
'    commit; ' ||
'	 ' ||
'	end loop; ' ||
' ' ||
'end;   ' 
where  BLE_STEP_ID = 10001001;



commit;
exit



