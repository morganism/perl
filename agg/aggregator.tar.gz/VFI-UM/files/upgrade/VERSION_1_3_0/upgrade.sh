#!/bin/bash

log="VFI-UM_1_3_0_upgrade_`date +\"%d%m%Y%H%M%S\"`.log"
echo "VFI-UM_1_3_0 `date`" > $log

# make sure ASCERTAIN_BUILD is set
if [ ! -e $ASCERTAIN_BUILD/upgrade/VERSION_1_3_0 ]; then
        echo "ASCERTAIN_BUILD needs to be set to the VFI_UM_1_3_0 build" 2>&1 | tee -a $log
        exit 1
fi


##############################################
#Check the current OS to choose right commands
#for options compatibility
##############################################
OS=`uname -a | grep Linux`
if [ "$OS" != "" ]; then
        ##Linux commands
        AWK_CMD="awk"
        DIFF_CMD="diff"
else
        #Solaris commands
        AWK_CMD="nawk"
        DIFF_CMD="sdiff"
fi

##############################################
# check to see that ASCERTAIN_BUILD is set
##############################################
if [ -z $ASCERTAIN_BUILD ]; then
  echo "ASCERTAIN_BUILD environment variable not set, aborting"  2>&1 | tee -a $log
  exit
fi

##############################################
# check to see that ORACLE_SID is set
##############################################
if [ -z $ORACLE_SID ]; then
  echo "ORACLE_SID environment variable not set, aborting"  2>&1 | tee -a $log
  exit
fi

##############################################
# check to see that CARTESIAN_PROPERTIES is set
##############################################
if [ -z $CARTESIAN_PROPERTIES ]; then
  echo "CARTESIAN_PROPERTIES environment variable not set, aborting"  2>&1 | tee -a $log
  exit
fi

##############################################
# function to get passwords from .cpm.xml
##############################################
setPasswords(){
  cpm=`grep CPM_CONFIG_FILE $CARTESIAN_PROPERTIES | $AWK_CMD '{print $2}' FS="\="`
  for line in $(egrep "(user=|password=)" $cpm) ; do
        lower_line=`echo $line | tr "[:upper:]" "[:lower:]"`
    eval "$lower_line"
    if [ "$password" != "" ] ; then
      eval "export ${user}_pass=\"$password\""
      user=""
      password=""
    fi
  done
}

##############################################
# load passwords using password function
##############################################
setPasswords

sqlplus um/$um_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/sql/procedures/um/unload_old_ss_suspense.prc
sqlplus dgf/$dgf_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/upgrade/VERSION_1_3_0/sql/dgf.sql
sqlplus gdl/$gdl_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/upgrade/VERSION_1_3_0/sql/gdl.sql
sqlplus imm/$imm_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/upgrade/VERSION_1_3_0/sql/imm.sql
sqlplus um/$um_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/upgrade/VERSION_1_3_0/sql/um.sql
sqlplus web/$web_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/upgrade/VERSION_1_3_0/sql/web.sql
sqlplus jobs/$web_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/upgrade/VERSION_1_3_0/sql/jobs.sql
sqlplus customer/$customer_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/upgrade/VERSION_1_3_0/sql/customer.sql
sqlplus utils/$utils_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/upgrade/VERSION_1_3_0/sql/utils.sql
sqlplus um/$um_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/sql/packages/um/volumetricrec.pck
sqlplus um/$um_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/sql/packages/um/VOLUMETRICREC_DAILY.pck
sqlplus customer/$customer_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/sql/procedures/customer/populate_um_staging.prc

chmod u+x ${ASCERTAIN_BUILD}/upgrade/VERSION_1_3_0/buildCustomReferenceData
${ASCERTAIN_BUILD}/upgrade/VERSION_1_3_0/buildCustomReferenceData ikm ${ikm_pass} JAM_TOPIC_VERSION
${ASCERTAIN_BUILD}/upgrade/VERSION_1_3_0/buildCustomReferenceData ikm ${ikm_pass} JAM_TOPIC
${ASCERTAIN_BUILD}/upgrade/VERSION_1_3_0/buildCustomReferenceData ikm ${ikm_pass} JAM_FILE
${ASCERTAIN_BUILD}/upgrade/VERSION_1_3_0/buildCustomReferenceData ikm ${ikm_pass} JAM_FILE_VERSION

sqlplus ikm/$ikm_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/upgrade/VERSION_1_3_0/sql/ikm.sql

$ASCERTAIN_BUILD/tools/perlPathScript.sh 

echo "VFI-UM_1_3_0 update complete" 2>&1 | tee -a $log
