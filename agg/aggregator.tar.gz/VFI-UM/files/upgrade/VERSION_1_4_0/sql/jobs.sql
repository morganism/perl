
insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100309, '(M) Import CCS Intermediate', '-daemon no -load_type 1 -mapping 100110', 5000);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100310, '(M) Import CCS Daily', '-daemon no -load_type 1 -mapping 100111', 5000);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100311, '(M) Import ICCS WAP (CCS)', '-daemon no -load_type 1 -mapping 100112', 5000);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100312, '(M) Import ICCS GPRS (CCS)', '-daemon no -load_type 1 -mapping 100113', 5000);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100313, '(M) Import ICCS Billed', '-daemon no -load_type 1 -mapping 100114', 5000);



insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100579, '(M) Node DS83', '-node 100180 -node_id 100180 -daemon no -offset 1 --terminatetime 23:59:59', 1);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100580, '(M) Node DS84', '-node 100181 -node_id 100181 -daemon no -offset 1 --terminatetime 23:59:59', 1);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100581, '(M) Node DS7', '-node 100182 -node_id 100182 -daemon no -offset 1 --terminatetime 23:59:59', 1);


insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (101580, '(M) Node Matching DS83', '', 1);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (101581, '(M) Node Matching DS84', '', 1);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (101582, '(M) Node Matching DS85', '', 1);


insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105258, '(M) CCS Intermediate vs CCS Daily (value) . ST_ALL . EDR Value', '-mrec_id 100182 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105259, '(M) CCS Intermediate vs CCS Daily (value) . ST_ALL . EDR Bytes', '-mrec_id 100183 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105260, '(M) CCS Intermediate vs CCS Daily (value) . ST_ALL . EDR Count', '-mrec_id 100184 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105261, '(M) CCS vs WAP ICCS (bytes) . ST_DATA_WAP_POSTPAID . EDR Bytes (Daily)', '-mrec_id 100185 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105262, '(M) CCS  vs GPRS ICCS (bytes) . ST_DATA_GPRS_POSTPAID . EDR Bytes (Daily)', '-mrec_id 100186 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105263, '(M) CCS Intermediate vs CCS Daily (value) . ST_ALL . EDR Value (Daily)', '-mrec_id 100187 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105264, '(M) GPRS ICCS vs ICCS Billed (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily)', '-mrec_id 100188 -num_days 59 -offset 60', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105265, '(M) WAP ICCS vs ICCS Billed (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily)', '-mrec_id 100189 -num_days 59 -offset 60', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105266, '(M) CCS vs WAP ICCS (bytes) .ST_DATA _STRIP . EDR Bytes (Daily)', '-mrec_id 100190 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105267, '(M) CCS vs GPRS ICCS (bytes) .ST_DATA _STRIP . EDR Bytes (Daily)', '-mrec_id 100191 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (118142, '(M) Node Metrics DS83', '-node 100180', 35002);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (118143, '(M) Node Metrics DS84', '-node 100181', 35002);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (118144, '(M) Node Metrics DS7', '-node 100182', 35002);


update jobs.multi_job_ref
set    description = '(M) Node DS39/DS85'
where  multi_job_ref_id = 100554;

update jobs.multi_job_ref
set    description = '(M) Node DS55/DS86'
where  multi_job_ref_id = 100551;

update jobs.multi_job_ref
set    description = '(M) Node Matching DS55/DS86'
where  multi_job_ref_id = 101551;

update jobs.multi_job_ref
set    description = '(M) Node Matching DS39/DS85'
where  multi_job_ref_id = 101551;
	
update jobs.multi_job_ref
set    description = '(M) Node Metrics DS39/DS85'
where  multi_job_ref_id = 108108;	

update jobs.multi_job_ref
set    description = '(M) Node Metrics DS55/DS86'
where  multi_job_ref_id = 108118;

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (102309, 100309, null, 5000);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (102310, 100310, null, 5000);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (102311, 100311, null, 5000);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (102312, 100312, null, 5000);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (102313, 100313, null, 5000);


insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (110309, 102000, 100309, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (110310, 102000, 100310, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (110311, 102000, 100311, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (110312, 102000, 100312, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (110313, 102000, 100313, null);



insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (110309, 100308);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (110310, 110309);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (110311, 110310);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (110312, 110311);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (110313, 110312);



insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100579, 104000, 100579, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100580, 104000, 100580, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100581, 104000, 100581, null);



insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104549, 100579, null, 100400);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104548, 100579, null, 35105);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100779, 100579, 101580, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104551, 100580, null, 100400);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104550, 100580, null, 35105);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100780, 100580, 101581, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104553, 100581, null, 100400);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104552, 100581, null, 35105);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100781, 100581, 101582, null);


insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100779, 104549);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100780, 104551);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100781, 104553);



insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (104547, 104546);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (104549, 104548);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (104551, 104550);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (104553, 104552);



insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105457, 105000, 105258, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105458, 105000, 105259, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105459, 105000, 105260, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105460, 105000, 105261, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105461, 105000, 105262, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105462, 105000, 105263, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105463, 105000, 105264, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105464, 105000, 105265, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105465, 105000, 105266, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105466, 105000, 105267, null);



insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105368, 105258, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105369, 105259, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105370, 105260, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105371, 105261, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105372, 105262, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105373, 105263, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105374, 105264, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105375, 105265, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105376, 105266, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105377, 105267, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (128142, 108000, 118142, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (128143, 108000, 118143, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (128144, 108000, 118144, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (118142, 118142, null, 35105);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (118143, 118143, null, 35105);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (118144, 118144, null, 35105);


insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (109127, 101580, null, 100401);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (109128, 101580, null, 100402);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (109129, 101580, null, 100403);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (109130, 101581, null, 100401);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (109131, 101581, null, 100402);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (109132, 101581, null, 100403);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (109133, 101582, null, 100401);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (109134, 101582, null, 100402);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (109135, 101582, null, 100403);



commit;

exit
