
insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY, CAP)
values ('DS83', 'day', 1440, 0.1, 1, 21);

insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY, CAP)
values ('DS84', 'day', 1, 0.1, 1, 21);

insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY, CAP)
values ('DS7', 'month', 1, 0.1, 1, 60);



create table customer.stg_agg_data_ds83
(
  CURRENTDIR      VARCHAR2(200),
  EDRFILENAME   VARCHAR2(100),
  NEID          VARCHAR2(100),
  UMIDENTIFIER  VARCHAR2(50),
  USAGETYPE     VARCHAR2(10),
  TIMESLOT      DATE,
  SERVICETYPE   VARCHAR2(100),
  EVENTCOUNT    INTEGER,
  SUMDURATION   INTEGER,
  SUMBYTES      INTEGER,
  SUMVALUE      INTEGER,
  LOG_RECORD_ID INTEGER,
  PROCESSDATE DATE
)
tablespace customer_data;

create table customer.stg_agg_data_ds84
(
  CURRENTDIR      VARCHAR2(200),
  EDRFILENAME   VARCHAR2(100),
  NEID          VARCHAR2(100),
  UMIDENTIFIER  VARCHAR2(50),
  USAGETYPE     VARCHAR2(10),
  TIMESLOT      DATE,
  SERVICETYPE   VARCHAR2(100),
  EVENTCOUNT    INTEGER,
  SUMDURATION   INTEGER,
  SUMBYTES      INTEGER,
  SUMVALUE      INTEGER,
  LOG_RECORD_ID INTEGER,
  PROCESSDATE DATE
)
tablespace customer_data;


create table customer.stg_agg_data_ds85
(
  CURRENTDIR      VARCHAR2(200),
  EDRFILENAME   VARCHAR2(100),
  NEID          VARCHAR2(100),
  UMIDENTIFIER  VARCHAR2(50),
  USAGETYPE     VARCHAR2(10),
  TIMESLOT      DATE,
  SERVICETYPE   VARCHAR2(100),
  EVENTCOUNT    INTEGER,
  SUMDURATION   INTEGER,
  SUMBYTES      INTEGER,
  SUMVALUE      INTEGER,
  LOG_RECORD_ID INTEGER,
  PROCESSDATE DATE
)
tablespace customer_data;

create table customer.stg_agg_data_ds86
(
  CURRENTDIR      VARCHAR2(200),
  EDRFILENAME   VARCHAR2(100),
  NEID          VARCHAR2(100),
  UMIDENTIFIER  VARCHAR2(50),
  USAGETYPE     VARCHAR2(10),
  TIMESLOT      DATE,
  SERVICETYPE   VARCHAR2(100),
  EVENTCOUNT    INTEGER,
  SUMDURATION   INTEGER,
  SUMBYTES      INTEGER,
  SUMVALUE      INTEGER,
  LOG_RECORD_ID INTEGER,
  PROCESSDATE DATE
)
tablespace customer_data;

create table customer.stg_agg_data_ds7
(
  CURRENTDIR      VARCHAR2(200),
  EDRFILENAME   VARCHAR2(100),
  NEID          VARCHAR2(100),
  UMIDENTIFIER  VARCHAR2(50),
  USAGETYPE     VARCHAR2(10),
  TIMESLOT      DATE,
  SERVICETYPE   VARCHAR2(100),
  EVENTCOUNT    INTEGER,
  SUMDURATION   INTEGER,
  SUMBYTES      INTEGER,
  SUMVALUE      INTEGER,
  LOG_RECORD_ID INTEGER,
  PROCESSDATE DATE
)
tablespace customer_data;


grant insert, update, references, select on customer.stg_agg_data_ds83 to gdl;
grant insert, update, references, select on customer.stg_agg_data_ds84 to gdl;
grant insert, update, references, select on customer.stg_agg_data_ds85 to gdl;
grant insert, update, references, select on customer.stg_agg_data_ds86 to gdl;
grant insert, update, references, select on customer.stg_agg_data_ds7 to gdl;


commit;




alter table customer.data_feed_frequency_ref add node_id number;

update customer.data_feed_frequency_ref c
set    node_id = (select node_id
                  from   dgf.node_ref n
                  where c.node = n.description );
                
  
insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY, CAP, NODE_ID)
values ('DS85', 'day', 6, 0.1, 1, 21, 100144);

insert into customer.data_feed_frequency_ref (NODE, ALARM_PERIOD_TYPE, EXPECTED_FILES_PER_PERIOD, ALARM_THRESHOLD, LATENCY, CAP, NODE_ID)
values ('DS86', 'day', 144, 0.1, 2, 21, 100141);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100185);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100192);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100188);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100190);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100189);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100187);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100186);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100193);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100191);

insert into customer.daily_mrecs (MREC_DEFINITION_ID)
values (100181);



commit;

exit
