set define off

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100210, 'ST_DATA_STRIP', 'Stripped Data');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100211, 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP', 'Stripped Data GPRS Roamers');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100212, 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP', 'Stripped Data WAP Roamers');

insert into um.d_custom_01 (D_CUSTOM_01_ID, CUSTOM_TYPE, DESCRIPTION)
values (100213, 'ST_DATA', 'Data');



insert into um.source_type_ref (SOURCE_TYPE_ID, SOURCE_TYPE, DESCRIPTION)
values (100090, 'CCS AMA', 'CCS AMA');



insert into um.source_ref (SOURCE_ID, SOURCE_TYPE_ID, REGION_ID, SYSTEM_ID, COUNTRY_ID, NAME, IDENTIFIER)
values (100090, 100090, -1, -1, -1, 'CCS AMA', 'CCS AMA');



insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100180, 'CCS', 100090);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100181, 'CCS', 100090);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100182, 'DS7', 100006);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100144, 'CCS', 100090);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100141, 'CCS', 100090);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100144, 'EMM', 100090);

insert into um.source_desc_ref (NODE_ID, SOURCE_DESCRIPTION, SOURCE_ID)
values (100141, 'EMM', 100090);


insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102501, 'ST_ALL - EDR Bytes (Daily)', 'ST_ALL - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102502, 'ST_ALL - EDR Count (Daily)', 'ST_ALL - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102503, 'ST_ALL - EDR Value (Daily)', 'ST_ALL - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102504, 'ST_DATA - EDR Bytes', 'ST_DATA - EDR Bytes', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102505, 'ST_DATA - EDR Bytes (Daily)', 'ST_DATA - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102506, 'ST_DATA - EDR Count', 'ST_DATA - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102507, 'ST_DATA - EDR Count (Daily)', 'ST_DATA - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102508, 'ST_DATA - EDR Value', 'ST_DATA - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102509, 'ST_DATA - EDR Value (Daily)', 'ST_DATA - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102510, 'ST_DATA_2G - EDR Bytes (Daily)', 'ST_DATA_2G - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102511, 'ST_DATA_2G - EDR Count (Daily)', 'ST_DATA_2G - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102512, 'ST_DATA_2G - EDR Value (Daily)', 'ST_DATA_2G - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102513, 'ST_DATA_3G - EDR Bytes (Daily)', 'ST_DATA_3G - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102514, 'ST_DATA_3G - EDR Count (Daily)', 'ST_DATA_3G - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102515, 'ST_DATA_3G - EDR Value (Daily)', 'ST_DATA_3G - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102516, 'ST_DATA_4G - EDR Bytes (Daily)', 'ST_DATA_4G - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102517, 'ST_DATA_4G - EDR Count (Daily)', 'ST_DATA_4G - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102518, 'ST_DATA_4G - EDR Value (Daily)', 'ST_DATA_4G - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102519, 'ST_DATA_GPRS - EDR Bytes (Daily)', 'ST_DATA_GPRS - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102520, 'ST_DATA_GPRS - EDR Count (Daily)', 'ST_DATA_GPRS - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102521, 'ST_DATA_GPRS - EDR Value (Daily)', 'ST_DATA_GPRS - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102522, 'ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value', 'ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102523, 'ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value (Daily)', 'ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102524, 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Bytes', 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Bytes', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102525, 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Bytes (Daily)', 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102526, 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Count', 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102527, 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Count (Daily)', 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102528, 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Value', 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102529, 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Value (Daily)', 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102530, 'ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily)', 'ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102531, 'ST_DATA_GPRS_POSTPAID - EDR Count (Daily)', 'ST_DATA_GPRS_POSTPAID - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102532, 'ST_DATA_GPRS_POSTPAID - EDR Value (Daily)', 'ST_DATA_GPRS_POSTPAID - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102533, 'ST_DATA_STRIP - EDR Bytes', 'ST_DATA_STRIP - EDR Bytes', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102534, 'ST_DATA_STRIP - EDR Bytes (Daily)', 'ST_DATA_STRIP - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102535, 'ST_DATA_STRIP - EDR Count', 'ST_DATA_STRIP - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102536, 'ST_DATA_STRIP - EDR Count (Daily)', 'ST_DATA_STRIP - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102537, 'ST_DATA_STRIP - EDR Value', 'ST_DATA_STRIP - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102538, 'ST_DATA_STRIP - EDR Value (Daily)', 'ST_DATA_STRIP - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102539, 'ST_DATA_WAP - EDR Bytes (Daily)', 'ST_DATA_WAP - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102540, 'ST_DATA_WAP - EDR Count (Daily)', 'ST_DATA_WAP - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102541, 'ST_DATA_WAP - EDR Value (Daily)', 'ST_DATA_WAP - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102542, 'ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value', 'ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102543, 'ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value (Daily)', 'ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102544, 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Bytes', 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Bytes', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102545, 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Bytes (Daily)', 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102546, 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Count', 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Count', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102547, 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Count (Daily)', 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102548, 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Value', 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Value', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102549, 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Value (Daily)', 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102550, 'ST_DATA_WAP_POSTPAID - EDR Bytes (Daily)', 'ST_DATA_WAP_POSTPAID - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102551, 'ST_DATA_WAP_POSTPAID - EDR Count (Daily)', 'ST_DATA_WAP_POSTPAID - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102552, 'ST_DATA_WAP_POSTPAID - EDR Value (Daily)', 'ST_DATA_WAP_POSTPAID - EDR Value (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102553, 'ST_UNIDENT - EDR Bytes (Daily)', 'ST_UNIDENT - EDR Bytes (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102554, 'ST_UNIDENT - EDR Count (Daily)', 'ST_UNIDENT - EDR Count (Daily)', 7, 100000, 100000);

insert into um.metric_definition_ref (METRIC_DEFINITION_ID, NAME, DESCRIPTION, THRESHOLD_REAPPLY_PERIOD, METRIC_TYPE_ID, METRIC_CATEGORY_ID)
values (102555, 'ST_UNIDENT - EDR Value (Daily)', 'ST_UNIDENT - EDR Value (Daily)', 7, 100000, 100000);



insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102501, 102501, null, 'ST_ALL - EDR Bytes (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102502, 102502, null, 'ST_ALL - EDR Count (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102503, 102503, null, 'ST_ALL - EDR Value (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102504, 102504, null, 'ST_DATA - EDR Bytes', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102505, 102505, null, 'ST_DATA - EDR Bytes (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102506, 102506, null, 'ST_DATA - EDR Count', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102507, 102507, null, 'ST_DATA - EDR Count (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102508, 102508, null, 'ST_DATA - EDR Value', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102509, 102509, null, 'ST_DATA - EDR Value (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102510, 102510, null, 'ST_DATA_2G - EDR Bytes (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102511, 102511, null, 'ST_DATA_2G - EDR Count (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102512, 102512, null, 'ST_DATA_2G - EDR Value (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102513, 102513, null, 'ST_DATA_3G - EDR Bytes (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102514, 102514, null, 'ST_DATA_3G - EDR Count (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102515, 102515, null, 'ST_DATA_3G - EDR Value (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102516, 102516, null, 'ST_DATA_4G - EDR Bytes (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102517, 102517, null, 'ST_DATA_4G - EDR Count (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102518, 102518, null, 'ST_DATA_4G - EDR Value (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102519, 102519, null, 'ST_DATA_GPRS - EDR Bytes (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102520, 102520, null, 'ST_DATA_GPRS - EDR Count (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102521, 102521, null, 'ST_DATA_GPRS - EDR Value (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102522, 102522, null, 'ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102523, 102523, null, 'ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102524, 102524, null, 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Bytes', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102525, 102525, null, 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Bytes (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102526, 102526, null, 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Count', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102527, 102527, null, 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Count (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102528, 102528, null, 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Value', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102529, 102529, null, 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Value (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102530, 102530, null, 'ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102531, 102531, null, 'ST_DATA_GPRS_POSTPAID - EDR Count (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102532, 102532, null, 'ST_DATA_GPRS_POSTPAID - EDR Value (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102533, 102533, null, 'ST_DATA_STRIP - EDR Bytes', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102534, 102534, null, 'ST_DATA_STRIP - EDR Bytes (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102535, 102535, null, 'ST_DATA_STRIP - EDR Count', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102536, 102536, null, 'ST_DATA_STRIP - EDR Count (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102537, 102537, null, 'ST_DATA_STRIP - EDR Value', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102538, 102538, null, 'ST_DATA_STRIP - EDR Value (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102539, 102539, null, 'ST_DATA_WAP - EDR Bytes (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102540, 102540, null, 'ST_DATA_WAP - EDR Count (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102541, 102541, null, 'ST_DATA_WAP - EDR Value (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102542, 102542, null, 'ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102543, 102543, null, 'ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102544, 102544, null, 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Bytes', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102545, 102545, null, 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Bytes (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102546, 102546, null, 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Count', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102547, 102547, null, 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Count (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102548, 102548, null, 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Value', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102549, 102549, null, 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Value (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102550, 102550, null, 'ST_DATA_WAP_POSTPAID - EDR Bytes (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102551, 102551, null, 'ST_DATA_WAP_POSTPAID - EDR Count (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102552, 102552, null, 'ST_DATA_WAP_POSTPAID - EDR Value (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102553, 102553, null, 'ST_UNIDENT - EDR Bytes (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102554, 102554, null, 'ST_UNIDENT - EDR Count (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');

insert into um.metric_version_ref (METRIC_VERSION_ID, METRIC_DEFINITION_ID, PARENT_VERSION_ID, DESCRIPTION, VALID_FROM, VALID_TO, STATUS)
values (102555, 102555, null, 'ST_UNIDENT - EDR Value (Daily)', to_date('15-02-2015', 'dd-mm-yyyy'), to_date('31-12-2020 23:59:59', 'dd-mm-yyyy hh24:mi:ss'), 'A');



insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102501, 100001, 102501);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102502, 100001, 102502);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102503, 100001, 102503);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102504, 100001, 102504);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102505, 100001, 102505);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102506, 100001, 102506);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102507, 100001, 102507);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102508, 100001, 102508);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102509, 100001, 102509);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102510, 100001, 102510);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102511, 100001, 102511);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102512, 100001, 102512);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102513, 100001, 102513);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102514, 100001, 102514);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102515, 100001, 102515);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102516, 100001, 102516);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102517, 100001, 102517);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102518, 100001, 102518);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102519, 100001, 102519);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102520, 100001, 102520);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102521, 100001, 102521);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102522, 100001, 102522);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102523, 100001, 102523);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102524, 100001, 102524);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102525, 100001, 102525);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102526, 100001, 102526);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102527, 100001, 102527);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102528, 100001, 102528);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102529, 100001, 102529);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102530, 100001, 102530);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102531, 100001, 102531);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102532, 100001, 102532);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102533, 100001, 102533);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102534, 100001, 102534);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102535, 100001, 102535);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102536, 100001, 102536);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102537, 100001, 102537);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102538, 100001, 102538);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102539, 100001, 102539);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102540, 100001, 102540);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102541, 100001, 102541);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102542, 100001, 102542);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102543, 100001, 102543);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102544, 100001, 102544);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102545, 100001, 102545);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102546, 100001, 102546);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102547, 100001, 102547);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102548, 100001, 102548);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102549, 100001, 102549);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102550, 100001, 102550);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102551, 100001, 102551);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102552, 100001, 102552);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102553, 100001, 102553);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102554, 100001, 102554);

insert into um.forecast_metric_jn (FORECAST_METRIC_ID, FORECAST_DEFINITION_ID, METRIC_DEFINITION_ID)
values (102555, 100001, 102555);



insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102501, 102501, 10, 35127, 102501, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_ALL - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102502, 102502, 13, 35127, 102502, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_ALL - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102503, 102503, 3, 35127, 102503, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_ALL - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102504, 102504, 10, 35127, 102504, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA - EDR Bytes');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102505, 102505, 10, 35127, 102505, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102506, 102506, 13, 35127, 102506, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102507, 102507, 13, 35127, 102507, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102508, 102508, 3, 35127, 102508, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102509, 102509, 3, 35127, 102509, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102510, 102510, 10, 35127, 102510, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_2G - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102511, 102511, 13, 35127, 102511, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_2G - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102512, 102512, 3, 35127, 102512, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_2G - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102513, 102513, 10, 35127, 102513, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_3G - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102514, 102514, 13, 35127, 102514, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_3G - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102515, 102515, 3, 35127, 102515, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_3G - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102516, 102516, 10, 35127, 102516, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_4G - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102517, 102517, 13, 35127, 102517, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_4G - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102518, 102518, 3, 35127, 102518, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_4G - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102519, 102519, 10, 35127, 102519, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_GPRS - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102520, 102520, 13, 35127, 102520, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_GPRS - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102521, 102521, 3, 35127, 102521, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_GPRS - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102522, 102522, 3, 35127, 102522, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102523, 102523, 3, 35127, 102523, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102524, 102524, 10, 35127, 102524, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Bytes');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102525, 102525, 10, 35127, 102525, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102526, 102526, 13, 35127, 102526, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102527, 102527, 13, 35127, 102527, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102528, 102528, 3, 35127, 102528, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102529, 102529, 3, 35127, 102529, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102530, 102530, 10, 35127, 102530, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102531, 102531, 13, 35127, 102531, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_GPRS_POSTPAID - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102532, 102532, 3, 35127, 102532, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_GPRS_POSTPAID - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102533, 102533, 10, 35127, 102533, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_STRIP - EDR Bytes');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102534, 102534, 10, 35127, 102534, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_STRIP - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102535, 102535, 13, 35127, 102535, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_STRIP - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102536, 102536, 13, 35127, 102536, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_STRIP - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102537, 102537, 3, 35127, 102537, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_STRIP - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102538, 102538, 3, 35127, 102538, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_STRIP - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102539, 102539, 10, 35127, 102539, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_WAP - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102540, 102540, 13, 35127, 102540, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_WAP - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102541, 102541, 3, 35127, 102541, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_WAP - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102542, 102542, 3, 35127, 102542, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102543, 102543, 3, 35127, 102543, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102544, 102544, 10, 35127, 102544, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Bytes');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102545, 102545, 10, 35127, 102545, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102546, 102546, 13, 35127, 102546, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Count');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102547, 102547, 13, 35127, 102547, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102548, 102548, 3, 35127, 102548, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Value');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102549, 102549, 3, 35127, 102549, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102550, 102550, 10, 35127, 102550, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_WAP_POSTPAID - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102551, 102551, 13, 35127, 102551, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_WAP_POSTPAID - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102552, 102552, 3, 35127, 102552, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_DATA_WAP_POSTPAID - EDR Value (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102553, 102553, 10, 35127, 102553, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_UNIDENT - EDR Bytes (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102554, 102554, 13, 35127, 102554, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_UNIDENT - EDR Count (Daily)');

insert into um.metric_operator_ref (METRIC_OPERATOR_ID, METRIC_VERSION_ID, UNIT_ID, OPERATOR_DEFINITION_ID, FORECAST_METRIC_ID, OPERATOR_ORDER, PARAMETERS, DESCRIPTION)
values (102555, 102555, 3, 35127, 102555, 1, '-syncOnMerge no -function sum -debug no -switch_to_raw no -threads 1 -distinct_filenames no', 'ST_UNIDENT - EDR Value (Daily)');



insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102501, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102502, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102503, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102504, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100213', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102505, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100213', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102506, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100213', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102507, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100213', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102508, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100213', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102509, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100213', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102510, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100076', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102511, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100076', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102512, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100076', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102513, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100077', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102514, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100077', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102515, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100077', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102516, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100078', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102517, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100078', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102518, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100078', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102519, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100040', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102520, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100040', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102521, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100040', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102522, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100142', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102523, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100142', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102524, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100211', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102525, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100211', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102526, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100211', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102527, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100211', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102528, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100211', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102529, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100211', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102530, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100043', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102531, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100043', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102532, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100043', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102533, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100210', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102534, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100210', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102535, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100210', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102536, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100210', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102537, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100210', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102538, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100210', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102539, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100041', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102540, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100041', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102541, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100041', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102542, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100143', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102543, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100143', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102544, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100212', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102545, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100212', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102546, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100212', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102547, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100212', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102548, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100212', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102549, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100212', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102550, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100045', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102551, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100045', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102552, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100045', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102553, 'B', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100052', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102554, 'C', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100052', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

insert into um.fmo_equation (METRIC_OPERATOR_ID, FIELD_TYPE, OPERATOR, ADJUSTER, SOURCE_ID, SOURCE_TYPE_ID, I_D_MEASURE_TYPE_ID, J_D_MEASURE_TYPE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, D_PAYMENT_TYPE_ID, D_CALL_TYPE_ID, D_CUSTOMER_TYPE_ID, D_SERVICE_PROVIDER_ID, D_CUSTOM_01_LIST, D_CUSTOM_02_LIST, D_CUSTOM_03_LIST, D_CUSTOM_04_LIST, D_CUSTOM_05_LIST, D_CUSTOM_06_LIST, D_CUSTOM_07_LIST, D_CUSTOM_08_LIST, D_CUSTOM_09_LIST, D_CUSTOM_10_LIST, D_CUSTOM_11_LIST, D_CUSTOM_12_LIST, D_CUSTOM_13_LIST, D_CUSTOM_14_LIST, D_CUSTOM_15_LIST, D_CUSTOM_16_LIST, D_CUSTOM_17_LIST, D_CUSTOM_18_LIST, D_CUSTOM_19_LIST, D_CUSTOM_20_LIST)
values (102555, 'V', 'Sum', null, null, null, 100, null, null, null, null, null, null, null, '100052', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');


insert into um.node_metric_jn values (100181,100800,102601,null,null,null,100002, 'Y','Y');
insert into um.node_metric_jn values (100181,102501,102602,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100181,102603,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102502,102604,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100000,102605,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102503,102606,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100102,102607,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102505,102608,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,102504,102609,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102507,102610,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,102506,102611,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102509,102612,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,102508,102613,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102510,102614,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100442,102615,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102511,102616,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100441,102617,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102512,102618,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100444,102619,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102513,102620,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100446,102621,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102514,102622,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100445,102623,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102515,102624,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100448,102625,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102516,102626,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100450,102627,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102517,102628,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100449,102629,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102518,102630,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100452,102631,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102519,102632,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100271,102633,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102520,102634,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100025,102635,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102521,102636,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100382,102637,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,100634,102638,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100534,102639,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,100669,102640,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100569,102641,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102523,102642,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,102522,102643,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102530,102644,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100272,102645,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102531,102646,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100264,102647,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102532,102648,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100383,102649,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102539,102650,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100274,102651,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102540,102652,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100042,102653,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102541,102654,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100384,102655,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,100635,102656,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100535,102657,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,100673,102658,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100573,102659,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102543,102660,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,102542,102661,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102550,102662,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100182,102663,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102551,102664,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100179,102665,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,102552,102666,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,100385,102667,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100180,100800,102668,null,null,null,100002, 'Y','Y');
insert into um.node_metric_jn values (100180,102501,102669,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100180,100181,102670,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100180,102502,102671,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100180,100000,102672,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100180,102503,102673,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100180,100102,102674,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100180,102505,102675,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100180,102504,102676,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100180,102507,102677,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100180,102506,102678,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100180,102509,102679,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100180,102508,102680,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100180,102519,102681,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100180,100271,102682,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100180,102520,102683,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100180,100025,102684,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100180,102521,102685,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100180,100382,102686,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100180,102539,102687,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100180,100274,102688,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100180,102540,102689,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100180,100042,102690,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100180,102541,102691,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100180,100384,102692,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100141,100634,102693,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100141,100534,102694,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100141,100669,102695,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100141,100569,102696,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100141,102523,102697,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100141,102522,102698,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100141,102525,102699,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100141,102524,102700,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100141,102527,102701,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100141,102526,102702,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100141,102529,102703,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100141,102528,102704,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100141,102534,102705,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100141,102533,102706,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100141,102536,102707,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100141,102535,102708,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100141,102538,102709,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100141,102537,102710,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,100800,102711,null,null,null,100002, 'Y','Y');
insert into um.node_metric_jn values (100182,102501,102712,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,100181,102713,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102502,102714,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,100000,102715,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102503,102716,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,100102,102717,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102505,102718,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,102504,102719,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102507,102720,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,102506,102721,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102509,102722,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,102508,102723,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102519,102724,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,100271,102725,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102520,102726,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,100025,102727,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102521,102728,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,100382,102729,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102530,102730,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,100272,102731,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102531,102732,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,100264,102733,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102532,102734,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,100383,102735,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102332,102736,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,102331,102737,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102334,102738,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,102333,102739,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102336,102740,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,102335,102741,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102338,102742,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,102337,102743,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102340,102744,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,102339,102745,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102342,102746,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,102341,102747,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102539,102748,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,100274,102749,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102540,102750,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,100042,102751,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102541,102752,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,100384,102753,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102550,102754,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,100182,102755,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102551,102756,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,100179,102757,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,102552,102758,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,100385,102759,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100144,102534,102760,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100144,102533,102761,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100144,102536,102762,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100144,102535,102763,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100144,102538,102764,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100144,102537,102765,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100144,100635,102766,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100144,100535,102767,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100144,100673,102768,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100144,100573,102769,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100144,102543,102770,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100144,102542,102771,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100144,102545,102772,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100144,102544,102773,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100144,102547,102774,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100144,102546,102775,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100144,102549,102776,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100144,102548,102777,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,100006,null,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100180,100006,null,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,100006,null,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,100110,null,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,100110,null,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100180,100110,null,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100180,100183,null,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100182,100183,null,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100181,100183,null,null,null,null,100000, 'Y','Y');
insert into um.node_metric_jn values (100180,100801,100433,null,null,null,100002, 'Y','Y');
insert into um.node_metric_jn values (100182,100801,100433,null,null,null,100002, 'Y','Y');
insert into um.node_metric_jn values (100181,100801,100433,null,null,null,100002, 'Y','Y');
insert into um.node_metric_jn values (100182,100802,100434,null,null,null,100002, 'Y','Y');
insert into um.node_metric_jn values (100181,100802,100434,null,null,null,100002, 'Y','Y');
insert into um.node_metric_jn values (100180,100802,100434,null,null,null,100002, 'Y','Y');
insert into um.node_metric_jn values (100182,102553,null,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,102553,null,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100180,102553,null,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,102554,null,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100180,102554,null,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,102554,null,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100180,102555,null,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100182,102555,null,null,null,null,100001, 'Y','Y');
insert into um.node_metric_jn values (100181,102555,null,null,null,null,100001, 'Y','Y');



commit;




insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100180, 100002);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100180, 100001);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100180, 100000);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100181, 100002);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100181, 100001);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100181, 100000);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100182, 100002);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100182, 100001);

insert into um.node_match_jn (NODE_ID, FILE_MATCH_DEFINITION_ID)
values (100182, 100000);




insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100182, 100017, 'T', 100001, 'CCS Intermediate vs CCS Daily (Value) - ST_ALL - EDR Value', 'CCS Intermediate vs CCS Daily (value) - ST_ALL - EDR Value');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100183, 100017, 'T', 100001, 'CCS Intermediate vs CCS Daily (Bytes) - ST_ALL - EDR Bytes', 'CCS Intermediate vs CCS Daily (value) - ST_ALL - EDR Bytes');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100184, 100017, 'T', 100001, 'CCS Intermediate vs CCS Daily (Count) - ST_ALL - EDR Count', 'CCS Intermediate vs CCS Daily (value) - ST_ALL - EDR Count');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100185, 100017, 'T', 100001, 'CCS vs WAP ICCS (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily)', 'CCS vs WAP ICCS (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100186, 100017, 'T', 100001, 'CCS  vs GPRS ICCS (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily)', 'CCS  vs GPRS ICCS (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100187, 100017, 'T', 100001, 'CCS Intermediate vs CCS Daily (value) - ST_ALL - EDR Value (Daily)', 'CCS Intermediate vs CCS Daily (value) - ST_ALL - EDR Value (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100188, 100017, 'T', 100001, 'GPRS ICCS vs ICCS Billed (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily)', 'GPRS ICCS vs ICCS Billed (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100189, 100017, 'T', 100001, 'WAP ICCS vs ICCS Billed (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily)', 'WAP ICCS vs ICCS Billed (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100190, 100017, 'T', 100001, 'CCS vs WAP ICCS (bytes) - ST_DATA _STRIP - EDR Bytes (Daily)', 'CCS vs WAP ICCS (bytes) - ST_DATA _STRIP - EDR Bytes (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100191, 100017, 'T', 100001, 'CCS vs GPRS ICCS (bytes) .ST_DATA _STRIP - EDR Bytes (Daily)', 'CCS vs GPRS ICCS (bytes) - ST_DATA _STRIP - EDR Bytes (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100192, 100017, 'T', 100001, 'CCS Intermediate vs CCS Daily (Bytes) - ST_ALL - EDR Bytes (Daily)', 'CCS Intermediate vs CCS Daily (Bytes) - ST_ALL - EDR Bytes (Daily)');

insert into um.mrec_definition_ref (MREC_DEFINITION_ID, MREC_CATEGORY_ID, MREC_TYPE, GRAPH_ID, NAME, DESCRIPTION)
values (100193, 100017, 'T', 100001, 'CCS Intermediate vs CCS Daily (Count) - ST_ALL - EDR Count (Daily)', 'CCS Intermediate vs CCS Daily (Count) - ST_ALL - EDR Count (Daily)');


insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100182, 100182, null, 102182, null, null, 'CCS Intermediate vs CCS Daily (Value) - ST_ALL - EDR Value', '-forecast_comparison Y', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100183, 100183, null, 102183, null, null, 'CCS Intermediate vs CCS Daily (Bytes) - ST_ALL - EDR Bytes', '-forecast_comparison Y', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100184, 100184, null, 102184, null, null, 'CCS Intermediate vs CCS Daily (Count) - ST_ALL - EDR Count', '-forecast_comparison Y', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100185, 100185, null, 102185, null, null, 'CCS vs WAP ICCS (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily)', '-forecast_comparison Y -source 100090', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100186, 100186, null, 102186, null, null, 'CCS vs GPRS ICCS (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily)', '-forecast_comparison Y -source 100090', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100187, 100187, null, 102187, null, null, 'CCS Intermediate vs CCS Daily (value) - ST_ALL - EDR Value (Daily)', '-forecast_comparison Y', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100188, 100188, null, 102188, null, null, 'GPRS ICCS vs ICCS Billed (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily)', '-forecast_comparison Y', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100189, 100189, null, 102189, null, null, 'WAP ICCS vs ICCS Billed (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily)', '-forecast_comparison Y', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100190, 100190, null, 102190, null, null, 'CCS vs WAP ICCS (bytes) - ST_DATA _STRIP - EDR Bytes (Daily)', '-forecast_comparison Y -source 100090', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100191, 100191, null, 102191, null, null, 'CCS vs GPRS ICCS (bytes) - ST_DATA _STRIP - EDR Bytes (Daily)', '-forecast_comparison Y -source 100090', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100192, 100192, null, 102192, null, null, 'CCS Intermediate vs CCS Daily (Bytes) - ST_ALL - EDR Bytes (Daily)', '-forecast_comparison Y', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');

insert into um.mrec_version_ref (MREC_VERSION_ID, MREC_DEFINITION_ID, PARENT_VERSION_ID, THRESHOLD_DEFINITION_ID, THRESHOLD_SEQUENCE_ID, FORECAST_MREC_ID, DESCRIPTION, PARAMETERS, VALID_FROM, VALID_TO, STATUS)
values (100193, 100193, null, 102193, null, null, 'CCS Intermediate vs CCS Daily (Count) - ST_ALL - EDR Count (Daily)', '-forecast_comparison Y', to_date('01-10-2014 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2021', 'dd-mm-yyyy'), 'A');



insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100182, 100102, 100180, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100182, 100102, 100181, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100183, 100181, 100180, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100183, 100181, 100181, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100184, 100000, 100180, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100184, 100000, 100181, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100185, 100182, 100181, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100185, 100182, 100144, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100186, 100272, 100181, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100186, 100272, 100141, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100187, 100102, 100180, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100187, 100102, 100181, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100188, 100272, 100141, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100188, 100272, 100182, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100189, 100182, 100144, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100189, 100182, 100182, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100190, 100181, 100181, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100190, 102533, 100144, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100191, 100181, 100181, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100191, 102533, 100141, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100192, 100181, 100180, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100192, 100181, 100181, -1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100193, 100000, 100180, 1);

insert into um.mrec_metric_ref (MREC_VERSION_ID, METRIC_DEFINITION_ID, NODE_ID, MREC_SET)
values (100193, 100000, 100181, -1);



commit;



insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102381, 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100271, 100180, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102382, 'CCS AMA Intermediate: ST_DATA_WAP - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100274, 100180, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102383, 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100382, 100180, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102384, 'CCS AMA Intermediate: ST_DATA_WAP - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100384, 100180, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102385, 'CCS AMA Intermediate: ST_DATA - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102504, 100180, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102386, 'CCS AMA Intermediate: ST_DATA - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102505, 100180, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102387, 'CCS AMA Intermediate: ST_DATA - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102508, 100180, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102388, 'CCS AMA Intermediate: ST_DATA - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102509, 100180, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102389, 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102519, 100180, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102390, 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102521, 100180, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102391, 'CCS AMA Intermediate: ST_DATA_WAP - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102539, 100180, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102392, 'CCS AMA Intermediate: ST_DATA_WAP - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102541, 100180, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102393, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100182, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102394, 'CCS AMA Daily: ST_DATA_GPRS - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100271, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102395, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100272, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102396, 'CCS AMA Daily: ST_DATA_WAP - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100274, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102397, 'CCS AMA Daily: ST_DATA_GPRS - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100382, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102398, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100383, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102399, 'CCS AMA Daily: ST_DATA_WAP - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100384, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102400, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100385, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102401, 'CCS AMA Daily: ST_DATA_2G - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100442, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102402, 'CCS AMA Daily: ST_DATA_2G - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100444, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102403, 'CCS AMA Daily: ST_DATA_3G - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100446, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102404, 'CCS AMA Daily: ST_DATA_3G - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100448, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102405, 'CCS AMA Daily: ST_DATA_4G - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100450, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102406, 'CCS AMA Daily: ST_DATA_4G - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100452, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102407, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100534, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102408, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100535, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102409, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100634, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102410, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100635, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102411, 'CCS AMA Daily: ST_DATA - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102504, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102412, 'CCS AMA Daily: ST_DATA - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102505, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102413, 'CCS AMA Daily: ST_DATA - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102508, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102414, 'CCS AMA Daily: ST_DATA - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102509, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102415, 'CCS AMA Daily: ST_DATA_2G - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102510, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102416, 'CCS AMA Daily: ST_DATA_2G - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102512, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102417, 'CCS AMA Daily: ST_DATA_3G - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102513, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102418, 'CCS AMA Daily: ST_DATA_3G - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102515, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102419, 'CCS AMA Daily: ST_DATA_4G - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102516, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102420, 'CCS AMA Daily: ST_DATA_4G - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102518, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102421, 'CCS AMA Daily: ST_DATA_GPRS - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102519, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102422, 'CCS AMA Daily: ST_DATA_GPRS - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102521, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102423, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102522, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102424, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102523, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102425, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102530, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102426, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102532, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102427, 'CCS AMA Daily: ST_DATA_WAP - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102539, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102428, 'CCS AMA Daily: ST_DATA_WAP - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102541, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102429, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102542, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102430, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102543, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102431, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102550, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102432, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102552, 100181, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102433, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100182, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102434, 'ICCS Billed: ST_DATA_GPRS - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100271, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102435, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100272, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102436, 'ICCS Billed: ST_DATA_WAP - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100274, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102437, 'ICCS Billed: ST_DATA_GPRS - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100382, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102438, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100383, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102439, 'ICCS Billed: ST_DATA_WAP - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100384, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102440, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 100385, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102441, 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102331, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102442, 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102332, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102443, 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102335, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102444, 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102336, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102445, 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102337, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102446, 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102338, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102447, 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102341, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102448, 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102342, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102449, 'ICCS Billed: ST_DATA - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102504, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102450, 'ICCS Billed: ST_DATA - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102505, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102451, 'ICCS Billed: ST_DATA - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102508, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102452, 'ICCS Billed: ST_DATA - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102509, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102453, 'ICCS Billed: ST_DATA_GPRS - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102519, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102454, 'ICCS Billed: ST_DATA_GPRS - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102521, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102455, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102530, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102456, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102532, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102457, 'ICCS Billed: ST_DATA_WAP - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102539, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102458, 'ICCS Billed: ST_DATA_WAP - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102541, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102459, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102550, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102460, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102552, 100182, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102461, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102522, 100141, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102462, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102523, 100141, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102463, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102524, 100141, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102464, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102525, 100141, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102465, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102528, 100141, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102466, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102529, 100141, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102467, 'GPRS ICCS: ST_DATA_STRIP - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102533, 100141, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102468, 'GPRS ICCS: ST_DATA_STRIP - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102534, 100141, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102469, 'GPRS ICCS: ST_DATA_STRIP - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102537, 100141, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102470, 'GPRS ICCS: ST_DATA_STRIP - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102538, 100141, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102471, 'WAP ICCS: ST_DATA_STRIP - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102533, 100144, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102472, 'WAP ICCS: ST_DATA_STRIP - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102534, 100144, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102473, 'WAP ICCS: ST_DATA_STRIP - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102537, 100144, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102474, 'WAP ICCS: ST_DATA_STRIP - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102538, 100144, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102475, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102542, 100144, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102476, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102543, 100144, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102477, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Bytes Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102544, 100144, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102478, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Bytes (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102545, 100144, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102479, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Value Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102548, 100144, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');

insert into um.cd_metric_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, SAMPLE_FROM, SAMPLE_TO, METRIC_DEFINITION_ID, NODE_ID, EDGE_ID, SOURCE_TYPE_ID, SOURCE_ID, EDR_TYPE_ID, EDR_SUB_TYPE_ID, IS_MIN, IS_MAX, IS_AVERAGE, IS_MOVING_AVERAGE, IS_FORECAST, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (102480, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Value (Daily) Metric Chart', '/vfi-um/vfi-um/chartMetricSwfDisplay.do?rebuildFilters=true', '14', '0', 102549, 100144, null, null, null, null, null, '', '', '', '', '', 450, 175, '', '');




insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100182, 'CCS Intermediate vs CCS Daily (Value) - ST_ALL - EDR Value', '/um/um/mrecChartSetup.do?mrecType=TIMEmrecType=TIMEdisplayType=absolute&mrecDefinitionId_time=100182', 100182, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100183, 'CCS Intermediate vs CCS Daily (Bytes) - ST_ALL - EDR Bytes', '/um/um/mrecChartSetup.do?mrecType=TIMEmrecType=TIMEdisplayType=absolute&mrecDefinitionId_time=100183', 100183, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100184, 'CCS Intermediate vs CCS Daily (Count) - ST_ALL - EDR Count', '/um/um/mrecChartSetup.do?mrecType=TIMEmrecType=TIMEdisplayType=absolute&mrecDefinitionId_time=100184', 100184, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100185, 'CCS vs WAP ICCS (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIMEmrecType=TIMEdisplayType=absolute&mrecDefinitionId_time=100185', 100185, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100186, 'CCS  vs GPRS ICCS (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIMEmrecType=TIMEdisplayType=absolute&mrecDefinitionId_time=100186', 100186, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100187, 'CCS Intermediate vs CCS Daily (value) - ST_ALL - EDR Value (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIMEmrecType=TIMEdisplayType=absolute&mrecDefinitionId_time=100187', 100187, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100188, 'GPRS ICCS vs ICCS Billed (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIMEmrecType=TIMEdisplayType=absolute&mrecDefinitionId_time=100188', 100188, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100189, 'WAP ICCS vs ICCS Billed (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIMEmrecType=TIMEdisplayType=absolute&mrecDefinitionId_time=100189', 100189, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100190, 'CCS vs WAP ICCS (bytes) - ST_DATA _STRIP - EDR Bytes (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIMEmrecType=TIMEdisplayType=absolute&mrecDefinitionId_time=100190', 100190, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100191, 'CCS vs GPRS ICCS (bytes) - ST_DATA _STRIP - EDR Bytes (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIMEmrecType=TIMEdisplayType=absolute&mrecDefinitionId_time=100191', 100191, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100192, 'CCS Intermediate vs CCS Daily (Bytes) - ST_ALL - EDR Bytes (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIMEmrecType=TIMEdisplayType=absolute&mrecDefinitionId_time=100192', 100192, null, '14', '0', 'R', 450, 175, '', '');

insert into um.cd_mrec_ref (INSTANCE_ID, LABEL, CLICKTHROUGH_URL, MREC_DEFINITION_ID, EDGE_ID, SAMPLE_FROM, SAMPLE_TO, SHOW_DETAILS, WIDTH, HEIGHT, PARAMETERS, PDF_PARAMETERS)
values (100193, 'CCS Intermediate vs CCS Daily (Count) - ST_ALL - EDR Count (Daily)', '/um/um/mrecChartSetup.do?mrecType=TIMEmrecType=TIMEdisplayType=absolute&mrecDefinitionId_time=100193', 100193, null, '14', '0', 'R', 450, 175, '', '');




----



update um.mrec_definition_ref 
set    name               = replace(name,'EMM data', 'CCS/EMM data'),
       description        = replace(description,'EMM data', 'CCS/EMM data')
where  mrec_definition_id in (100033,100034,100060,100061,100062,100069,100070);

update um.mrec_version_ref 
set  
       description        = replace(description,'EMM data', 'CCS/EMM data')
where  mrec_definition_id in (100033,100034,100060,100061,100062,100069,100070);


update um.mrec_definition_ref 
set    name               = replace(name,'EMM Data', 'CCS/EMM Data'),
       description        = replace(description,'EMM Data', 'CCS/EMM Data')
where  mrec_definition_id in (100128,100129,100138,100139);

update um.mrec_version_ref 
set  
       description        = replace(description,'EMM data', 'CCS/EMM Data')
where  mrec_definition_id in (100128,100129,100138,100139);
        


insert into um.mrec_metric_ref 
select m.mrec_version_id, m.metric_definition_id, 100181, mrec_set
from   um.mrec_version_ref v, 
       um.mrec_metric_ref m
where  v.mrec_definition_id in (100033,100034,100060,100061,100062,100069,100070,100128,100129,100138,100139)
and    v.mrec_version_id = m.mrec_version_id
and    m.node_id = 100107;       

commit;


exit
