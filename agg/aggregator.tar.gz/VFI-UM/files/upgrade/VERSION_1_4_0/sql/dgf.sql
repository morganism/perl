insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100180, 100001, 100000, 'CCS AMA Intermediate', 'DS83', '', null);

insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100181, 100001, 100000, 'CCS AMA Daily', 'DS84', '', null);

insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100182, 100001, 100000, 'ICCS Billed', 'DS7', '', null);


insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100107, 100180);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100107, 100181);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100107, 100182);




commit;

exit
