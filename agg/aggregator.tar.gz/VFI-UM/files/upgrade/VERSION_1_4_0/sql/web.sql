
update web.cd_dashboard_detail
set    title               = replace(title,'EMM data', 'CCS/EMM data')
where  cd_dashboard_id = 100017
and    type_id = 35001;


update web.cd_dashboard_detail
set    format_row = format_row*10
where  cd_dashboard_id = 100017;




insert into web.cd_dashboard_detail (CD_DASHBOARD_ID, FORMAT_ROW, POSITION, WIDTH, TITLE, INSTANCE_ID, COLSPAN, TYPE_ID)
values (100017, 81, 0, 450, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Value Metric Chart', 102400, null, 35000);

insert into web.cd_dashboard_detail (CD_DASHBOARD_ID, FORMAT_ROW, POSITION, WIDTH, TITLE, INSTANCE_ID, COLSPAN, TYPE_ID)
values (100017, 81, 1, 450, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Value Metric Chart', 102398, null, 35000);

insert into web.cd_dashboard_detail (CD_DASHBOARD_ID, FORMAT_ROW, POSITION, WIDTH, TITLE, INSTANCE_ID, COLSPAN, TYPE_ID)
values (100017, 82, 0, 450, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes Metric Chart', 102407, null, 35000);

insert into web.cd_dashboard_detail (CD_DASHBOARD_ID, FORMAT_ROW, POSITION, WIDTH, TITLE, INSTANCE_ID, COLSPAN, TYPE_ID)
values (100017, 82, 1, 450, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes Metric Chart', 102408, null, 35000);

insert into web.cd_dashboard_detail (CD_DASHBOARD_ID, FORMAT_ROW, POSITION, WIDTH, TITLE, INSTANCE_ID, COLSPAN, TYPE_ID)
values (100017, 85, 0, 450, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Value Metric Chart', 102438, null, 35000);

insert into web.cd_dashboard_detail (CD_DASHBOARD_ID, FORMAT_ROW, POSITION, WIDTH, TITLE, INSTANCE_ID, COLSPAN, TYPE_ID)
values (100017, 85, 1, 450, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Value Metric Chart', 102440, null, 35000);

insert into web.cd_dashboard_detail (CD_DASHBOARD_ID, FORMAT_ROW, POSITION, WIDTH, TITLE, INSTANCE_ID, COLSPAN, TYPE_ID)
values (100017, 84, 0, 450, 'WAP ICCS: ST_DATA_STRIP - EDR Bytes Metric Chart', 102471, null, 35000);

insert into web.cd_dashboard_detail (CD_DASHBOARD_ID, FORMAT_ROW, POSITION, WIDTH, TITLE, INSTANCE_ID, COLSPAN, TYPE_ID)
values (100017, 84, 1, 450, 'GPRS ICCS: ST_DATA_STRIP - EDR Bytes Metric Chart', 102467, null, 35000);




insert into web.cd_dashboard_detail (CD_DASHBOARD_ID, FORMAT_ROW, POSITION, WIDTH, TITLE, INSTANCE_ID, COLSPAN, TYPE_ID)
values (100017, 41, 0, 450, 'CCS Intermediate vs CCS Daily (Bytes) - ST_ALL - EDR Bytes (Daily)', 100192, null, 35001);

insert into web.cd_dashboard_detail (CD_DASHBOARD_ID, FORMAT_ROW, POSITION, WIDTH, TITLE, INSTANCE_ID, COLSPAN, TYPE_ID)
values (100017, 41, 1, 450, 'CCS vs WAP ICCS (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily)', 100185, null, 35001);

insert into web.cd_dashboard_detail (CD_DASHBOARD_ID, FORMAT_ROW, POSITION, WIDTH, TITLE, INSTANCE_ID, COLSPAN, TYPE_ID)
values (100017, 42, 0, 450, 'CCS  vs GPRS ICCS (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily)', 100186, null, 35001);

insert into web.cd_dashboard_detail (CD_DASHBOARD_ID, FORMAT_ROW, POSITION, WIDTH, TITLE, INSTANCE_ID, COLSPAN, TYPE_ID)
values (100017, 42, 1, 450, 'GPRS ICCS vs ICCS Billed (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily)', 100188, null, 35001);

insert into web.cd_dashboard_detail (CD_DASHBOARD_ID, FORMAT_ROW, POSITION, WIDTH, TITLE, INSTANCE_ID, COLSPAN, TYPE_ID)
values (100017, 42, 2, 450, 'WAP ICCS vs ICCS Billed (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily)', 100189, null, 35001);


commit;

exit
