set define off

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102601, 'CCS AMA Daily: ST_AGG_SUCCESS - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_AGG_SUCCESS - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102602, 'CCS AMA Daily: ST_ALL - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_ALL - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102603, 'CCS AMA Daily: ST_ALL - EDR Bytes - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_ALL - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102604, 'CCS AMA Daily: ST_ALL - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_ALL - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102605, 'CCS AMA Daily: ST_ALL - EDR Count - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_ALL - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102606, 'CCS AMA Daily: ST_ALL - EDR Value (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_ALL - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102607, 'CCS AMA Daily: ST_ALL - EDR Value - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_ALL - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102608, 'CCS AMA Daily: ST_DATA - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102609, 'CCS AMA Daily: ST_DATA - EDR Bytes - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102610, 'CCS AMA Daily: ST_DATA - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102611, 'CCS AMA Daily: ST_DATA - EDR Count - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102612, 'CCS AMA Daily: ST_DATA - EDR Value (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102613, 'CCS AMA Daily: ST_DATA - EDR Value - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102614, 'CCS AMA Daily: ST_DATA_2G - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_2G - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102615, 'CCS AMA Daily: ST_DATA_2G - EDR Bytes - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_2G - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102616, 'CCS AMA Daily: ST_DATA_2G - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_2G - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102617, 'CCS AMA Daily: ST_DATA_2G - EDR Count - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_2G - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102618, 'CCS AMA Daily: ST_DATA_2G - EDR Value (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_2G - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102619, 'CCS AMA Daily: ST_DATA_2G - EDR Value - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_2G - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102620, 'CCS AMA Daily: ST_DATA_3G - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_3G - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102621, 'CCS AMA Daily: ST_DATA_3G - EDR Bytes - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_3G - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102622, 'CCS AMA Daily: ST_DATA_3G - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_3G - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102623, 'CCS AMA Daily: ST_DATA_3G - EDR Count - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_3G - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102624, 'CCS AMA Daily: ST_DATA_3G - EDR Value (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_3G - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102625, 'CCS AMA Daily: ST_DATA_3G - EDR Value - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_3G - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102626, 'CCS AMA Daily: ST_DATA_4G - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_4G - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102627, 'CCS AMA Daily: ST_DATA_4G - EDR Bytes - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_4G - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102628, 'CCS AMA Daily: ST_DATA_4G - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_4G - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102629, 'CCS AMA Daily: ST_DATA_4G - EDR Count - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_4G - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102630, 'CCS AMA Daily: ST_DATA_4G - EDR Value (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_4G - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102631, 'CCS AMA Daily: ST_DATA_4G - EDR Value - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_4G - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102632, 'CCS AMA Daily: ST_DATA_GPRS - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102633, 'CCS AMA Daily: ST_DATA_GPRS - EDR Bytes - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102634, 'CCS AMA Daily: ST_DATA_GPRS - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102635, 'CCS AMA Daily: ST_DATA_GPRS - EDR Count - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102636, 'CCS AMA Daily: ST_DATA_GPRS - EDR Value (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102637, 'CCS AMA Daily: ST_DATA_GPRS - EDR Value - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102638, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102639, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102640, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102641, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102642, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102643, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102644, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102645, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Bytes - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102646, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102647, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Count - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102648, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Value (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102649, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Value - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102650, 'CCS AMA Daily: ST_DATA_WAP - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102651, 'CCS AMA Daily: ST_DATA_WAP - EDR Bytes - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102652, 'CCS AMA Daily: ST_DATA_WAP - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102653, 'CCS AMA Daily: ST_DATA_WAP - EDR Count - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102654, 'CCS AMA Daily: ST_DATA_WAP - EDR Value (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102655, 'CCS AMA Daily: ST_DATA_WAP - EDR Value - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102656, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102657, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102658, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102659, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102660, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102661, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102662, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102663, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Bytes - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102664, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102665, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Count - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102666, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Value (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102667, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Value - Metric Threshold', 'Percentage', 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102668, 'CCS AMA Intermediate: ST_AGG_SUCCESS - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_AGG_SUCCESS - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102669, 'CCS AMA Intermediate: ST_ALL - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_ALL - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102670, 'CCS AMA Intermediate: ST_ALL - EDR Bytes - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_ALL - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102671, 'CCS AMA Intermediate: ST_ALL - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_ALL - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102672, 'CCS AMA Intermediate: ST_ALL - EDR Count - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_ALL - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102673, 'CCS AMA Intermediate: ST_ALL - EDR Value (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_ALL - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102674, 'CCS AMA Intermediate: ST_ALL - EDR Value - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_ALL - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102675, 'CCS AMA Intermediate: ST_DATA - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102676, 'CCS AMA Intermediate: ST_DATA - EDR Bytes - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102677, 'CCS AMA Intermediate: ST_DATA - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102678, 'CCS AMA Intermediate: ST_DATA - EDR Count - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102679, 'CCS AMA Intermediate: ST_DATA - EDR Value (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102680, 'CCS AMA Intermediate: ST_DATA - EDR Value - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102681, 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102682, 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Bytes - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102683, 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102684, 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Count - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102685, 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Value (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102686, 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Value - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102687, 'CCS AMA Intermediate: ST_DATA_WAP - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA_WAP - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102688, 'CCS AMA Intermediate: ST_DATA_WAP - EDR Bytes - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA_WAP - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102689, 'CCS AMA Intermediate: ST_DATA_WAP - EDR Count (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA_WAP - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102690, 'CCS AMA Intermediate: ST_DATA_WAP - EDR Count - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA_WAP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102691, 'CCS AMA Intermediate: ST_DATA_WAP - EDR Value (Daily) - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA_WAP - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102692, 'CCS AMA Intermediate: ST_DATA_WAP - EDR Value - Metric Threshold', 'Percentage', 'CCS AMA Intermediate: ST_DATA_WAP - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102693, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102694, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102695, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count (Daily) - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102696, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102697, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value (Daily) - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102698, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102699, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102700, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Bytes - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102701, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Count (Daily) - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102702, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Count - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102703, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Value (Daily) - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102704, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Value - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102705, 'GPRS ICCS: ST_DATA_STRIP - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_STRIP - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102706, 'GPRS ICCS: ST_DATA_STRIP - EDR Bytes - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_STRIP - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102707, 'GPRS ICCS: ST_DATA_STRIP - EDR Count (Daily) - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_STRIP - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102708, 'GPRS ICCS: ST_DATA_STRIP - EDR Count - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_STRIP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102709, 'GPRS ICCS: ST_DATA_STRIP - EDR Value (Daily) - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_STRIP - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102710, 'GPRS ICCS: ST_DATA_STRIP - EDR Value - Metric Threshold', 'Percentage', 'GPRS ICCS: ST_DATA_STRIP - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102711, 'ICCS Billed: ST_AGG_SUCCESS - EDR Count (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_AGG_SUCCESS - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102712, 'ICCS Billed: ST_ALL - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_ALL - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102713, 'ICCS Billed: ST_ALL - EDR Bytes - Metric Threshold', 'Percentage', 'ICCS Billed: ST_ALL - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102714, 'ICCS Billed: ST_ALL - EDR Count (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_ALL - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102715, 'ICCS Billed: ST_ALL - EDR Count - Metric Threshold', 'Percentage', 'ICCS Billed: ST_ALL - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102716, 'ICCS Billed: ST_ALL - EDR Value (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_ALL - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102717, 'ICCS Billed: ST_ALL - EDR Value - Metric Threshold', 'Percentage', 'ICCS Billed: ST_ALL - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102718, 'ICCS Billed: ST_DATA - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102719, 'ICCS Billed: ST_DATA - EDR Bytes - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102720, 'ICCS Billed: ST_DATA - EDR Count (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102721, 'ICCS Billed: ST_DATA - EDR Count - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102722, 'ICCS Billed: ST_DATA - EDR Value (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102723, 'ICCS Billed: ST_DATA - EDR Value - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102724, 'ICCS Billed: ST_DATA_GPRS - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_GPRS - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102725, 'ICCS Billed: ST_DATA_GPRS - EDR Bytes - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_GPRS - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102726, 'ICCS Billed: ST_DATA_GPRS - EDR Count (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_GPRS - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102727, 'ICCS Billed: ST_DATA_GPRS - EDR Count - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_GPRS - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102728, 'ICCS Billed: ST_DATA_GPRS - EDR Value (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_GPRS - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102729, 'ICCS Billed: ST_DATA_GPRS - EDR Value - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_GPRS - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102730, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102731, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Bytes - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102732, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Count (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102733, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Count - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102734, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Value (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102735, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Value - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102736, 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102737, 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Bytes - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102738, 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Count (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102739, 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Count - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102740, 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Value (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102741, 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Value - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102742, 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102743, 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Bytes - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102744, 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Count (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102745, 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Count - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102746, 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Value (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102747, 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Value - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102748, 'ICCS Billed: ST_DATA_WAP - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_WAP - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102749, 'ICCS Billed: ST_DATA_WAP - EDR Bytes - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_WAP - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102750, 'ICCS Billed: ST_DATA_WAP - EDR Count (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_WAP - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102751, 'ICCS Billed: ST_DATA_WAP - EDR Count - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_WAP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102752, 'ICCS Billed: ST_DATA_WAP - EDR Value (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_WAP - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102753, 'ICCS Billed: ST_DATA_WAP - EDR Value - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_WAP - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102754, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102755, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Bytes - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102756, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Count (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102757, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Count - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102758, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Value (Daily) - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102759, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Value - Metric Threshold', 'Percentage', 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102760, 'WAP ICCS: ST_DATA_STRIP - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_STRIP - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102761, 'WAP ICCS: ST_DATA_STRIP - EDR Bytes - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_STRIP - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102762, 'WAP ICCS: ST_DATA_STRIP - EDR Count (Daily) - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_STRIP - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102763, 'WAP ICCS: ST_DATA_STRIP - EDR Count - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_STRIP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102764, 'WAP ICCS: ST_DATA_STRIP - EDR Value (Daily) - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_STRIP - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102765, 'WAP ICCS: ST_DATA_STRIP - EDR Value - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_STRIP - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102766, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102767, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102768, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count (Daily) - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102769, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102770, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value (Daily) - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102771, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102772, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Bytes (Daily) - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Bytes (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102773, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Bytes - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102774, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Count (Daily) - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Count (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102775, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Count - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102776, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Value (Daily) - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Value (Daily) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102777, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Value - Metric Threshold', 'Percentage', 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Value - Metric Threshold');



insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102601, 'CCS AMA Daily: ST_AGG_SUCCESS - EDR Count (Daily) - Metric Threshold', 102601, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102602, 'CCS AMA Daily: ST_ALL - EDR Bytes (Daily) - Metric Threshold', 102602, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102603, 'CCS AMA Daily: ST_ALL - EDR Bytes - Metric Threshold', 102603, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102604, 'CCS AMA Daily: ST_ALL - EDR Count (Daily) - Metric Threshold', 102604, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102605, 'CCS AMA Daily: ST_ALL - EDR Count - Metric Threshold', 102605, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102606, 'CCS AMA Daily: ST_ALL - EDR Value (Daily) - Metric Threshold', 102606, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102607, 'CCS AMA Daily: ST_ALL - EDR Value - Metric Threshold', 102607, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102608, 'CCS AMA Daily: ST_DATA - EDR Bytes (Daily) - Metric Threshold', 102608, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102609, 'CCS AMA Daily: ST_DATA - EDR Bytes - Metric Threshold', 102609, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102610, 'CCS AMA Daily: ST_DATA - EDR Count (Daily) - Metric Threshold', 102610, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102611, 'CCS AMA Daily: ST_DATA - EDR Count - Metric Threshold', 102611, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102612, 'CCS AMA Daily: ST_DATA - EDR Value (Daily) - Metric Threshold', 102612, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102613, 'CCS AMA Daily: ST_DATA - EDR Value - Metric Threshold', 102613, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102614, 'CCS AMA Daily: ST_DATA_2G - EDR Bytes (Daily) - Metric Threshold', 102614, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102615, 'CCS AMA Daily: ST_DATA_2G - EDR Bytes - Metric Threshold', 102615, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102616, 'CCS AMA Daily: ST_DATA_2G - EDR Count (Daily) - Metric Threshold', 102616, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102617, 'CCS AMA Daily: ST_DATA_2G - EDR Count - Metric Threshold', 102617, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102618, 'CCS AMA Daily: ST_DATA_2G - EDR Value (Daily) - Metric Threshold', 102618, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102619, 'CCS AMA Daily: ST_DATA_2G - EDR Value - Metric Threshold', 102619, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102620, 'CCS AMA Daily: ST_DATA_3G - EDR Bytes (Daily) - Metric Threshold', 102620, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102621, 'CCS AMA Daily: ST_DATA_3G - EDR Bytes - Metric Threshold', 102621, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102622, 'CCS AMA Daily: ST_DATA_3G - EDR Count (Daily) - Metric Threshold', 102622, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102623, 'CCS AMA Daily: ST_DATA_3G - EDR Count - Metric Threshold', 102623, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102624, 'CCS AMA Daily: ST_DATA_3G - EDR Value (Daily) - Metric Threshold', 102624, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102625, 'CCS AMA Daily: ST_DATA_3G - EDR Value - Metric Threshold', 102625, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102626, 'CCS AMA Daily: ST_DATA_4G - EDR Bytes (Daily) - Metric Threshold', 102626, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102627, 'CCS AMA Daily: ST_DATA_4G - EDR Bytes - Metric Threshold', 102627, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102628, 'CCS AMA Daily: ST_DATA_4G - EDR Count (Daily) - Metric Threshold', 102628, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102629, 'CCS AMA Daily: ST_DATA_4G - EDR Count - Metric Threshold', 102629, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102630, 'CCS AMA Daily: ST_DATA_4G - EDR Value (Daily) - Metric Threshold', 102630, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102631, 'CCS AMA Daily: ST_DATA_4G - EDR Value - Metric Threshold', 102631, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102632, 'CCS AMA Daily: ST_DATA_GPRS - EDR Bytes (Daily) - Metric Threshold', 102632, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102633, 'CCS AMA Daily: ST_DATA_GPRS - EDR Bytes - Metric Threshold', 102633, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102634, 'CCS AMA Daily: ST_DATA_GPRS - EDR Count (Daily) - Metric Threshold', 102634, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102635, 'CCS AMA Daily: ST_DATA_GPRS - EDR Count - Metric Threshold', 102635, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102636, 'CCS AMA Daily: ST_DATA_GPRS - EDR Value (Daily) - Metric Threshold', 102636, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102637, 'CCS AMA Daily: ST_DATA_GPRS - EDR Value - Metric Threshold', 102637, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102638, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes (Daily) - Metric Threshold', 102638, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102639, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold', 102639, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102640, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count (Daily) - Metric Threshold', 102640, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102641, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count - Metric Threshold', 102641, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102642, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value (Daily) - Metric Threshold', 102642, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102643, 'CCS AMA Daily: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value - Metric Threshold', 102643, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102644, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily) - Metric Threshold', 102644, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102645, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Bytes - Metric Threshold', 102645, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102646, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Count (Daily) - Metric Threshold', 102646, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102647, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Count - Metric Threshold', 102647, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102648, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Value (Daily) - Metric Threshold', 102648, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102649, 'CCS AMA Daily: ST_DATA_GPRS_POSTPAID - EDR Value - Metric Threshold', 102649, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102650, 'CCS AMA Daily: ST_DATA_WAP - EDR Bytes (Daily) - Metric Threshold', 102650, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102651, 'CCS AMA Daily: ST_DATA_WAP - EDR Bytes - Metric Threshold', 102651, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102652, 'CCS AMA Daily: ST_DATA_WAP - EDR Count (Daily) - Metric Threshold', 102652, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102653, 'CCS AMA Daily: ST_DATA_WAP - EDR Count - Metric Threshold', 102653, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102654, 'CCS AMA Daily: ST_DATA_WAP - EDR Value (Daily) - Metric Threshold', 102654, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102655, 'CCS AMA Daily: ST_DATA_WAP - EDR Value - Metric Threshold', 102655, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102656, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes (Daily) - Metric Threshold', 102656, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102657, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold', 102657, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102658, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count (Daily) - Metric Threshold', 102658, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102659, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count - Metric Threshold', 102659, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102660, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value (Daily) - Metric Threshold', 102660, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102661, 'CCS AMA Daily: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value - Metric Threshold', 102661, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102662, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Bytes (Daily) - Metric Threshold', 102662, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102663, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Bytes - Metric Threshold', 102663, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102664, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Count (Daily) - Metric Threshold', 102664, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102665, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Count - Metric Threshold', 102665, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102666, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Value (Daily) - Metric Threshold', 102666, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102667, 'CCS AMA Daily: ST_DATA_WAP_POSTPAID - EDR Value - Metric Threshold', 102667, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102668, 'CCS AMA Intermediate: ST_AGG_SUCCESS - EDR Count (Daily) - Metric Threshold', 102668, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102669, 'CCS AMA Intermediate: ST_ALL - EDR Bytes (Daily) - Metric Threshold', 102669, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102670, 'CCS AMA Intermediate: ST_ALL - EDR Bytes - Metric Threshold', 102670, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102671, 'CCS AMA Intermediate: ST_ALL - EDR Count (Daily) - Metric Threshold', 102671, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102672, 'CCS AMA Intermediate: ST_ALL - EDR Count - Metric Threshold', 102672, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102673, 'CCS AMA Intermediate: ST_ALL - EDR Value (Daily) - Metric Threshold', 102673, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102674, 'CCS AMA Intermediate: ST_ALL - EDR Value - Metric Threshold', 102674, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102675, 'CCS AMA Intermediate: ST_DATA - EDR Bytes (Daily) - Metric Threshold', 102675, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102676, 'CCS AMA Intermediate: ST_DATA - EDR Bytes - Metric Threshold', 102676, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102677, 'CCS AMA Intermediate: ST_DATA - EDR Count (Daily) - Metric Threshold', 102677, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102678, 'CCS AMA Intermediate: ST_DATA - EDR Count - Metric Threshold', 102678, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102679, 'CCS AMA Intermediate: ST_DATA - EDR Value (Daily) - Metric Threshold', 102679, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102680, 'CCS AMA Intermediate: ST_DATA - EDR Value - Metric Threshold', 102680, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102681, 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Bytes (Daily) - Metric Threshold', 102681, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102682, 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Bytes - Metric Threshold', 102682, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102683, 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Count (Daily) - Metric Threshold', 102683, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102684, 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Count - Metric Threshold', 102684, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102685, 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Value (Daily) - Metric Threshold', 102685, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102686, 'CCS AMA Intermediate: ST_DATA_GPRS - EDR Value - Metric Threshold', 102686, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102687, 'CCS AMA Intermediate: ST_DATA_WAP - EDR Bytes (Daily) - Metric Threshold', 102687, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102688, 'CCS AMA Intermediate: ST_DATA_WAP - EDR Bytes - Metric Threshold', 102688, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102689, 'CCS AMA Intermediate: ST_DATA_WAP - EDR Count (Daily) - Metric Threshold', 102689, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102690, 'CCS AMA Intermediate: ST_DATA_WAP - EDR Count - Metric Threshold', 102690, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102691, 'CCS AMA Intermediate: ST_DATA_WAP - EDR Value (Daily) - Metric Threshold', 102691, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102692, 'CCS AMA Intermediate: ST_DATA_WAP - EDR Value - Metric Threshold', 102692, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102693, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes (Daily) - Metric Threshold', 102693, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102694, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold', 102694, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102695, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count (Daily) - Metric Threshold', 102695, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102696, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Count - Metric Threshold', 102696, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102697, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value (Daily) - Metric Threshold', 102697, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102698, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS - EDR Value - Metric Threshold', 102698, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102699, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Bytes (Daily) - Metric Threshold', 102699, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102700, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Bytes - Metric Threshold', 102700, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102701, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Count (Daily) - Metric Threshold', 102701, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102702, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Count - Metric Threshold', 102702, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102703, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Value (Daily) - Metric Threshold', 102703, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102704, 'GPRS ICCS: ST_DATA_GPRS_OUTBOUND_ROAMERS_STRIP - EDR Value - Metric Threshold', 102704, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102705, 'GPRS ICCS: ST_DATA_STRIP - EDR Bytes (Daily) - Metric Threshold', 102705, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102706, 'GPRS ICCS: ST_DATA_STRIP - EDR Bytes - Metric Threshold', 102706, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102707, 'GPRS ICCS: ST_DATA_STRIP - EDR Count (Daily) - Metric Threshold', 102707, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102708, 'GPRS ICCS: ST_DATA_STRIP - EDR Count - Metric Threshold', 102708, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102709, 'GPRS ICCS: ST_DATA_STRIP - EDR Value (Daily) - Metric Threshold', 102709, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102710, 'GPRS ICCS: ST_DATA_STRIP - EDR Value - Metric Threshold', 102710, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102711, 'ICCS Billed: ST_AGG_SUCCESS - EDR Count (Daily) - Metric Threshold', 102711, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102712, 'ICCS Billed: ST_ALL - EDR Bytes (Daily) - Metric Threshold', 102712, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102713, 'ICCS Billed: ST_ALL - EDR Bytes - Metric Threshold', 102713, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102714, 'ICCS Billed: ST_ALL - EDR Count (Daily) - Metric Threshold', 102714, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102715, 'ICCS Billed: ST_ALL - EDR Count - Metric Threshold', 102715, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102716, 'ICCS Billed: ST_ALL - EDR Value (Daily) - Metric Threshold', 102716, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102717, 'ICCS Billed: ST_ALL - EDR Value - Metric Threshold', 102717, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102718, 'ICCS Billed: ST_DATA - EDR Bytes (Daily) - Metric Threshold', 102718, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102719, 'ICCS Billed: ST_DATA - EDR Bytes - Metric Threshold', 102719, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102720, 'ICCS Billed: ST_DATA - EDR Count (Daily) - Metric Threshold', 102720, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102721, 'ICCS Billed: ST_DATA - EDR Count - Metric Threshold', 102721, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102722, 'ICCS Billed: ST_DATA - EDR Value (Daily) - Metric Threshold', 102722, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102723, 'ICCS Billed: ST_DATA - EDR Value - Metric Threshold', 102723, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102724, 'ICCS Billed: ST_DATA_GPRS - EDR Bytes (Daily) - Metric Threshold', 102724, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102725, 'ICCS Billed: ST_DATA_GPRS - EDR Bytes - Metric Threshold', 102725, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102726, 'ICCS Billed: ST_DATA_GPRS - EDR Count (Daily) - Metric Threshold', 102726, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102727, 'ICCS Billed: ST_DATA_GPRS - EDR Count - Metric Threshold', 102727, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102728, 'ICCS Billed: ST_DATA_GPRS - EDR Value (Daily) - Metric Threshold', 102728, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102729, 'ICCS Billed: ST_DATA_GPRS - EDR Value - Metric Threshold', 102729, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102730, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily) - Metric Threshold', 102730, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102731, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Bytes - Metric Threshold', 102731, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102732, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Count (Daily) - Metric Threshold', 102732, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102733, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Count - Metric Threshold', 102733, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102734, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Value (Daily) - Metric Threshold', 102734, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102735, 'ICCS Billed: ST_DATA_GPRS_POSTPAID - EDR Value - Metric Threshold', 102735, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102736, 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Bytes (Daily) - Metric Threshold', 102736, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102737, 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Bytes - Metric Threshold', 102737, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102738, 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Count (Daily) - Metric Threshold', 102738, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102739, 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Count - Metric Threshold', 102739, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102740, 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Value (Daily) - Metric Threshold', 102740, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102741, 'ICCS Billed: ST_DATA_IN_BUNDLE - EDR Value - Metric Threshold', 102741, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102742, 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Bytes (Daily) - Metric Threshold', 102742, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102743, 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Bytes - Metric Threshold', 102743, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102744, 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Count (Daily) - Metric Threshold', 102744, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102745, 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Count - Metric Threshold', 102745, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102746, 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Value (Daily) - Metric Threshold', 102746, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102747, 'ICCS Billed: ST_DATA_OUT_BUNDLE - EDR Value - Metric Threshold', 102747, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102748, 'ICCS Billed: ST_DATA_WAP - EDR Bytes (Daily) - Metric Threshold', 102748, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102749, 'ICCS Billed: ST_DATA_WAP - EDR Bytes - Metric Threshold', 102749, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102750, 'ICCS Billed: ST_DATA_WAP - EDR Count (Daily) - Metric Threshold', 102750, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102751, 'ICCS Billed: ST_DATA_WAP - EDR Count - Metric Threshold', 102751, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102752, 'ICCS Billed: ST_DATA_WAP - EDR Value (Daily) - Metric Threshold', 102752, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102753, 'ICCS Billed: ST_DATA_WAP - EDR Value - Metric Threshold', 102753, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102754, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Bytes (Daily) - Metric Threshold', 102754, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102755, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Bytes - Metric Threshold', 102755, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102756, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Count (Daily) - Metric Threshold', 102756, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102757, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Count - Metric Threshold', 102757, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102758, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Value (Daily) - Metric Threshold', 102758, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102759, 'ICCS Billed: ST_DATA_WAP_POSTPAID - EDR Value - Metric Threshold', 102759, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102760, 'WAP ICCS: ST_DATA_STRIP - EDR Bytes (Daily) - Metric Threshold', 102760, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102761, 'WAP ICCS: ST_DATA_STRIP - EDR Bytes - Metric Threshold', 102761, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102762, 'WAP ICCS: ST_DATA_STRIP - EDR Count (Daily) - Metric Threshold', 102762, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102763, 'WAP ICCS: ST_DATA_STRIP - EDR Count - Metric Threshold', 102763, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102764, 'WAP ICCS: ST_DATA_STRIP - EDR Value (Daily) - Metric Threshold', 102764, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102765, 'WAP ICCS: ST_DATA_STRIP - EDR Value - Metric Threshold', 102765, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102766, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes (Daily) - Metric Threshold', 102766, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102767, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Bytes - Metric Threshold', 102767, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102768, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count (Daily) - Metric Threshold', 102768, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102769, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Count - Metric Threshold', 102769, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102770, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value (Daily) - Metric Threshold', 102770, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102771, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS - EDR Value - Metric Threshold', 102771, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102772, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Bytes (Daily) - Metric Threshold', 102772, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102773, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Bytes - Metric Threshold', 102773, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102774, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Count (Daily) - Metric Threshold', 102774, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102775, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Count - Metric Threshold', 102775, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102776, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Value (Daily) - Metric Threshold', 102776, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102777, 'WAP ICCS: ST_DATA_WAP_OUTBOUND_ROAMERS_STRIP - EDR Value - Metric Threshold', 102777, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));



insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112601, 102601, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122601, 102601, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112602, 102602, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122602, 102602, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112603, 102603, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122603, 102603, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112604, 102604, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122604, 102604, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112605, 102605, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122605, 102605, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112606, 102606, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122606, 102606, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112607, 102607, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122607, 102607, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112608, 102608, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122608, 102608, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112609, 102609, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122609, 102609, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112610, 102610, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122610, 102610, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112611, 102611, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122611, 102611, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112612, 102612, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122612, 102612, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112613, 102613, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122613, 102613, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112614, 102614, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122614, 102614, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112615, 102615, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122615, 102615, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112616, 102616, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122616, 102616, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112617, 102617, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122617, 102617, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112618, 102618, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122618, 102618, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112619, 102619, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122619, 102619, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112620, 102620, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122620, 102620, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112621, 102621, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122621, 102621, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112622, 102622, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122622, 102622, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112623, 102623, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122623, 102623, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112624, 102624, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122624, 102624, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112625, 102625, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122625, 102625, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112626, 102626, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122626, 102626, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112627, 102627, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122627, 102627, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112628, 102628, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122628, 102628, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112629, 102629, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122629, 102629, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112630, 102630, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122630, 102630, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112631, 102631, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122631, 102631, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112632, 102632, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122632, 102632, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112633, 102633, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122633, 102633, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112634, 102634, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122634, 102634, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112635, 102635, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122635, 102635, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112636, 102636, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122636, 102636, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112637, 102637, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122637, 102637, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112638, 102638, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122638, 102638, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112639, 102639, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122639, 102639, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112640, 102640, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122640, 102640, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112641, 102641, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122641, 102641, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112642, 102642, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122642, 102642, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112643, 102643, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122643, 102643, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112644, 102644, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122644, 102644, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112645, 102645, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122645, 102645, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112646, 102646, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122646, 102646, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112647, 102647, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122647, 102647, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112648, 102648, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122648, 102648, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112649, 102649, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122649, 102649, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112650, 102650, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122650, 102650, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112651, 102651, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122651, 102651, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112652, 102652, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122652, 102652, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112653, 102653, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122653, 102653, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112654, 102654, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122654, 102654, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112655, 102655, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122655, 102655, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112656, 102656, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122656, 102656, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112657, 102657, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122657, 102657, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112658, 102658, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122658, 102658, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112659, 102659, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122659, 102659, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112660, 102660, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122660, 102660, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112661, 102661, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122661, 102661, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112662, 102662, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122662, 102662, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112663, 102663, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122663, 102663, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112664, 102664, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122664, 102664, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112665, 102665, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122665, 102665, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112666, 102666, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122666, 102666, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112667, 102667, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122667, 102667, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112668, 102668, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122668, 102668, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112669, 102669, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122669, 102669, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112670, 102670, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122670, 102670, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112671, 102671, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122671, 102671, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112672, 102672, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122672, 102672, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112673, 102673, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122673, 102673, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112674, 102674, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122674, 102674, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112675, 102675, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122675, 102675, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112676, 102676, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122676, 102676, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112677, 102677, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122677, 102677, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112678, 102678, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122678, 102678, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112679, 102679, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122679, 102679, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112680, 102680, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122680, 102680, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112681, 102681, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122681, 102681, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112682, 102682, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122682, 102682, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112683, 102683, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122683, 102683, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112684, 102684, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122684, 102684, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112685, 102685, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122685, 102685, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112686, 102686, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122686, 102686, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112687, 102687, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122687, 102687, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112688, 102688, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122688, 102688, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112689, 102689, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122689, 102689, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112690, 102690, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122690, 102690, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112691, 102691, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122691, 102691, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112692, 102692, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122692, 102692, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112693, 102693, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122693, 102693, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112694, 102694, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122694, 102694, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112695, 102695, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122695, 102695, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112696, 102696, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122696, 102696, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112697, 102697, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122697, 102697, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112698, 102698, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122698, 102698, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112699, 102699, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122699, 102699, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112700, 102700, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122700, 102700, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112701, 102701, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122701, 102701, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112702, 102702, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122702, 102702, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112703, 102703, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122703, 102703, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112704, 102704, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122704, 102704, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112705, 102705, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122705, 102705, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112706, 102706, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122706, 102706, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112707, 102707, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122707, 102707, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112708, 102708, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122708, 102708, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112709, 102709, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122709, 102709, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112710, 102710, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122710, 102710, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112711, 102711, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122711, 102711, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112712, 102712, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122712, 102712, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112713, 102713, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122713, 102713, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112714, 102714, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122714, 102714, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112715, 102715, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122715, 102715, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112716, 102716, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122716, 102716, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112717, 102717, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122717, 102717, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112718, 102718, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122718, 102718, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112719, 102719, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122719, 102719, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112720, 102720, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122720, 102720, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112721, 102721, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122721, 102721, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112722, 102722, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122722, 102722, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112723, 102723, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122723, 102723, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112724, 102724, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122724, 102724, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112725, 102725, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122725, 102725, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112726, 102726, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122726, 102726, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112727, 102727, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122727, 102727, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112728, 102728, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122728, 102728, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112729, 102729, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122729, 102729, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112730, 102730, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122730, 102730, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112731, 102731, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122731, 102731, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112732, 102732, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122732, 102732, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112733, 102733, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122733, 102733, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112734, 102734, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122734, 102734, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112735, 102735, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122735, 102735, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112736, 102736, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122736, 102736, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112737, 102737, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122737, 102737, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112738, 102738, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122738, 102738, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112739, 102739, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122739, 102739, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112740, 102740, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122740, 102740, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112741, 102741, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122741, 102741, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112742, 102742, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122742, 102742, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112743, 102743, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122743, 102743, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112744, 102744, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122744, 102744, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112745, 102745, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122745, 102745, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112746, 102746, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122746, 102746, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112747, 102747, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122747, 102747, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112748, 102748, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122748, 102748, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112749, 102749, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122749, 102749, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112750, 102750, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122750, 102750, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112751, 102751, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122751, 102751, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112752, 102752, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122752, 102752, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112753, 102753, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122753, 102753, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112754, 102754, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122754, 102754, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112755, 102755, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122755, 102755, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112756, 102756, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122756, 102756, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112757, 102757, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122757, 102757, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112758, 102758, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122758, 102758, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112759, 102759, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122759, 102759, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112760, 102760, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122760, 102760, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112761, 102761, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122761, 102761, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112762, 102762, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122762, 102762, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112763, 102763, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122763, 102763, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112764, 102764, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122764, 102764, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112765, 102765, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122765, 102765, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112766, 102766, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122766, 102766, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112767, 102767, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122767, 102767, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112768, 102768, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122768, 102768, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112769, 102769, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122769, 102769, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112770, 102770, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122770, 102770, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112771, 102771, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122771, 102771, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112772, 102772, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122772, 102772, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112773, 102773, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122773, 102773, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112774, 102774, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122774, 102774, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112775, 102775, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122775, 102775, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112776, 102776, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122776, 102776, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112777, 102777, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122777, 102777, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);





insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112601, 1, 102601, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122601, 2, 102601, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132601, 3, 102601, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142601, 4, 102601, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152601, 5, 102601, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162601, 6, 102601, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172601, 7, 102601, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112602, 1, 102602, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122602, 2, 102602, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132602, 3, 102602, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142602, 4, 102602, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152602, 5, 102602, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162602, 6, 102602, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172602, 7, 102602, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112603, 1, 102603, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122603, 2, 102603, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132603, 3, 102603, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142603, 4, 102603, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152603, 5, 102603, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162603, 6, 102603, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172603, 7, 102603, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112604, 1, 102604, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122604, 2, 102604, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132604, 3, 102604, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142604, 4, 102604, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152604, 5, 102604, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162604, 6, 102604, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172604, 7, 102604, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112605, 1, 102605, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122605, 2, 102605, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132605, 3, 102605, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142605, 4, 102605, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152605, 5, 102605, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162605, 6, 102605, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172605, 7, 102605, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112606, 1, 102606, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122606, 2, 102606, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132606, 3, 102606, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142606, 4, 102606, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152606, 5, 102606, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162606, 6, 102606, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172606, 7, 102606, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112607, 1, 102607, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122607, 2, 102607, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132607, 3, 102607, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142607, 4, 102607, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152607, 5, 102607, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162607, 6, 102607, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172607, 7, 102607, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112608, 1, 102608, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122608, 2, 102608, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132608, 3, 102608, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142608, 4, 102608, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152608, 5, 102608, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162608, 6, 102608, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172608, 7, 102608, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112609, 1, 102609, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122609, 2, 102609, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132609, 3, 102609, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142609, 4, 102609, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152609, 5, 102609, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162609, 6, 102609, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172609, 7, 102609, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112610, 1, 102610, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122610, 2, 102610, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132610, 3, 102610, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142610, 4, 102610, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152610, 5, 102610, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162610, 6, 102610, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172610, 7, 102610, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112611, 1, 102611, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122611, 2, 102611, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132611, 3, 102611, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142611, 4, 102611, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152611, 5, 102611, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162611, 6, 102611, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172611, 7, 102611, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112612, 1, 102612, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122612, 2, 102612, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132612, 3, 102612, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142612, 4, 102612, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152612, 5, 102612, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162612, 6, 102612, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172612, 7, 102612, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112613, 1, 102613, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122613, 2, 102613, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132613, 3, 102613, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142613, 4, 102613, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152613, 5, 102613, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162613, 6, 102613, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172613, 7, 102613, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112614, 1, 102614, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122614, 2, 102614, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132614, 3, 102614, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142614, 4, 102614, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152614, 5, 102614, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162614, 6, 102614, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172614, 7, 102614, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112615, 1, 102615, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122615, 2, 102615, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132615, 3, 102615, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142615, 4, 102615, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152615, 5, 102615, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162615, 6, 102615, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172615, 7, 102615, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112616, 1, 102616, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122616, 2, 102616, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132616, 3, 102616, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142616, 4, 102616, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152616, 5, 102616, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162616, 6, 102616, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172616, 7, 102616, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112617, 1, 102617, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122617, 2, 102617, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132617, 3, 102617, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142617, 4, 102617, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152617, 5, 102617, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162617, 6, 102617, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172617, 7, 102617, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112618, 1, 102618, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122618, 2, 102618, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132618, 3, 102618, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142618, 4, 102618, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152618, 5, 102618, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162618, 6, 102618, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172618, 7, 102618, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112619, 1, 102619, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122619, 2, 102619, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132619, 3, 102619, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142619, 4, 102619, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152619, 5, 102619, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162619, 6, 102619, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172619, 7, 102619, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112620, 1, 102620, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122620, 2, 102620, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132620, 3, 102620, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142620, 4, 102620, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152620, 5, 102620, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162620, 6, 102620, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172620, 7, 102620, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112621, 1, 102621, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122621, 2, 102621, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132621, 3, 102621, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142621, 4, 102621, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152621, 5, 102621, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162621, 6, 102621, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172621, 7, 102621, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112622, 1, 102622, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122622, 2, 102622, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132622, 3, 102622, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142622, 4, 102622, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152622, 5, 102622, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162622, 6, 102622, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172622, 7, 102622, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112623, 1, 102623, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122623, 2, 102623, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132623, 3, 102623, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142623, 4, 102623, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152623, 5, 102623, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162623, 6, 102623, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172623, 7, 102623, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112624, 1, 102624, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122624, 2, 102624, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132624, 3, 102624, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142624, 4, 102624, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152624, 5, 102624, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162624, 6, 102624, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172624, 7, 102624, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112625, 1, 102625, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122625, 2, 102625, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132625, 3, 102625, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142625, 4, 102625, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152625, 5, 102625, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162625, 6, 102625, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172625, 7, 102625, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112626, 1, 102626, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122626, 2, 102626, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132626, 3, 102626, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142626, 4, 102626, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152626, 5, 102626, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162626, 6, 102626, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172626, 7, 102626, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112627, 1, 102627, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122627, 2, 102627, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132627, 3, 102627, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142627, 4, 102627, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152627, 5, 102627, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162627, 6, 102627, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172627, 7, 102627, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112628, 1, 102628, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122628, 2, 102628, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132628, 3, 102628, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142628, 4, 102628, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152628, 5, 102628, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162628, 6, 102628, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172628, 7, 102628, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112629, 1, 102629, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122629, 2, 102629, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132629, 3, 102629, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142629, 4, 102629, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152629, 5, 102629, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162629, 6, 102629, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172629, 7, 102629, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112630, 1, 102630, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122630, 2, 102630, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132630, 3, 102630, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142630, 4, 102630, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152630, 5, 102630, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162630, 6, 102630, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172630, 7, 102630, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112631, 1, 102631, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122631, 2, 102631, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132631, 3, 102631, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142631, 4, 102631, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152631, 5, 102631, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162631, 6, 102631, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172631, 7, 102631, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112632, 1, 102632, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122632, 2, 102632, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132632, 3, 102632, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142632, 4, 102632, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152632, 5, 102632, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162632, 6, 102632, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172632, 7, 102632, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112633, 1, 102633, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122633, 2, 102633, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132633, 3, 102633, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142633, 4, 102633, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152633, 5, 102633, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162633, 6, 102633, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172633, 7, 102633, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112634, 1, 102634, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122634, 2, 102634, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132634, 3, 102634, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142634, 4, 102634, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152634, 5, 102634, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162634, 6, 102634, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172634, 7, 102634, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112635, 1, 102635, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122635, 2, 102635, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132635, 3, 102635, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142635, 4, 102635, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152635, 5, 102635, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162635, 6, 102635, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172635, 7, 102635, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112636, 1, 102636, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122636, 2, 102636, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132636, 3, 102636, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142636, 4, 102636, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152636, 5, 102636, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162636, 6, 102636, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172636, 7, 102636, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112637, 1, 102637, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122637, 2, 102637, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132637, 3, 102637, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142637, 4, 102637, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152637, 5, 102637, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162637, 6, 102637, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172637, 7, 102637, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112638, 1, 102638, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122638, 2, 102638, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132638, 3, 102638, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142638, 4, 102638, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152638, 5, 102638, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162638, 6, 102638, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172638, 7, 102638, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112639, 1, 102639, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122639, 2, 102639, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132639, 3, 102639, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142639, 4, 102639, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152639, 5, 102639, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162639, 6, 102639, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172639, 7, 102639, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112640, 1, 102640, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122640, 2, 102640, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132640, 3, 102640, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142640, 4, 102640, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152640, 5, 102640, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162640, 6, 102640, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172640, 7, 102640, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112641, 1, 102641, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122641, 2, 102641, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132641, 3, 102641, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142641, 4, 102641, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152641, 5, 102641, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162641, 6, 102641, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172641, 7, 102641, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112642, 1, 102642, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122642, 2, 102642, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132642, 3, 102642, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142642, 4, 102642, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152642, 5, 102642, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162642, 6, 102642, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172642, 7, 102642, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112643, 1, 102643, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122643, 2, 102643, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132643, 3, 102643, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142643, 4, 102643, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152643, 5, 102643, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162643, 6, 102643, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172643, 7, 102643, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112644, 1, 102644, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122644, 2, 102644, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132644, 3, 102644, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142644, 4, 102644, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152644, 5, 102644, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162644, 6, 102644, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172644, 7, 102644, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112645, 1, 102645, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122645, 2, 102645, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132645, 3, 102645, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142645, 4, 102645, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152645, 5, 102645, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162645, 6, 102645, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172645, 7, 102645, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112646, 1, 102646, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122646, 2, 102646, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132646, 3, 102646, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142646, 4, 102646, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152646, 5, 102646, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162646, 6, 102646, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172646, 7, 102646, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112647, 1, 102647, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122647, 2, 102647, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132647, 3, 102647, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142647, 4, 102647, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152647, 5, 102647, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162647, 6, 102647, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172647, 7, 102647, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112648, 1, 102648, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122648, 2, 102648, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132648, 3, 102648, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142648, 4, 102648, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152648, 5, 102648, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162648, 6, 102648, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172648, 7, 102648, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112649, 1, 102649, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122649, 2, 102649, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132649, 3, 102649, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142649, 4, 102649, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152649, 5, 102649, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162649, 6, 102649, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172649, 7, 102649, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112650, 1, 102650, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122650, 2, 102650, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132650, 3, 102650, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142650, 4, 102650, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152650, 5, 102650, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162650, 6, 102650, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172650, 7, 102650, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112651, 1, 102651, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122651, 2, 102651, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132651, 3, 102651, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142651, 4, 102651, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152651, 5, 102651, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162651, 6, 102651, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172651, 7, 102651, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112652, 1, 102652, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122652, 2, 102652, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132652, 3, 102652, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142652, 4, 102652, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152652, 5, 102652, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162652, 6, 102652, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172652, 7, 102652, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112653, 1, 102653, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122653, 2, 102653, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132653, 3, 102653, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142653, 4, 102653, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152653, 5, 102653, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162653, 6, 102653, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172653, 7, 102653, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112654, 1, 102654, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122654, 2, 102654, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132654, 3, 102654, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142654, 4, 102654, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152654, 5, 102654, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162654, 6, 102654, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172654, 7, 102654, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112655, 1, 102655, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122655, 2, 102655, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132655, 3, 102655, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142655, 4, 102655, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152655, 5, 102655, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162655, 6, 102655, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172655, 7, 102655, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112656, 1, 102656, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122656, 2, 102656, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132656, 3, 102656, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142656, 4, 102656, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152656, 5, 102656, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162656, 6, 102656, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172656, 7, 102656, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112657, 1, 102657, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122657, 2, 102657, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132657, 3, 102657, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142657, 4, 102657, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152657, 5, 102657, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162657, 6, 102657, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172657, 7, 102657, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112658, 1, 102658, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122658, 2, 102658, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132658, 3, 102658, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142658, 4, 102658, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152658, 5, 102658, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162658, 6, 102658, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172658, 7, 102658, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112659, 1, 102659, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122659, 2, 102659, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132659, 3, 102659, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142659, 4, 102659, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152659, 5, 102659, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162659, 6, 102659, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172659, 7, 102659, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112660, 1, 102660, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122660, 2, 102660, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132660, 3, 102660, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142660, 4, 102660, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152660, 5, 102660, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162660, 6, 102660, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172660, 7, 102660, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112661, 1, 102661, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122661, 2, 102661, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132661, 3, 102661, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142661, 4, 102661, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152661, 5, 102661, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162661, 6, 102661, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172661, 7, 102661, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112662, 1, 102662, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122662, 2, 102662, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132662, 3, 102662, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142662, 4, 102662, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152662, 5, 102662, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162662, 6, 102662, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172662, 7, 102662, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112663, 1, 102663, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122663, 2, 102663, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132663, 3, 102663, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142663, 4, 102663, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152663, 5, 102663, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162663, 6, 102663, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172663, 7, 102663, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112664, 1, 102664, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122664, 2, 102664, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132664, 3, 102664, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142664, 4, 102664, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152664, 5, 102664, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162664, 6, 102664, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172664, 7, 102664, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112665, 1, 102665, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122665, 2, 102665, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132665, 3, 102665, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142665, 4, 102665, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152665, 5, 102665, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162665, 6, 102665, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172665, 7, 102665, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112666, 1, 102666, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122666, 2, 102666, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132666, 3, 102666, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142666, 4, 102666, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152666, 5, 102666, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162666, 6, 102666, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172666, 7, 102666, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112667, 1, 102667, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122667, 2, 102667, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132667, 3, 102667, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142667, 4, 102667, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152667, 5, 102667, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162667, 6, 102667, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172667, 7, 102667, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112668, 1, 102668, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122668, 2, 102668, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132668, 3, 102668, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142668, 4, 102668, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152668, 5, 102668, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162668, 6, 102668, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172668, 7, 102668, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112669, 1, 102669, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122669, 2, 102669, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132669, 3, 102669, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142669, 4, 102669, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152669, 5, 102669, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162669, 6, 102669, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172669, 7, 102669, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112670, 1, 102670, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122670, 2, 102670, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132670, 3, 102670, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142670, 4, 102670, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152670, 5, 102670, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162670, 6, 102670, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172670, 7, 102670, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112671, 1, 102671, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122671, 2, 102671, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132671, 3, 102671, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142671, 4, 102671, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152671, 5, 102671, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162671, 6, 102671, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172671, 7, 102671, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112672, 1, 102672, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122672, 2, 102672, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132672, 3, 102672, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142672, 4, 102672, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152672, 5, 102672, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162672, 6, 102672, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172672, 7, 102672, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112673, 1, 102673, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122673, 2, 102673, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132673, 3, 102673, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142673, 4, 102673, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152673, 5, 102673, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162673, 6, 102673, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172673, 7, 102673, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112674, 1, 102674, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122674, 2, 102674, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132674, 3, 102674, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142674, 4, 102674, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152674, 5, 102674, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162674, 6, 102674, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172674, 7, 102674, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112675, 1, 102675, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122675, 2, 102675, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132675, 3, 102675, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142675, 4, 102675, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152675, 5, 102675, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162675, 6, 102675, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172675, 7, 102675, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112676, 1, 102676, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122676, 2, 102676, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132676, 3, 102676, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142676, 4, 102676, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152676, 5, 102676, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162676, 6, 102676, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172676, 7, 102676, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112677, 1, 102677, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122677, 2, 102677, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132677, 3, 102677, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142677, 4, 102677, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152677, 5, 102677, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162677, 6, 102677, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172677, 7, 102677, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112678, 1, 102678, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122678, 2, 102678, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132678, 3, 102678, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142678, 4, 102678, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152678, 5, 102678, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162678, 6, 102678, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172678, 7, 102678, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112679, 1, 102679, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122679, 2, 102679, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132679, 3, 102679, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142679, 4, 102679, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152679, 5, 102679, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162679, 6, 102679, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172679, 7, 102679, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112680, 1, 102680, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122680, 2, 102680, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132680, 3, 102680, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142680, 4, 102680, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152680, 5, 102680, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162680, 6, 102680, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172680, 7, 102680, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112681, 1, 102681, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122681, 2, 102681, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132681, 3, 102681, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142681, 4, 102681, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152681, 5, 102681, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162681, 6, 102681, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172681, 7, 102681, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112682, 1, 102682, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122682, 2, 102682, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132682, 3, 102682, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142682, 4, 102682, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152682, 5, 102682, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162682, 6, 102682, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172682, 7, 102682, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112683, 1, 102683, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122683, 2, 102683, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132683, 3, 102683, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142683, 4, 102683, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152683, 5, 102683, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162683, 6, 102683, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172683, 7, 102683, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112684, 1, 102684, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122684, 2, 102684, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132684, 3, 102684, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142684, 4, 102684, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152684, 5, 102684, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162684, 6, 102684, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172684, 7, 102684, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112685, 1, 102685, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122685, 2, 102685, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132685, 3, 102685, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142685, 4, 102685, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152685, 5, 102685, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162685, 6, 102685, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172685, 7, 102685, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112686, 1, 102686, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122686, 2, 102686, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132686, 3, 102686, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142686, 4, 102686, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152686, 5, 102686, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162686, 6, 102686, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172686, 7, 102686, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112687, 1, 102687, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122687, 2, 102687, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132687, 3, 102687, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142687, 4, 102687, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152687, 5, 102687, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162687, 6, 102687, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172687, 7, 102687, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112688, 1, 102688, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122688, 2, 102688, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132688, 3, 102688, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142688, 4, 102688, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152688, 5, 102688, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162688, 6, 102688, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172688, 7, 102688, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112689, 1, 102689, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122689, 2, 102689, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132689, 3, 102689, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142689, 4, 102689, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152689, 5, 102689, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162689, 6, 102689, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172689, 7, 102689, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112690, 1, 102690, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122690, 2, 102690, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132690, 3, 102690, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142690, 4, 102690, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152690, 5, 102690, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162690, 6, 102690, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172690, 7, 102690, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112691, 1, 102691, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122691, 2, 102691, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132691, 3, 102691, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142691, 4, 102691, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152691, 5, 102691, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162691, 6, 102691, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172691, 7, 102691, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112692, 1, 102692, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122692, 2, 102692, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132692, 3, 102692, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142692, 4, 102692, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152692, 5, 102692, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162692, 6, 102692, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172692, 7, 102692, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112693, 1, 102693, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122693, 2, 102693, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132693, 3, 102693, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142693, 4, 102693, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152693, 5, 102693, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162693, 6, 102693, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172693, 7, 102693, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112694, 1, 102694, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122694, 2, 102694, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132694, 3, 102694, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142694, 4, 102694, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152694, 5, 102694, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162694, 6, 102694, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172694, 7, 102694, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112695, 1, 102695, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122695, 2, 102695, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132695, 3, 102695, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142695, 4, 102695, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152695, 5, 102695, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162695, 6, 102695, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172695, 7, 102695, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112696, 1, 102696, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122696, 2, 102696, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132696, 3, 102696, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142696, 4, 102696, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152696, 5, 102696, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162696, 6, 102696, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172696, 7, 102696, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112697, 1, 102697, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122697, 2, 102697, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132697, 3, 102697, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142697, 4, 102697, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152697, 5, 102697, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162697, 6, 102697, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172697, 7, 102697, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112698, 1, 102698, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122698, 2, 102698, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132698, 3, 102698, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142698, 4, 102698, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152698, 5, 102698, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162698, 6, 102698, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172698, 7, 102698, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112699, 1, 102699, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122699, 2, 102699, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132699, 3, 102699, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142699, 4, 102699, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152699, 5, 102699, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162699, 6, 102699, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172699, 7, 102699, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112700, 1, 102700, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122700, 2, 102700, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132700, 3, 102700, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142700, 4, 102700, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152700, 5, 102700, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162700, 6, 102700, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172700, 7, 102700, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112701, 1, 102701, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122701, 2, 102701, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132701, 3, 102701, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142701, 4, 102701, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152701, 5, 102701, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162701, 6, 102701, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172701, 7, 102701, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112702, 1, 102702, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122702, 2, 102702, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132702, 3, 102702, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142702, 4, 102702, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152702, 5, 102702, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162702, 6, 102702, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172702, 7, 102702, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112703, 1, 102703, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122703, 2, 102703, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132703, 3, 102703, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142703, 4, 102703, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152703, 5, 102703, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162703, 6, 102703, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172703, 7, 102703, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112704, 1, 102704, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122704, 2, 102704, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132704, 3, 102704, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142704, 4, 102704, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152704, 5, 102704, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162704, 6, 102704, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172704, 7, 102704, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112705, 1, 102705, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122705, 2, 102705, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132705, 3, 102705, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142705, 4, 102705, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152705, 5, 102705, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162705, 6, 102705, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172705, 7, 102705, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112706, 1, 102706, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122706, 2, 102706, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132706, 3, 102706, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142706, 4, 102706, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152706, 5, 102706, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162706, 6, 102706, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172706, 7, 102706, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112707, 1, 102707, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122707, 2, 102707, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132707, 3, 102707, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142707, 4, 102707, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152707, 5, 102707, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162707, 6, 102707, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172707, 7, 102707, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112708, 1, 102708, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122708, 2, 102708, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132708, 3, 102708, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142708, 4, 102708, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152708, 5, 102708, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162708, 6, 102708, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172708, 7, 102708, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112709, 1, 102709, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122709, 2, 102709, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132709, 3, 102709, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142709, 4, 102709, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152709, 5, 102709, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162709, 6, 102709, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172709, 7, 102709, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112710, 1, 102710, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122710, 2, 102710, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132710, 3, 102710, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142710, 4, 102710, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152710, 5, 102710, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162710, 6, 102710, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172710, 7, 102710, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112711, 1, 102711, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122711, 2, 102711, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132711, 3, 102711, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142711, 4, 102711, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152711, 5, 102711, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162711, 6, 102711, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172711, 7, 102711, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112712, 1, 102712, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122712, 2, 102712, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132712, 3, 102712, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142712, 4, 102712, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152712, 5, 102712, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162712, 6, 102712, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172712, 7, 102712, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112713, 1, 102713, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122713, 2, 102713, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132713, 3, 102713, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142713, 4, 102713, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152713, 5, 102713, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162713, 6, 102713, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172713, 7, 102713, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112714, 1, 102714, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122714, 2, 102714, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132714, 3, 102714, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142714, 4, 102714, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152714, 5, 102714, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162714, 6, 102714, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172714, 7, 102714, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112715, 1, 102715, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122715, 2, 102715, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132715, 3, 102715, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142715, 4, 102715, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152715, 5, 102715, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162715, 6, 102715, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172715, 7, 102715, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112716, 1, 102716, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122716, 2, 102716, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132716, 3, 102716, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142716, 4, 102716, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152716, 5, 102716, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162716, 6, 102716, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172716, 7, 102716, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112717, 1, 102717, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122717, 2, 102717, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132717, 3, 102717, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142717, 4, 102717, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152717, 5, 102717, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162717, 6, 102717, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172717, 7, 102717, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112718, 1, 102718, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122718, 2, 102718, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132718, 3, 102718, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142718, 4, 102718, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152718, 5, 102718, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162718, 6, 102718, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172718, 7, 102718, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112719, 1, 102719, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122719, 2, 102719, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132719, 3, 102719, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142719, 4, 102719, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152719, 5, 102719, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162719, 6, 102719, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172719, 7, 102719, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112720, 1, 102720, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122720, 2, 102720, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132720, 3, 102720, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142720, 4, 102720, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152720, 5, 102720, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162720, 6, 102720, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172720, 7, 102720, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112721, 1, 102721, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122721, 2, 102721, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132721, 3, 102721, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142721, 4, 102721, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152721, 5, 102721, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162721, 6, 102721, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172721, 7, 102721, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112722, 1, 102722, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122722, 2, 102722, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132722, 3, 102722, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142722, 4, 102722, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152722, 5, 102722, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162722, 6, 102722, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172722, 7, 102722, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112723, 1, 102723, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122723, 2, 102723, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132723, 3, 102723, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142723, 4, 102723, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152723, 5, 102723, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162723, 6, 102723, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172723, 7, 102723, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112724, 1, 102724, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122724, 2, 102724, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132724, 3, 102724, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142724, 4, 102724, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152724, 5, 102724, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162724, 6, 102724, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172724, 7, 102724, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112725, 1, 102725, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122725, 2, 102725, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132725, 3, 102725, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142725, 4, 102725, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152725, 5, 102725, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162725, 6, 102725, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172725, 7, 102725, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112726, 1, 102726, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122726, 2, 102726, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132726, 3, 102726, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142726, 4, 102726, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152726, 5, 102726, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162726, 6, 102726, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172726, 7, 102726, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112727, 1, 102727, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122727, 2, 102727, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132727, 3, 102727, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142727, 4, 102727, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152727, 5, 102727, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162727, 6, 102727, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172727, 7, 102727, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112728, 1, 102728, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122728, 2, 102728, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132728, 3, 102728, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142728, 4, 102728, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152728, 5, 102728, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162728, 6, 102728, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172728, 7, 102728, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112729, 1, 102729, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122729, 2, 102729, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132729, 3, 102729, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142729, 4, 102729, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152729, 5, 102729, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162729, 6, 102729, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172729, 7, 102729, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112730, 1, 102730, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122730, 2, 102730, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132730, 3, 102730, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142730, 4, 102730, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152730, 5, 102730, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162730, 6, 102730, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172730, 7, 102730, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112731, 1, 102731, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122731, 2, 102731, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132731, 3, 102731, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142731, 4, 102731, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152731, 5, 102731, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162731, 6, 102731, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172731, 7, 102731, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112732, 1, 102732, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122732, 2, 102732, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132732, 3, 102732, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142732, 4, 102732, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152732, 5, 102732, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162732, 6, 102732, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172732, 7, 102732, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112733, 1, 102733, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122733, 2, 102733, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132733, 3, 102733, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142733, 4, 102733, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152733, 5, 102733, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162733, 6, 102733, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172733, 7, 102733, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112734, 1, 102734, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122734, 2, 102734, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132734, 3, 102734, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142734, 4, 102734, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152734, 5, 102734, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162734, 6, 102734, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172734, 7, 102734, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112735, 1, 102735, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122735, 2, 102735, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132735, 3, 102735, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142735, 4, 102735, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152735, 5, 102735, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162735, 6, 102735, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172735, 7, 102735, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112736, 1, 102736, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122736, 2, 102736, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132736, 3, 102736, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142736, 4, 102736, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152736, 5, 102736, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162736, 6, 102736, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172736, 7, 102736, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112737, 1, 102737, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122737, 2, 102737, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132737, 3, 102737, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142737, 4, 102737, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152737, 5, 102737, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162737, 6, 102737, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172737, 7, 102737, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112738, 1, 102738, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122738, 2, 102738, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132738, 3, 102738, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142738, 4, 102738, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152738, 5, 102738, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162738, 6, 102738, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172738, 7, 102738, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112739, 1, 102739, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122739, 2, 102739, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132739, 3, 102739, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142739, 4, 102739, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152739, 5, 102739, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162739, 6, 102739, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172739, 7, 102739, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112740, 1, 102740, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122740, 2, 102740, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132740, 3, 102740, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142740, 4, 102740, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152740, 5, 102740, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162740, 6, 102740, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172740, 7, 102740, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112741, 1, 102741, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122741, 2, 102741, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132741, 3, 102741, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142741, 4, 102741, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152741, 5, 102741, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162741, 6, 102741, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172741, 7, 102741, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112742, 1, 102742, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122742, 2, 102742, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132742, 3, 102742, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142742, 4, 102742, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152742, 5, 102742, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162742, 6, 102742, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172742, 7, 102742, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112743, 1, 102743, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122743, 2, 102743, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132743, 3, 102743, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142743, 4, 102743, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152743, 5, 102743, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162743, 6, 102743, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172743, 7, 102743, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112744, 1, 102744, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122744, 2, 102744, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132744, 3, 102744, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142744, 4, 102744, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152744, 5, 102744, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162744, 6, 102744, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172744, 7, 102744, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112745, 1, 102745, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122745, 2, 102745, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132745, 3, 102745, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142745, 4, 102745, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152745, 5, 102745, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162745, 6, 102745, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172745, 7, 102745, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112746, 1, 102746, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122746, 2, 102746, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132746, 3, 102746, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142746, 4, 102746, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152746, 5, 102746, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162746, 6, 102746, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172746, 7, 102746, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112747, 1, 102747, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122747, 2, 102747, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132747, 3, 102747, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142747, 4, 102747, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152747, 5, 102747, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162747, 6, 102747, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172747, 7, 102747, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112748, 1, 102748, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122748, 2, 102748, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132748, 3, 102748, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142748, 4, 102748, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152748, 5, 102748, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162748, 6, 102748, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172748, 7, 102748, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112749, 1, 102749, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122749, 2, 102749, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132749, 3, 102749, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142749, 4, 102749, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152749, 5, 102749, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162749, 6, 102749, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172749, 7, 102749, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112750, 1, 102750, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122750, 2, 102750, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132750, 3, 102750, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142750, 4, 102750, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152750, 5, 102750, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162750, 6, 102750, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172750, 7, 102750, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112751, 1, 102751, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122751, 2, 102751, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132751, 3, 102751, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142751, 4, 102751, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152751, 5, 102751, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162751, 6, 102751, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172751, 7, 102751, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112752, 1, 102752, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122752, 2, 102752, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132752, 3, 102752, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142752, 4, 102752, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152752, 5, 102752, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162752, 6, 102752, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172752, 7, 102752, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112753, 1, 102753, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122753, 2, 102753, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132753, 3, 102753, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142753, 4, 102753, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152753, 5, 102753, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162753, 6, 102753, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172753, 7, 102753, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112754, 1, 102754, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122754, 2, 102754, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132754, 3, 102754, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142754, 4, 102754, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152754, 5, 102754, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162754, 6, 102754, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172754, 7, 102754, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112755, 1, 102755, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122755, 2, 102755, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132755, 3, 102755, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142755, 4, 102755, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152755, 5, 102755, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162755, 6, 102755, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172755, 7, 102755, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112756, 1, 102756, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122756, 2, 102756, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132756, 3, 102756, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142756, 4, 102756, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152756, 5, 102756, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162756, 6, 102756, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172756, 7, 102756, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112757, 1, 102757, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122757, 2, 102757, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132757, 3, 102757, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142757, 4, 102757, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152757, 5, 102757, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162757, 6, 102757, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172757, 7, 102757, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112758, 1, 102758, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122758, 2, 102758, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132758, 3, 102758, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142758, 4, 102758, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152758, 5, 102758, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162758, 6, 102758, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172758, 7, 102758, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112759, 1, 102759, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122759, 2, 102759, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132759, 3, 102759, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142759, 4, 102759, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152759, 5, 102759, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162759, 6, 102759, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172759, 7, 102759, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112760, 1, 102760, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122760, 2, 102760, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132760, 3, 102760, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142760, 4, 102760, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152760, 5, 102760, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162760, 6, 102760, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172760, 7, 102760, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112761, 1, 102761, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122761, 2, 102761, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132761, 3, 102761, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142761, 4, 102761, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152761, 5, 102761, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162761, 6, 102761, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172761, 7, 102761, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112762, 1, 102762, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122762, 2, 102762, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132762, 3, 102762, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142762, 4, 102762, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152762, 5, 102762, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162762, 6, 102762, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172762, 7, 102762, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112763, 1, 102763, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122763, 2, 102763, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132763, 3, 102763, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142763, 4, 102763, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152763, 5, 102763, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162763, 6, 102763, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172763, 7, 102763, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112764, 1, 102764, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122764, 2, 102764, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132764, 3, 102764, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142764, 4, 102764, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152764, 5, 102764, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162764, 6, 102764, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172764, 7, 102764, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112765, 1, 102765, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122765, 2, 102765, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132765, 3, 102765, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142765, 4, 102765, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152765, 5, 102765, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162765, 6, 102765, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172765, 7, 102765, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112766, 1, 102766, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122766, 2, 102766, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132766, 3, 102766, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142766, 4, 102766, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152766, 5, 102766, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162766, 6, 102766, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172766, 7, 102766, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112767, 1, 102767, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122767, 2, 102767, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132767, 3, 102767, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142767, 4, 102767, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152767, 5, 102767, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162767, 6, 102767, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172767, 7, 102767, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112768, 1, 102768, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122768, 2, 102768, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132768, 3, 102768, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142768, 4, 102768, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152768, 5, 102768, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162768, 6, 102768, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172768, 7, 102768, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112769, 1, 102769, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122769, 2, 102769, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132769, 3, 102769, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142769, 4, 102769, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152769, 5, 102769, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162769, 6, 102769, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172769, 7, 102769, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112770, 1, 102770, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122770, 2, 102770, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132770, 3, 102770, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142770, 4, 102770, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152770, 5, 102770, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162770, 6, 102770, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172770, 7, 102770, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112771, 1, 102771, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122771, 2, 102771, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132771, 3, 102771, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142771, 4, 102771, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152771, 5, 102771, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162771, 6, 102771, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172771, 7, 102771, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112772, 1, 102772, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122772, 2, 102772, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132772, 3, 102772, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142772, 4, 102772, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152772, 5, 102772, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162772, 6, 102772, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172772, 7, 102772, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112773, 1, 102773, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122773, 2, 102773, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132773, 3, 102773, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142773, 4, 102773, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152773, 5, 102773, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162773, 6, 102773, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172773, 7, 102773, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112774, 1, 102774, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122774, 2, 102774, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132774, 3, 102774, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142774, 4, 102774, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152774, 5, 102774, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162774, 6, 102774, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172774, 7, 102774, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112775, 1, 102775, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122775, 2, 102775, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132775, 3, 102775, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142775, 4, 102775, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152775, 5, 102775, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162775, 6, 102775, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172775, 7, 102775, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112776, 1, 102776, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122776, 2, 102776, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132776, 3, 102776, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142776, 4, 102776, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152776, 5, 102776, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162776, 6, 102776, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172776, 7, 102776, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112777, 1, 102777, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122777, 2, 102777, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132777, 3, 102777, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142777, 4, 102777, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152777, 5, 102777, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162777, 6, 102777, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172777, 7, 102777, 0, 86399);

----

commit;




insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102193, 'CCS Intermediate vs CCS Daily (Count) - ST_ALL - EDR Count (Daily) - Reconciliation Threshold', 'Percentage', 'CCS Intermediate vs CCS Daily (Count) - ST_ALL - EDR Count (Daily) - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102192, 'CCS Intermediate vs CCS Daily (Bytes) - ST_ALL - EDR Bytes (Daily) - Reconciliation Threshold', 'Percentage', 'CCS Intermediate vs CCS Daily (Bytes) - ST_ALL - EDR Bytes (Daily) - Reconciliation Threshold');

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102193, 'CCS Intermediate vs CCS Daily (Count) - ST_ALL - EDR Count (Daily) - Reconciliation Threshold', 102193, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102192, 'CCS Intermediate vs CCS Daily (Bytes) - ST_ALL - EDR Bytes (Daily) - Reconciliation Threshold', 102192, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));


insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122192, 102192, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122193, 102193, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);




insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132192, 3, 102192, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172192, 7, 102192, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152192, 5, 102192, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142192, 4, 102192, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122192, 2, 102192, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112192, 1, 102192, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162192, 6, 102192, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132193, 3, 102193, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142193, 4, 102193, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162193, 6, 102193, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122193, 2, 102193, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152193, 5, 102193, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112193, 1, 102193, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172193, 7, 102193, 0, 86399);




insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102182, 'CCS Intermediate vs CCS Daily (Value) - ST_ALL - EDR Value - Reconciliation Threshold', 'Percentage', 'CCS Intermediate vs CCS Daily (value) - ST_ALL - EDR Value - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102183, 'CCS Intermediate vs CCS Daily (Bytes) - ST_ALL - EDR Bytes - Reconciliation Threshold', 'Percentage', 'CCS Intermediate vs CCS Daily (value) - ST_ALL - EDR Bytes - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102184, 'CCS Intermediate vs CCS Daily (Count) - ST_ALL - EDR Count - Reconciliation Threshold', 'Percentage', 'CCS Intermediate vs CCS Daily (value) - ST_ALL - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102185, 'CCS vs WAP ICCS (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily) - Reconciliation Threshold', 'Percentage', 'CCS vs WAP ICCS (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily) - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102186, 'CCS  vs GPRS ICCS (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily) - Reconciliation Threshold', 'Percentage', 'CCS  vs GPRS ICCS (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily) - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102187, 'CCS Intermediate vs CCS Daily (value) - ST_ALL - EDR Value (Daily) - Reconciliation Threshold', 'Percentage', 'CCS Intermediate vs CCS Daily (value) - ST_ALL - EDR Value (Daily) - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102188, 'GPRS ICCS vs ICCS Billed (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily) - Reconciliation Threshold', 'Percentage', 'GPRS ICCS vs ICCS Billed (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily) - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102189, 'WAP ICCS vs ICCS Billed (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily) - Reconciliation Threshold', 'Percentage', 'WAP ICCS vs ICCS Billed (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily) - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102190, 'CCS vs WAP ICCS (bytes) - ST_DATA _STRIP - EDR Bytes (Daily) - Reconciliation Threshold', 'Percentage', 'CCS vs WAP ICCS (bytes) - ST_DATA _STRIP - EDR Bytes (Daily) - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (102191, 'CCS vs GPRS ICCS (bytes) - ST_DATA _STRIP - EDR Bytes (Daily) - Reconciliation Threshold', 'Percentage', 'CCS vs GPRS ICCS (bytes) - ST_DATA _STRIP - EDR Bytes (Daily) - Reconciliation Threshold');



insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102182, 'CCS Intermediate vs CCS Daily (Value) - ST_ALL - EDR Value - Reconciliation Threshold', 102182, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102183, 'CCS Intermediate vs CCS Daily (Bytes) - ST_ALL - EDR Bytes - Reconciliation Threshold', 102183, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102184, 'CCS Intermediate vs CCS Daily (Count) - ST_ALL - EDR Count - Reconciliation Threshold', 102184, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102185, 'CCS vs WAP ICCS (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily) - Reconciliation Threshold', 102185, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102186, 'CCS  vs GPRS ICCS (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily) - Reconciliation Threshold', 102186, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102187, 'CCS Intermediate vs CCS Daily (value) - ST_ALL - EDR Value (Daily) - Reconciliation Threshold', 102187, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102188, 'GPRS ICCS vs ICCS Billed (bytes) - ST_DATA_GPRS_POSTPAID - EDR Bytes (Daily) - Reconciliation Threshold', 102188, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102189, 'WAP ICCS vs ICCS Billed (bytes) - ST_DATA_WAP_POSTPAID - EDR Bytes (Daily) - Reconciliation Threshold', 102189, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102190, 'CCS vs WAP ICCS (bytes) - ST_DATA _STRIP - EDR Bytes (Daily) - Reconciliation Threshold', 102190, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (102191, 'CCS vs GPRS ICCS (bytes) - ST_DATA _STRIP - EDR Bytes (Daily) - Reconciliation Threshold', 102191, null, 'I', to_date('01-10-2014', 'dd-mm-yyyy'));




insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112182, 102182, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122182, 102182, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112183, 102183, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122183, 102183, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112184, 102184, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122184, 102184, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112185, 102185, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122185, 102185, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112186, 102186, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122186, 102186, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112187, 102187, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122187, 102187, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112188, 102188, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122188, 102188, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112189, 102189, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122189, 102189, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112190, 102190, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122190, 102190, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (112191, 102191, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (122191, 102191, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);




insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112182, 1, 102182, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122182, 2, 102182, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132182, 3, 102182, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142182, 4, 102182, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152182, 5, 102182, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162182, 6, 102182, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172182, 7, 102182, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112183, 1, 102183, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122183, 2, 102183, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132183, 3, 102183, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142183, 4, 102183, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152183, 5, 102183, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162183, 6, 102183, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172183, 7, 102183, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112184, 1, 102184, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122184, 2, 102184, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132184, 3, 102184, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142184, 4, 102184, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152184, 5, 102184, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162184, 6, 102184, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172184, 7, 102184, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112185, 1, 102185, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122185, 2, 102185, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132185, 3, 102185, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142185, 4, 102185, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152185, 5, 102185, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162185, 6, 102185, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172185, 7, 102185, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112186, 1, 102186, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122186, 2, 102186, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132186, 3, 102186, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142186, 4, 102186, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152186, 5, 102186, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162186, 6, 102186, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172186, 7, 102186, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112187, 1, 102187, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122187, 2, 102187, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132187, 3, 102187, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142187, 4, 102187, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152187, 5, 102187, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162187, 6, 102187, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172187, 7, 102187, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112188, 1, 102188, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122188, 2, 102188, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132188, 3, 102188, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142188, 4, 102188, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152188, 5, 102188, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162188, 6, 102188, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172188, 7, 102188, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112189, 1, 102189, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122189, 2, 102189, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132189, 3, 102189, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142189, 4, 102189, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152189, 5, 102189, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162189, 6, 102189, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172189, 7, 102189, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112190, 1, 102190, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122190, 2, 102190, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132190, 3, 102190, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142190, 4, 102190, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152190, 5, 102190, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162190, 6, 102190, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172190, 7, 102190, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (112191, 1, 102191, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (122191, 2, 102191, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (132191, 3, 102191, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (142191, 4, 102191, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (152191, 5, 102191, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (162191, 6, 102191, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (172191, 7, 102191, 0, 86399);


commit;

exit
