select on mobile.iccs_sub to jobs;
select on mobile.iccs_onxp_packages to jobs;
exit;
