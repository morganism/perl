#!/bin/bash

log="VFI-UM_1_1_0_upgrade_`date +\"%d%m%Y%H%M%S\"`.log"
echo "VFI-UM_1_1_0 `date`" > $log

# make sure ASCERTAIN_BUILD is set
if [ ! -e $ASCERTAIN_BUILD/upgrade/VERSION_1_1_0 ]; then
        echo "ASCERTAIN_BUILD needs to be set to the VFI_UM_1_1_0 build" 2>&1 | tee -a $log
        exit 1
fi


##############################################
#Check the current OS to choose right commands
#for options compatibility
##############################################
OS=`uname -a | grep Linux`
if [ "$OS" != "" ]; then
        ##Linux commands
        AWK_CMD="awk"
        DIFF_CMD="diff"
else
        #Solaris commands
        AWK_CMD="nawk"
        DIFF_CMD="sdiff"
fi

##############################################
# check to see that ASCERTAIN_BUILD is set
##############################################
if [ -z $ASCERTAIN_BUILD ]; then
  echo "ASCERTAIN_BUILD environment variable not set, aborting"  2>&1 | tee -a $log
  exit
fi

##############################################
# check to see that ORACLE_SID is set
##############################################
if [ -z $ORACLE_SID ]; then
  echo "ORACLE_SID environment variable not set, aborting"  2>&1 | tee -a $log
  exit
fi

##############################################
# check to see that CARTESIAN_PROPERTIES is set
##############################################
if [ -z $CARTESIAN_PROPERTIES ]; then
  echo "CARTESIAN_PROPERTIES environment variable not set, aborting"  2>&1 | tee -a $log
  exit
fi

##############################################
# function to get passwords from .cpm.xml
##############################################
setPasswords(){
  cpm=`grep CPM_CONFIG_FILE $CARTESIAN_PROPERTIES | $AWK_CMD '{print $2}' FS="\="`
  for line in $(egrep "(user=|password=)" $cpm) ; do
        lower_line=`echo $line | tr "[:upper:]" "[:lower:]"`
    eval "$lower_line"
    if [ "$password" != "" ] ; then
      eval "export ${user}_pass=\"$password\""
      user=""
      password=""
    fi
  done
}

##############################################
# load passwords using password function
##############################################
setPasswords

sqlplus dgf/$dgf_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/upgrade/VERSION_1_1_0/sql/MZ_Phase_II/dgf.sql
sqlplus gdl/$gdl_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/upgrade/VERSION_1_1_0/sql/MZ_Phase_II/gdl.sql
sqlplus imm/$imm_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/upgrade/VERSION_1_1_0/sql/MZ_Phase_II/imm.sql
sqlplus customer/$customer_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/upgrade/VERSION_1_1_0/sql/MZ_Phase_II/customer.sql
sqlplus jobs/$jobs_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/upgrade/VERSION_1_1_0/sql/MZ_Phase_II/jobs.sql
sqlplus web/$web_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/upgrade/VERSION_1_1_0/sql/MZ_Phase_II/web.sql
sqlplus um/$um_pass@$ORACLE_SID @ $ASCERTAIN_BUILD/upgrade/VERSION_1_1_0/sql/MZ_Phase_II/um.sql


echo "VFI-UM_1_1_0 update complete" 2>&1 | tee -a $log
