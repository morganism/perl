



insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100292, '(M) Import SMS Interconnect', '-daemon no -load_type 1 -mapping 100090', 5000);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100293, '(M) Import MSS Interconnect', '-daemon no -load_type 1 -mapping 100091', 5000);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100294, '(M) Import MMS Interconnect', '-daemon no -load_type 1 -mapping 100092', 5000);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100295, '(M) Import DWF Interconnect', '-daemon no -load_type 1 -mapping 100093', 5000);


insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100561, '(M) Node DS73', '-node 100160 -match 100000 -daemon no -offset 1 --terminatetime 23:59:59', 1);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100562, '(M) Node DS74', '-node 100161 -match 100000 -daemon no -offset 1 --terminatetime 23:59:59', 1);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100563, '(M) Node DS75', '-node 100162 -match 100000 -daemon no -offset 1 --terminatetime 23:59:59', 1);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100564, '(M) Node DS76', '-node 100163 -match 100000 -daemon no -offset 1 --terminatetime 23:59:59', 1);



insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100761, '(M) Forecasts multi-job for node 100160', '-node_id 100160 -offset 1', 35004);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100762, '(M) Forecasts multi-job for node 100161', '-node_id 100161 -offset 1', 35004);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100763, '(M) Forecasts multi-job for node 100162', '-node_id 100162 -offset 1', 35004);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (100764, '(M) Forecasts multi-job for node 100163', '-node_id 100163 -offset 1', 35004);



insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105180, '(M) SMSC vs SMS Ict (count) - ST_ITC_SMS_OUT - EDR Count', '-mrec_id 100100 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105181, '(M) MSS vs MSS Ict (count) - ST_ITC_SMS_IN - EDR Count', '-mrec_id 100101 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105182, '(M) MSS vs MSS Ict (count) - ST_ITC_VOICE_OUT - EDR Count', '-mrec_id 100102 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105183, '(M) MSS vs MSS Ict (duration) - ST_ITC_VOICE_OUT - EDR Duration', '-mrec_id 100103 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105184, '(M) Raw MMS vs MMS Ict (count) - ST_ITC_MMS_OUT - EDR Count', '-mrec_id 100104 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105185, '(M) Raw MMS vs MMS Ict (bytes) - ST_ITC_MMS_OUT - EDR Bytes', '-mrec_id 100105 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105186, '(M) SMS Ict vs DWF Interconnect (count) - ST_ITC_SMS_OUT  - EDR Count', '-mrec_id 100106 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105187, '(M) MSS Ict vs DWF Interconnect (count) - ST_ITC_VOICE_OUT - EDR Count', '-mrec_id 100107 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105188, '(M) MSS Ict vs DWF Interconnect (duration) - ST_ITC_VOICE_OUT -  EDR Duration', '-mrec_id 100108 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105189, '(M) MMS Ict vs DWF Interconnect (count) - ST_ITC_MMS_OUT - EDR Count', '-mrec_id 100109 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105190, '(M) MMS Ict vs DWF Interconnect (bytes) - ST_ITC_MMS_OUT - EDR Bytes', '-mrec_id 100110 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105191, '(M) MSS vs MSS Ict (count) - ST_ITC_VOICE_IN - EDR Count', '-mrec_id 100111 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105192, '(M) MSS vs MSS Ict (duration) - ST_ITC_VOICE_IN - EDR Duration', '-mrec_id 100112 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105193, '(M) Raw MMS vs MMS Ict (count) - ST_ITC_MMS_IN - EDR Count', '-mrec_id 100113 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105194, '(M) Raw MMS vs MMS Ict (bytes) - ST_ITC_MMS_IN - EDR Bytes', '-mrec_id 100114 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105195, '(M) MSS Ict vs DWF Interconnect (count) - ST_ITC_SMS_IN  - EDR Count', '-mrec_id 100115 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105196, '(M) MSS Ict vs DWF Interconnect (count) - ST_ITC_VOICE_IN - EDR Count', '-mrec_id 100116 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105197, '(M) MSS Ict vs DWF Interconnect (duration) - ST_ITC_VOICE_IN -  EDR Duration', '-mrec_id 100117 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105198, '(M) MMS Ict vs DWF Interconnect (count) - ST_ITC_MMS_IN - EDR Count', '-mrec_id 100118 -num_days 7 -offset 8', 35005);

insert into jobs.multi_job_ref (MULTI_JOB_REF_ID, DESCRIPTION, PARAMETERS, JOB_CATEGORY_ID)
values (105199, '(M) MMS Ict vs DWF Interconnect (bytes) - ST_ITC_MMS_IN - EDR Bytes', '-mrec_id 100119 -num_days 7 -offset 8', 35005);



insert into jobs.job_code_ref (JOB_CODE_ID, WEIGHT, PARAMETERS, CLASS_NAME, BLOCKING_STATUS, DESCRIPTION, JOB_CATEGORY_ID, COMPRESSED_LOGS, PARAMETERS_URL)
values (100150, 1, '-source 100030 -daemon no -sample_size 4 -threads 1 -forecast_type METRIC -date_type rolling -offset 1 -metric "0" -duration 1', 'uk.co.cartesian.ascertain.um.job.ForecastsAndTrendsJob', 'source_100030', 'Forecast (all metrics) for source MR1CDC1 (DS73)', 35004, 'N', '');

insert into jobs.job_code_ref (JOB_CODE_ID, WEIGHT, PARAMETERS, CLASS_NAME, BLOCKING_STATUS, DESCRIPTION, JOB_CATEGORY_ID, COMPRESSED_LOGS, PARAMETERS_URL)
values (100151, 1, '-source 100031 -daemon no -sample_size 4 -threads 1 -forecast_type METRIC -date_type rolling -offset 1 -metric "0" -duration 1', 'uk.co.cartesian.ascertain.um.job.ForecastsAndTrendsJob', 'source_100031', 'Forecast (all metrics) for source MR2CDC1 (DS73)', 35004, 'N', '');

insert into jobs.job_code_ref (JOB_CODE_ID, WEIGHT, PARAMETERS, CLASS_NAME, BLOCKING_STATUS, DESCRIPTION, JOB_CATEGORY_ID, COMPRESSED_LOGS, PARAMETERS_URL)
values (100152, 1, '-source 100032 -daemon no -sample_size 4 -threads 1 -forecast_type METRIC -date_type rolling -offset 1 -metric "0" -duration 1', 'uk.co.cartesian.ascertain.um.job.ForecastsAndTrendsJob', 'source_100032', 'Forecast (all metrics) for source MR3CWT1 (DS73)', 35004, 'N', '');

insert into jobs.job_code_ref (JOB_CODE_ID, WEIGHT, PARAMETERS, CLASS_NAME, BLOCKING_STATUS, DESCRIPTION, JOB_CATEGORY_ID, COMPRESSED_LOGS, PARAMETERS_URL)
values (100153, 1, '-source 100033 -daemon no -sample_size 4 -threads 1 -forecast_type METRIC -date_type rolling -offset 1 -metric "0" -duration 1', 'uk.co.cartesian.ascertain.um.job.ForecastsAndTrendsJob', 'source_100033', 'Forecast (all metrics) for source MR4CWT1 (DS73)', 35004, 'N', '');

insert into jobs.job_code_ref (JOB_CODE_ID, WEIGHT, PARAMETERS, CLASS_NAME, BLOCKING_STATUS, DESCRIPTION, JOB_CATEGORY_ID, COMPRESSED_LOGS, PARAMETERS_URL)
values (100154, 1, '-source 100034 -daemon no -sample_size 4 -threads 1 -forecast_type METRIC -date_type rolling -offset 1 -metric "0" -duration 1', 'uk.co.cartesian.ascertain.um.job.ForecastsAndTrendsJob', 'source_100034', 'Forecast (all metrics) for source MSSP001 (DS74)', 35004, 'N', '');

insert into jobs.job_code_ref (JOB_CODE_ID, WEIGHT, PARAMETERS, CLASS_NAME, BLOCKING_STATUS, DESCRIPTION, JOB_CATEGORY_ID, COMPRESSED_LOGS, PARAMETERS_URL)
values (100155, 1, '-source 100035 -daemon no -sample_size 4 -threads 1 -forecast_type METRIC -date_type rolling -offset 1 -metric "0" -duration 1', 'uk.co.cartesian.ascertain.um.job.ForecastsAndTrendsJob', 'source_100035', 'Forecast (all metrics) for source MSSP002 (DS74)', 35004, 'N', '');

insert into jobs.job_code_ref (JOB_CODE_ID, WEIGHT, PARAMETERS, CLASS_NAME, BLOCKING_STATUS, DESCRIPTION, JOB_CATEGORY_ID, COMPRESSED_LOGS, PARAMETERS_URL)
values (100156, 1, '-source 100036 -daemon no -sample_size 4 -threads 1 -forecast_type METRIC -date_type rolling -offset 1 -metric "0" -duration 1', 'uk.co.cartesian.ascertain.um.job.ForecastsAndTrendsJob', 'source_100036', 'Forecast (all metrics) for source MSSP003 (DS74)', 35004, 'N', '');

insert into jobs.job_code_ref (JOB_CODE_ID, WEIGHT, PARAMETERS, CLASS_NAME, BLOCKING_STATUS, DESCRIPTION, JOB_CATEGORY_ID, COMPRESSED_LOGS, PARAMETERS_URL)
values (100157, 1, '-source 100037 -daemon no -sample_size 4 -threads 1 -forecast_type METRIC -date_type rolling -offset 1 -metric "0" -duration 1', 'uk.co.cartesian.ascertain.um.job.ForecastsAndTrendsJob', 'source_100037', 'Forecast (all metrics) for source MSSP004 (DS74)', 35004, 'N', '');

insert into jobs.job_code_ref (JOB_CODE_ID, WEIGHT, PARAMETERS, CLASS_NAME, BLOCKING_STATUS, DESCRIPTION, JOB_CATEGORY_ID, COMPRESSED_LOGS, PARAMETERS_URL)
values (100158, 1, '-source 100038 -daemon no -sample_size 4 -threads 1 -forecast_type METRIC -date_type rolling -offset 1 -metric "0" -duration 1', 'uk.co.cartesian.ascertain.um.job.ForecastsAndTrendsJob', 'source_100038', 'Forecast (all metrics) for source MM4 (DS75)', 35004, 'N', '');

insert into jobs.job_code_ref (JOB_CODE_ID, WEIGHT, PARAMETERS, CLASS_NAME, BLOCKING_STATUS, DESCRIPTION, JOB_CATEGORY_ID, COMPRESSED_LOGS, PARAMETERS_URL)
values (100159, 1, '-source 100039 -daemon no -sample_size 4 -threads 1 -forecast_type METRIC -date_type rolling -offset 1 -metric "0" -duration 1', 'uk.co.cartesian.ascertain.um.job.ForecastsAndTrendsJob', 'source_100039', 'Forecast (all metrics) for source DWF (DS76)', 35004, 'N', '');


insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100292, 102000, 100292, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100293, 102000, 100293, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100294, 102000, 100294, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100295, 102000, 100295, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100561, 104000, 100561, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100562, 104000, 100562, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100563, 104000, 100563, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100564, 104000, 100564, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100761, 100561, 100761, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100762, 100562, 100762, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100763, 100563, 100763, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (100764, 100564, 100764, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (102127, 100292, null, 5000);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (102128, 100293, null, 5000);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (102129, 100294, null, 5000);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (102130, 100295, null, 5000);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104213, 100761, null, 100150);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104214, 100761, null, 100151);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104215, 100761, null, 100152);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104216, 100761, null, 100153);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104217, 100762, null, 100154);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104218, 100762, null, 100155);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104219, 100762, null, 100156);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104220, 100762, null, 100157);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104221, 100763, null, 100158);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104222, 100764, null, 100159);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104510, 100561, null, 35110);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104511, 100561, null, 35105);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104512, 100562, null, 35110);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104513, 100562, null, 35105);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104514, 100563, null, 35110);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104515, 100563, null, 35105);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104516, 100564, null, 35110);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (104517, 100564, null, 35105);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105180, 105180, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105181, 105181, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105182, 105182, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105183, 105183, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105184, 105184, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105185, 105185, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105186, 105186, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105187, 105187, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105188, 105188, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105189, 105189, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105190, 105190, null, 35501);


insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105191, 105191, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105192, 105192, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105193, 105193, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105194, 105194, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105196, 105196, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105197, 105197, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105198, 105198, null, 35501);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105199, 105199, null, 35501);








insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105280, 105000, 105180, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105281, 105000, 105181, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105282, 105000, 105182, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105283, 105000, 105183, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105284, 105000, 105184, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105285, 105000, 105185, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105286, 105000, 105186, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105287, 105000, 105187, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105288, 105000, 105188, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105289, 105000, 105189, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105290, 105000, 105190, null);



insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105291, 105000, 105191, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105292, 105000, 105192, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105293, 105000, 105193, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105294, 105000, 105194, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105296, 105000, 105196, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105297, 105000, 105197, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105298, 105000, 105198, null);

insert into jobs.multi_job_comp_ref (COMP_REF_ID, PARENT_JOB_REF_ID, MULTI_JOB_REF_ID, JOB_CODE_ID)
values (105299, 105000, 105199, null);




insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100295, 100294);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100294, 100293);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100293, 100292);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100292, 100291);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100764, 104517);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100763, 104515);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100762, 104513);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (100761, 104511);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (104517, 104516);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (104515, 104514);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (104513, 104512);

insert into jobs.job_comp_dep_ref (PARENT_COMP_ID, DEPENDENT_COMP_ID)
values (104511, 104510);



commit;

exit
