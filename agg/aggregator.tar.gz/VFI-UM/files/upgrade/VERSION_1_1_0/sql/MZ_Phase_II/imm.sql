
insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100100, 'MSS: ST_ITC_VOICE_IN - EDR Duration - Metric Threshold', 'Percentage', 'MSS: ST_ITC_VOICE_IN - EDR Duration - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100101, 'MSS: ST_ITC_VOICE_IN - EDR Count - Metric Threshold', 'Percentage', 'MSS: ST_ITC_VOICE_IN - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100102, 'MSS: ST_ITC_VOICE_OUT - EDR Count - Metric Threshold', 'Percentage', 'MSS: ST_ITC_VOICE_OUT - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100103, 'MSS: ST_ITC_VOICE_OUT - EDR Duration - Metric Threshold', 'Percentage', 'MSS: ST_ITC_VOICE_OUT - EDR Duration - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100107, 'SMSC: ST_ITC_SMS_OUT - EDR Count - Metric Threshold', 'Percentage', 'SMSC: ST_ITC_SMS_OUT - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100108, 'MSS Interconnect: ST_ITC_VOICE_IN - EDR Count - Metric Threshold', 'Percentage', 'MSS Interconnect: ST_ITC_VOICE_IN - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100109, 'MSS Interconnect: ST_ITC_VOICE_IN - EDR Duration - Metric Threshold', 'Percentage', 'MSS Interconnect: ST_ITC_VOICE_IN - EDR Duration - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100110, 'Raw MMS: ST_ITC_MMS_OUT - EDR Bytes - Metric Threshold', 'Percentage', 'Raw MMS: ST_ITC_MMS_OUT - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100111, 'Raw MMS: ST_ITC_MMS_OUT - EDR Count - Metric Threshold', 'Percentage', 'Raw MMS: ST_ITC_MMS_OUT - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100112, 'Raw MMS: ST_ITC_MMS_IN - EDR Bytes - Metric Threshold', 'Percentage', 'Raw MMS: ST_ITC_MMS_IN - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100113, 'Raw MMS: ST_ITC_MMS_IN - EDR Count - Metric Threshold', 'Percentage', 'Raw MMS: ST_ITC_MMS_IN - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100114, 'SMS Interconnect: ST_ALL - EDR Count - Metric Threshold', 'Percentage', 'SMS Interconnect: ST_ALL - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100115, 'SMS Interconnect: ST_ITC_SMS_OUT - EDR Count - Metric Threshold', 'Percentage', 'SMS Interconnect: ST_ITC_SMS_OUT - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100116, 'MSS Interconnect: ST_ALL - EDR Count - Metric Threshold', 'Percentage', 'MSS Interconnect: ST_ALL - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100117, 'MSS Interconnect: ST_ALL - EDR Duration - Metric Threshold', 'Percentage', 'MSS Interconnect: ST_ALL - EDR Duration - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100118, 'MSS Interconnect: ST_ITC_VOICE_OUT - EDR Count - Metric Threshold', 'Percentage', 'MSS Interconnect: ST_ITC_VOICE_OUT - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100119, 'MSS Interconnect: ST_ITC_VOICE_OUT - EDR Duration - Metric Threshold', 'Percentage', 'MSS Interconnect: ST_ITC_VOICE_OUT - EDR Duration - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100120, 'MMS Interconnect: ST_ALL - EDR Count - Metric Threshold', 'Percentage', 'MMS Interconnect: ST_ALL - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100121, 'MMS Interconnect: ST_ALL - EDR Bytes - Metric Threshold', 'Percentage', 'MMS Interconnect: ST_ALL - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100122, 'MSS: ST_ITC_SMS_IN - EDR Count - Metric Threshold', 'Percentage', 'MSS: ST_ITC_SMS_IN - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100123, 'MSS Interconnect: ST_ITC_VOICE_IN - EDR Count - Metric Threshold', 'Percentage', 'MSS Interconnect: ST_ITC_VOICE_IN - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100124, 'MMS Interconnect: ST_ITC_MMS_OUT - EDR Bytes - Metric Threshold', 'Percentage', 'MMS Interconnect: ST_ITC_MMS_OUT - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100125, 'MMS Interconnect: ST_ITC_MMS_OUT - EDR Count - Metric Threshold', 'Percentage', 'MMS Interconnect: ST_ITC_MMS_OUT - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100126, 'MMS Interconnect: ST_ITC_MMS_IN - EDR Bytes - Metric Threshold', 'Percentage', 'MMS Interconnect: ST_ITC_MMS_IN - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100127, 'MMS Interconnect: ST_ITC_MMS_IN - EDR Count - Metric Threshold', 'Percentage', 'MMS Interconnect: ST_ITC_MMS_IN - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100128, 'DWF Output Record: ST_ALL - EDR Count - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ALL - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100129, 'DWF Output Record: ST_ALL - EDR Duration - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ALL - EDR Duration - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100130, 'DWF Output Record: ST_ALL - EDR Value - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ALL - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100131, 'DWF Output Record: ST_ALL - EDR Bytes - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ALL - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100132, 'MSS Interconnect: ST_ITC_VOICE_IN - EDR Duration - Metric Threshold', 'Percentage', 'MSS Interconnect: ST_ITC_VOICE_IN - EDR Duration - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100133, 'DWF Output Record: ST_ITC_VOICE_IN - EDR Count - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ITC_VOICE_IN - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100134, 'DWF Output Record: ST_ITC_VOICE_IN - EDR Duration - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ITC_VOICE_IN - EDR Duration - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100135, 'DWF Output Record: ST_ITC_MMS_OUT - EDR Bytes - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ITC_MMS_OUT - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100136, 'DWF Output Record: ST_ITC_MMS_OUT - EDR Count - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ITC_MMS_OUT - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100137, 'DWF Output Record: ST_ITC_MMS_IN - EDR Bytes - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ITC_MMS_IN - EDR Bytes - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100138, 'DWF Output Record: ST_ITC_MMS_IN - EDR Count - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ITC_MMS_IN - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100139, 'DWF Output Record: ST_ITC_SMS_OUT - EDR Count - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ITC_SMS_OUT - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100140, 'DWF Output Record: ST_ITC_SMS_OUT - EDR Value - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ITC_SMS_OUT - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100141, 'DWF Output Record: ST_ITC_VOICE_OUT - EDR Count - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ITC_VOICE_OUT - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100142, 'DWF Output Record: ST_ITC_VOICE_OUT - EDR Duration - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ITC_VOICE_OUT - EDR Duration - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100143, 'DWF Output Record: ST_ITC_VOICE_OUT - EDR Value - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ITC_VOICE_OUT - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100200, 'SMSC vs SMS Ict (count) - ST_ITC_SMS_OUT - EDR Count - Reconciliation Threshold', 'Percentage', 'SMSC vs SMS Ict (count) - ST_ITC_SMS_OUT - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100201, 'MSS vs MSS Ict (count) - ST_ITC_SMS_IN - EDR Count - Reconciliation Threshold', 'Percentage', 'MSS vs MSS Ict (count) - ST_ITC_SMS_IN - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100202, 'MSS vs MSS Ict (count) - ST_ITC_VOICE_OUT - EDR Count - Reconciliation Threshold', 'Percentage', 'MSS vs MSS Ict (count) - ST_ITC_VOICE_OUT - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100203, 'MSS vs MSS Ict (duration) - ST_ITC_VOICE_OUT - EDR Duration - Reconciliation Threshold', 'Percentage', 'MSS vs MSS Ict (duration) - ST_ITC_VOICE_OUT - EDR Duration - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100204, 'Raw MMS vs MMS Ict (count) - ST_ITC_MMS_OUT - EDR Count - Reconciliation Threshold', 'Percentage', 'Raw MMS vs MMS Ict (count) - ST_ITC_MMS_OUT - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100205, 'Raw MMS vs MMS Ict (bytes) - ST_ITC_MMS_OUT - EDR Bytes - Reconciliation Threshold', 'Percentage', 'Raw MMS vs MMS Ict (bytes) - ST_ITC_MMS_OUT - EDR Bytes - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100206, 'SMS Ict vs DWF Interconnect (count) - ST_ITC_SMS_OUT - EDR Count - Reconciliation Threshold', 'Percentage', 'SMS Ict vs DWF Interconnect (count) - ST_ITC_SMS_OUT - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100207, 'MSS Ict vs DWF Interconnect (count) - ST_ITC_VOICE_OUT - EDR Count - Reconciliation Threshold', 'Percentage', 'MSS Ict vs DWF Interconnect (count) - ST_ITC_VOICE_OUT - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100208, 'MSS Ict vs DWF Interconnect (duration) - ST_ITC_VOICE_OUT -  EDR Duration - Reconciliation Threshold', 'Percentage', 'MSS Ict vs DWF Interconnect (duration) - ST_ITC_VOICE_OUT -  EDR Duration - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100209, 'MMS Ict vs DWF Interconnect (count) - ST_ITC_MMS_OUT - EDR Count - Reconciliation Threshold', 'Percentage', 'MMS Ict vs DWF Interconnect (count) - ST_ITC_MMS_OUT - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100210, 'MMS Ict vs DWF Interconnect (bytes) - ST_ITC_MMS_OUT - EDR Bytes - Reconciliation Threshold', 'Percentage', 'MMS Ict vs DWF Interconnect (bytes) - ST_ITC_MMS_OUT - EDR Bytes - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100230, 'DWF Output Record: ST_ITC_VOICE_IN - EDR Value - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ITC_VOICE_IN - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100231, 'DWF Output Record: ST_ITC_SMS_IN - EDR Value - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ITC_SMS_IN - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100232, 'DWF Output Record: ST_ITC_SMS_IN - EDR Count - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ITC_SMS_IN - EDR Count - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100233, 'DWF Output Record: ST_ITC_MMS_IN - EDR Value - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ITC_MMS_IN - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100234, 'DWF Output Record: ST_ITC_MMS_OUT - EDR Value - Metric Threshold', 'Percentage', 'DWF Output Record: ST_ITC_MMS_OUT - EDR Value - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100235, 'MSS: ST_ITC_NOROUTE - EDR Count (Absolute) - Metric Threshold', 'Absolute', 'MSS: ST_ITC_NOROUTE - EDR Count (Absolute) - Metric Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100240, 'MSS vs MSS Ict (count) - ST_ITC_VOICE_IN - EDR Count - Reconciliation Threshold', 'Percentage', 'MSS vs MSS Ict (count) - ST_ITC_VOICE_IN - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100241, 'MSS vs MSS Ict (duration) - ST_ITC_VOICE_IN - EDR Duration - Reconciliation Threshold', 'Percentage', 'MSS vs MSS Ict (duration) - ST_ITC_VOICE_IN - EDR Duration - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100242, 'Raw MMS vs MMS Ict (count) - ST_ITC_MMS_OUT - EDR Count - Reconciliation Threshold', 'Percentage', 'Raw MMS vs MMS Ict (count) - ST_ITC_MMS_OUT - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100243, 'Raw MMS vs MMS Ict (bytes) - ST_ITC_MMS_OUT - EDR Bytes - Reconciliation Threshold', 'Percentage', 'Raw MMS vs MMS Ict (bytes) - ST_ITC_MMS_OUT - EDR Bytes - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100244, 'MSS Ict vs DWF Interconnect (count) - ST_ITC_SMS_IN - EDR Count - Reconciliation Threshold', 'Percentage', 'MSS Ict vs DWF Interconnect (count) - ST_ITC_SMS_IN - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100245, 'MSS Ict vs DWF Interconnect (count) - ST_ITC_VOICE_IN - EDR Count - Reconciliation Threshold', 'Percentage', 'MSS Ict vs DWF Interconnect (count) - ST_ITC_VOICE_IN - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100246, 'MSS Ict vs DWF Interconnect (duration) - ST_ITC_VOICE_IN -  EDR Duration - Reconciliation Threshold', 'Percentage', 'MSS Ict vs DWF Interconnect (duration) - ST_ITC_VOICE_IN -  EDR Duration - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100247, 'MMS Ict vs DWF Interconnect (count) - ST_ITC_MMS_IN - EDR Count - Reconciliation Threshold', 'Percentage', 'MMS Ict vs DWF Interconnect (count) - ST_ITC_MMS_IN - EDR Count - Reconciliation Threshold');

insert into imm.threshold_definition_ref (THRESHOLD_DEFINITION_ID, DESCRIPTION, TYPE, NOTE)
values (100248, 'MMS Ict vs DWF Interconnect (bytes) - ST_ITC_MMS_IN - EDR Bytes - Reconciliation Threshold', 'Percentage', 'MMS Ict vs DWF Interconnect (bytes) - ST_ITC_MMS_IN - EDR Bytes - Reconciliation Threshold');




insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100100, 'MSS: ST_ITC_VOICE_IN - EDR Duration - Metric Threshold', 100100, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100101, 'MSS: ST_ITC_VOICE_IN - EDR Count - Metric Threshold', 100101, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100102, 'MSS: ST_ITC_VOICE_OUT - EDR Count - Metric Threshold', 100102, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100103, 'MSS: ST_ITC_VOICE_OUT - EDR Duration - Metric Threshold', 100103, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100107, 'SMSC: ST_ITC_SMS_OUT - EDR Count - Metric Threshold', 100107, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100108, 'MSS Interconnect: ST_ITC_VOICE_IN - EDR Count - Metric Threshold', 100108, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100109, 'MSS Interconnect: ST_ITC_VOICE_IN - EDR Duration - Metric Threshold', 100109, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100110, 'Raw MMS: ST_ITC_MMS_OUT - EDR Bytes - Metric Threshold', 100110, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100111, 'Raw MMS: ST_ITC_MMS_OUT - EDR Count - Metric Threshold', 100111, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100112, 'Raw MMS: ST_ITC_MMS_IN - EDR Bytes - Metric Threshold', 100112, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100113, 'Raw MMS: ST_ITC_MMS_IN - EDR Count - Metric Threshold', 100113, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100114, 'SMS Interconnect: ST_ALL - EDR Count - Metric Threshold', 100114, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100115, 'SMS Interconnect: ST_ITC_SMS_OUT - EDR Count - Metric Threshold', 100115, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100116, 'MSS Interconnect: ST_ALL - EDR Count - Metric Threshold', 100116, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100117, 'MSS Interconnect: ST_ALL - EDR Duration - Metric Threshold', 100117, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100118, 'MSS Interconnect: ST_ITC_VOICE_OUT - EDR Count - Metric Threshold', 100118, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100119, 'MSS Interconnect: ST_ITC_VOICE_OUT - EDR Duration - Metric Threshold', 100119, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100120, 'MMS Interconnect: ST_ALL - EDR Count - Metric Threshold', 100120, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100121, 'MMS Interconnect: ST_ALL - EDR Bytes - Metric Threshold', 100121, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100122, 'MSS: ST_ITC_SMS_IN - EDR Count - Metric Threshold', 100122, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100123, 'MSS Interconnect: ST_ITC_VOICE_IN - EDR Count - Metric Threshold', 100123, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100124, 'MMS Interconnect: ST_ITC_MMS_OUT - EDR Bytes - Metric Threshold', 100124, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100125, 'MMS Interconnect: ST_ITC_MMS_OUT - EDR Count - Metric Threshold', 100125, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100126, 'MMS Interconnect: ST_ITC_MMS_IN - EDR Bytes - Metric Threshold', 100126, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100127, 'MMS Interconnect: ST_ITC_MMS_IN - EDR Count - Metric Threshold', 100127, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100128, 'DWF Output Record: ST_ALL - EDR Count - Metric Threshold', 100128, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100129, 'DWF Output Record: ST_ALL - EDR Duration - Metric Threshold', 100129, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100130, 'DWF Output Record: ST_ALL - EDR Value - Metric Threshold', 100130, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100131, 'DWF Output Record: ST_ALL - EDR Bytes - Metric Threshold', 100131, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100132, 'MSS Interconnect: ST_ITC_VOICE_IN - EDR Duration - Metric Threshold', 100132, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100133, 'DWF Output Record: ST_ITC_VOICE_IN - EDR Count - Metric Threshold', 100133, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100134, 'DWF Output Record: ST_ITC_VOICE_IN - EDR Duration - Metric Threshold', 100134, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100135, 'DWF Output Record: ST_ITC_MMS_OUT - EDR Bytes - Metric Threshold', 100135, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100136, 'DWF Output Record: ST_ITC_MMS_OUT - EDR Count - Metric Threshold', 100136, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100137, 'DWF Output Record: ST_ITC_MMS_IN - EDR Bytes - Metric Threshold', 100137, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100138, 'DWF Output Record: ST_ITC_MMS_IN - EDR Count - Metric Threshold', 100138, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100139, 'DWF Output Record: ST_ITC_SMS_OUT - EDR Count - Metric Threshold', 100139, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100140, 'DWF Output Record: ST_ITC_SMS_OUT - EDR Value - Metric Threshold', 100140, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100141, 'DWF Output Record: ST_ITC_VOICE_OUT - EDR Count - Metric Threshold', 100141, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100142, 'DWF Output Record: ST_ITC_VOICE_OUT - EDR Duration - Metric Threshold', 100142, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100143, 'DWF Output Record: ST_ITC_VOICE_OUT - EDR Value - Metric Threshold', 100143, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100200, 'SMSC vs SMS Ict (count) - ST_ITC_SMS_OUT - EDR Count - Reconciliation Threshold', 100200, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100201, 'MSS vs MSS Ict (count) - ST_ITC_SMS_IN - EDR Count - Reconciliation Threshold', 100201, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100202, 'MSS vs MSS Ict (count) - ST_ITC_VOICE_OUT - EDR Count - Reconciliation Threshold', 100202, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100203, 'MSS vs MSS Ict (duration) - ST_ITC_VOICE_OUT - EDR Duration - Reconciliation Threshold', 100203, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100204, 'Raw MMS vs MMS Ict (count) - ST_ITC_MMS_OUT - EDR Count - Reconciliation Threshold', 100204, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100205, 'Raw MMS vs MMS Ict (bytes) - ST_ITC_MMS_OUT - EDR Bytes - Reconciliation Threshold', 100205, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100206, 'SMS Ict vs DWF Interconnect (count) - ST_ITC_SMS_OUT - EDR Count - Reconciliation Threshold', 100206, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100207, 'MSS Ict vs DWF Interconnect (count) - ST_ITC_VOICE_OUT - EDR Count - Reconciliation Threshold', 100207, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100208, 'MSS Ict vs DWF Interconnect (duration) - ST_ITC_VOICE_OUT -  EDR Duration - Reconciliation Threshold', 100208, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100209, 'MMS Ict vs DWF Interconnect (count) - ST_ITC_MMS_OUT - EDR Count - Reconciliation Threshold', 100209, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100210, 'MMS Ict vs DWF Interconnect (bytes) - ST_ITC_MMS_OUT - EDR Bytes - Reconciliation Threshold', 100210, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100230, 'DWF Output Record: ST_ITC_VOICE_IN - EDR Value - Metric Threshold', 100230, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100231, 'DWF Output Record: ST_ITC_SMS_IN - EDR Value - Metric Threshold', 100231, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100232, 'DWF Output Record: ST_ITC_SMS_IN - EDR Count - Metric Threshold', 100232, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100233, 'DWF Output Record: ST_ITC_MMS_IN - EDR Value - Metric Threshold', 100233, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100234, 'DWF Output Record: ST_ITC_MMS_OUT - EDR Value - Metric Threshold', 100234, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100235, 'MSS: ST_ITC_NOROUTE - EDR Count (Absolute) - Metric Threshold', 100235, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100240, 'MSS vs MSS Ict (count) - ST_ITC_VOICE_IN - EDR Count - Reconciliation Threshold', 100240, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100241, 'MSS vs MSS Ict (duration) - ST_ITC_VOICE_IN - EDR Duration - Reconciliation Threshold', 100241, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100242, 'Raw MMS vs MMS Ict (count) - ST_ITC_MMS_OUT - EDR Count - Reconciliation Threshold', 100242, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100243, 'Raw MMS vs MMS Ict (bytes) - ST_ITC_MMS_OUT - EDR Bytes - Reconciliation Threshold', 100243, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100244, 'MSS Ict vs DWF Interconnect (count) - ST_ITC_SMS_IN - EDR Count - Reconciliation Threshold', 100244, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100245, 'MSS Ict vs DWF Interconnect (count) - ST_ITC_VOICE_IN - EDR Count - Reconciliation Threshold', 100245, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100246, 'MSS Ict vs DWF Interconnect (duration) - ST_ITC_VOICE_IN -  EDR Duration - Reconciliation Threshold', 100246, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100247, 'MMS Ict vs DWF Interconnect (count) - ST_ITC_MMS_IN - EDR Count - Reconciliation Threshold', 100247, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));

insert into imm.threshold_version_ref (THRESHOLD_VERSION_ID, DESCRIPTION, THRESHOLD_DEFINITION_ID, PARENT_VERSION_ID, STATUS, CREATION_DATE)
values (100248, 'MMS Ict vs DWF Interconnect (bytes) - ST_ITC_MMS_IN - EDR Bytes - Reconciliation Threshold', 100248, null, 'I', to_date('01-11-2013', 'dd-mm-yyyy'));


insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101100, 100100, 3002, 3002, 0.02, '>', 'Y', 35200, 3001, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102100, 100100, 3002, 3002, -0.02, '<', 'Y', 35200, 3001, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101101, 100101, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102101, 100101, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101102, 100102, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102102, 100102, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101103, 100103, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102103, 100103, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101107, 100107, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102107, 100107, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101108, 100108, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102108, 100108, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101109, 100109, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102109, 100109, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101110, 100110, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102110, 100110, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101111, 100111, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102111, 100111, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101112, 100112, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102112, 100112, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101113, 100113, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102113, 100113, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101114, 100114, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102114, 100114, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101115, 100115, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102115, 100115, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101116, 100116, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102116, 100116, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101117, 100117, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102117, 100117, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101118, 100118, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102118, 100118, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101119, 100119, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102119, 100119, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101120, 100120, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102120, 100120, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101121, 100121, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102121, 100121, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101122, 100122, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102122, 100122, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101123, 100123, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102123, 100123, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101124, 100124, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102124, 100124, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101125, 100125, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102125, 100125, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101126, 100126, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102126, 100126, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101127, 100127, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102127, 100127, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101128, 100128, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102128, 100128, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101129, 100129, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102129, 100129, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101130, 100130, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102130, 100130, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101131, 100131, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102131, 100131, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101132, 100132, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102132, 100132, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101133, 100133, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102133, 100133, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101134, 100134, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102134, 100134, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101135, 100135, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102135, 100135, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101136, 100136, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102136, 100136, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101137, 100137, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102137, 100137, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101138, 100138, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102138, 100138, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101139, 100139, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102139, 100139, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101140, 100140, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102140, 100140, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101141, 100141, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102141, 100141, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101142, 100142, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102142, 100142, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101143, 100143, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102143, 100143, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101200, 100200, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102200, 100200, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101201, 100201, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102201, 100201, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101202, 100202, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102202, 100202, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101203, 100203, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102203, 100203, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101204, 100204, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102204, 100204, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101205, 100205, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102205, 100205, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101206, 100206, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102206, 100206, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101207, 100207, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102207, 100207, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101208, 100208, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102208, 100208, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101209, 100209, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102209, 100209, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101210, 100210, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102210, 100210, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101230, 100230, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102230, 100230, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101231, 100231, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102231, 100231, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101232, 100232, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102232, 100232, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101233, 100233, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102233, 100233, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101234, 100234, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102234, 100234, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101235, 100235, 3002, 3002, 0, '!=', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101240, 100240, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102240, 100240, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101241, 100241, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102241, 100241, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101242, 100242, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102242, 100242, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101243, 100243, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102243, 100243, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101244, 100244, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102244, 100244, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101245, 100245, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102245, 100245, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101246, 100246, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102246, 100246, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101247, 100247, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102247, 100247, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (101248, 100248, 3002, 3002, 0.02, '>', 'Y', 35200, 3000, null);

insert into imm.threshold_severity_ref (THRESHOLD_SEVERITY_ID, THRESHOLD_VERSION_ID, SEVERITY_ID, PRIORITY_ID, VALUE, OPERATOR, RAISE_ISSUE, ISSUE_TYPE_ID, START_GROUP_ID, START_USER_ID)
values (102248, 100248, 3002, 3002, -0.02, '<', 'Y', 35200, 3000, null);



insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101100, 1, 100100, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102100, 2, 100100, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103100, 3, 100100, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104100, 4, 100100, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105100, 5, 100100, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106100, 6, 100100, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107100, 7, 100100, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101101, 1, 100101, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102101, 2, 100101, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103101, 3, 100101, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104101, 4, 100101, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105101, 5, 100101, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106101, 6, 100101, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107101, 7, 100101, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101102, 1, 100102, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102102, 2, 100102, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103102, 3, 100102, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104102, 4, 100102, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105102, 5, 100102, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106102, 6, 100102, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107102, 7, 100102, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101103, 1, 100103, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102103, 2, 100103, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103103, 3, 100103, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104103, 4, 100103, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105103, 5, 100103, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106103, 6, 100103, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107103, 7, 100103, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101107, 1, 100107, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102107, 2, 100107, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103107, 3, 100107, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104107, 4, 100107, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105107, 5, 100107, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106107, 6, 100107, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107107, 7, 100107, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101108, 1, 100108, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102108, 2, 100108, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103108, 3, 100108, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104108, 4, 100108, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105108, 5, 100108, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106108, 6, 100108, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107108, 7, 100108, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101109, 1, 100109, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102109, 2, 100109, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103109, 3, 100109, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104109, 4, 100109, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105109, 5, 100109, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106109, 6, 100109, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107109, 7, 100109, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101110, 1, 100110, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102110, 2, 100110, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103110, 3, 100110, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104110, 4, 100110, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105110, 5, 100110, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106110, 6, 100110, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107110, 7, 100110, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101111, 1, 100111, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102111, 2, 100111, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103111, 3, 100111, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104111, 4, 100111, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105111, 5, 100111, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106111, 6, 100111, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107111, 7, 100111, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101112, 1, 100112, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102112, 2, 100112, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103112, 3, 100112, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104112, 4, 100112, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105112, 5, 100112, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106112, 6, 100112, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107112, 7, 100112, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101113, 1, 100113, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102113, 2, 100113, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103113, 3, 100113, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104113, 4, 100113, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105113, 5, 100113, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106113, 6, 100113, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107113, 7, 100113, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101114, 1, 100114, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102114, 2, 100114, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103114, 3, 100114, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104114, 4, 100114, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105114, 5, 100114, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106114, 6, 100114, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107114, 7, 100114, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101115, 1, 100115, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102115, 2, 100115, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103115, 3, 100115, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104115, 4, 100115, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105115, 5, 100115, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106115, 6, 100115, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107115, 7, 100115, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101116, 1, 100116, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102116, 2, 100116, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103116, 3, 100116, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104116, 4, 100116, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105116, 5, 100116, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106116, 6, 100116, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107116, 7, 100116, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101117, 1, 100117, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102117, 2, 100117, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103117, 3, 100117, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104117, 4, 100117, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105117, 5, 100117, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106117, 6, 100117, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107117, 7, 100117, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101118, 1, 100118, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102118, 2, 100118, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103118, 3, 100118, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104118, 4, 100118, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105118, 5, 100118, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106118, 6, 100118, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107118, 7, 100118, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101119, 1, 100119, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102119, 2, 100119, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103119, 3, 100119, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104119, 4, 100119, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105119, 5, 100119, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106119, 6, 100119, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107119, 7, 100119, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101120, 1, 100120, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102120, 2, 100120, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103120, 3, 100120, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104120, 4, 100120, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105120, 5, 100120, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106120, 6, 100120, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107120, 7, 100120, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101121, 1, 100121, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102121, 2, 100121, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103121, 3, 100121, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104121, 4, 100121, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105121, 5, 100121, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106121, 6, 100121, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107121, 7, 100121, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101122, 1, 100122, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102122, 2, 100122, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103122, 3, 100122, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104122, 4, 100122, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105122, 5, 100122, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106122, 6, 100122, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107122, 7, 100122, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101123, 1, 100123, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102123, 2, 100123, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103123, 3, 100123, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104123, 4, 100123, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105123, 5, 100123, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106123, 6, 100123, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107123, 7, 100123, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101124, 1, 100124, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102124, 2, 100124, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103124, 3, 100124, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104124, 4, 100124, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105124, 5, 100124, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106124, 6, 100124, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107124, 7, 100124, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101125, 1, 100125, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102125, 2, 100125, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103125, 3, 100125, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104125, 4, 100125, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105125, 5, 100125, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106125, 6, 100125, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107125, 7, 100125, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101126, 1, 100126, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102126, 2, 100126, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103126, 3, 100126, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104126, 4, 100126, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105126, 5, 100126, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106126, 6, 100126, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107126, 7, 100126, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101127, 1, 100127, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102127, 2, 100127, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103127, 3, 100127, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104127, 4, 100127, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105127, 5, 100127, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106127, 6, 100127, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107127, 7, 100127, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101128, 1, 100128, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102128, 2, 100128, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103128, 3, 100128, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104128, 4, 100128, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105128, 5, 100128, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106128, 6, 100128, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107128, 7, 100128, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101129, 1, 100129, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102129, 2, 100129, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103129, 3, 100129, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104129, 4, 100129, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105129, 5, 100129, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106129, 6, 100129, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107129, 7, 100129, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101130, 1, 100130, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102130, 2, 100130, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103130, 3, 100130, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104130, 4, 100130, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105130, 5, 100130, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106130, 6, 100130, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107130, 7, 100130, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101131, 1, 100131, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102131, 2, 100131, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103131, 3, 100131, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104131, 4, 100131, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105131, 5, 100131, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106131, 6, 100131, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107131, 7, 100131, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101132, 1, 100132, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102132, 2, 100132, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103132, 3, 100132, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104132, 4, 100132, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105132, 5, 100132, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106132, 6, 100132, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107132, 7, 100132, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101133, 1, 100133, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102133, 2, 100133, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103133, 3, 100133, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104133, 4, 100133, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105133, 5, 100133, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106133, 6, 100133, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107133, 7, 100133, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101134, 1, 100134, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102134, 2, 100134, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103134, 3, 100134, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104134, 4, 100134, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105134, 5, 100134, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106134, 6, 100134, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107134, 7, 100134, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101135, 1, 100135, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102135, 2, 100135, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103135, 3, 100135, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104135, 4, 100135, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105135, 5, 100135, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106135, 6, 100135, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107135, 7, 100135, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101136, 1, 100136, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102136, 2, 100136, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103136, 3, 100136, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104136, 4, 100136, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105136, 5, 100136, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106136, 6, 100136, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107136, 7, 100136, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101137, 1, 100137, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102137, 2, 100137, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103137, 3, 100137, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104137, 4, 100137, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105137, 5, 100137, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106137, 6, 100137, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107137, 7, 100137, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101138, 1, 100138, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102138, 2, 100138, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103138, 3, 100138, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104138, 4, 100138, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105138, 5, 100138, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106138, 6, 100138, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107138, 7, 100138, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101139, 1, 100139, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102139, 2, 100139, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103139, 3, 100139, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104139, 4, 100139, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105139, 5, 100139, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106139, 6, 100139, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107139, 7, 100139, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101140, 1, 100140, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102140, 2, 100140, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103140, 3, 100140, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104140, 4, 100140, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105140, 5, 100140, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106140, 6, 100140, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107140, 7, 100140, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101141, 1, 100141, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102141, 2, 100141, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103141, 3, 100141, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104141, 4, 100141, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105141, 5, 100141, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106141, 6, 100141, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107141, 7, 100141, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101142, 1, 100142, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102142, 2, 100142, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103142, 3, 100142, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104142, 4, 100142, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105142, 5, 100142, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106142, 6, 100142, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107142, 7, 100142, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101143, 1, 100143, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102143, 2, 100143, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103143, 3, 100143, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104143, 4, 100143, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105143, 5, 100143, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106143, 6, 100143, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107143, 7, 100143, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101200, 1, 100200, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102200, 2, 100200, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103200, 3, 100200, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104200, 4, 100200, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105200, 5, 100200, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106200, 6, 100200, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107200, 7, 100200, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101201, 1, 100201, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102201, 2, 100201, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103201, 3, 100201, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104201, 4, 100201, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105201, 5, 100201, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106201, 6, 100201, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107201, 7, 100201, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101202, 1, 100202, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102202, 2, 100202, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103202, 3, 100202, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104202, 4, 100202, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105202, 5, 100202, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106202, 6, 100202, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107202, 7, 100202, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101203, 1, 100203, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102203, 2, 100203, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103203, 3, 100203, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104203, 4, 100203, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105203, 5, 100203, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106203, 6, 100203, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107203, 7, 100203, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101204, 1, 100204, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102204, 2, 100204, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103204, 3, 100204, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104204, 4, 100204, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105204, 5, 100204, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106204, 6, 100204, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107204, 7, 100204, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101205, 1, 100205, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102205, 2, 100205, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103205, 3, 100205, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104205, 4, 100205, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105205, 5, 100205, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106205, 6, 100205, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107205, 7, 100205, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101206, 1, 100206, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102206, 2, 100206, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103206, 3, 100206, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104206, 4, 100206, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105206, 5, 100206, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106206, 6, 100206, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107206, 7, 100206, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101207, 1, 100207, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102207, 2, 100207, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103207, 3, 100207, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104207, 4, 100207, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105207, 5, 100207, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106207, 6, 100207, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107207, 7, 100207, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101208, 1, 100208, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102208, 2, 100208, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103208, 3, 100208, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104208, 4, 100208, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105208, 5, 100208, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106208, 6, 100208, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107208, 7, 100208, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101209, 1, 100209, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102209, 2, 100209, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103209, 3, 100209, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104209, 4, 100209, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105209, 5, 100209, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106209, 6, 100209, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107209, 7, 100209, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101210, 1, 100210, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102210, 2, 100210, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103210, 3, 100210, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104210, 4, 100210, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105210, 5, 100210, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106210, 6, 100210, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107210, 7, 100210, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101230, 1, 100230, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102230, 2, 100230, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103230, 3, 100230, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104230, 4, 100230, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105230, 5, 100230, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106230, 6, 100230, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107230, 7, 100230, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101231, 1, 100231, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102231, 2, 100231, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103231, 3, 100231, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104231, 4, 100231, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105231, 5, 100231, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106231, 6, 100231, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107231, 7, 100231, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101232, 1, 100232, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102232, 2, 100232, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103232, 3, 100232, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104232, 4, 100232, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105232, 5, 100232, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106232, 6, 100232, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107232, 7, 100232, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101233, 1, 100233, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102233, 2, 100233, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103233, 3, 100233, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104233, 4, 100233, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105233, 5, 100233, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106233, 6, 100233, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107233, 7, 100233, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101234, 1, 100234, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102234, 2, 100234, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103234, 3, 100234, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104234, 4, 100234, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105234, 5, 100234, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106234, 6, 100234, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107234, 7, 100234, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101235, 1, 100235, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102235, 2, 100235, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103235, 3, 100235, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104235, 4, 100235, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105235, 5, 100235, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106235, 6, 100235, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107235, 7, 100235, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101240, 1, 100240, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102240, 2, 100240, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103240, 3, 100240, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104240, 4, 100240, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105240, 5, 100240, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106240, 6, 100240, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107240, 7, 100240, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101241, 1, 100241, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102241, 2, 100241, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103241, 3, 100241, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104241, 4, 100241, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105241, 5, 100241, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106241, 6, 100241, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107241, 7, 100241, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101242, 1, 100242, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102242, 2, 100242, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103242, 3, 100242, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104242, 4, 100242, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105242, 5, 100242, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106242, 6, 100242, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107242, 7, 100242, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101243, 1, 100243, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102243, 2, 100243, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103243, 3, 100243, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104243, 4, 100243, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105243, 5, 100243, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106243, 6, 100243, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107243, 7, 100243, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101244, 1, 100244, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102244, 2, 100244, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103244, 3, 100244, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104244, 4, 100244, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105244, 5, 100244, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106244, 6, 100244, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107244, 7, 100244, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101245, 1, 100245, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102245, 2, 100245, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103245, 3, 100245, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104245, 4, 100245, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105245, 5, 100245, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106245, 6, 100245, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107245, 7, 100245, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101246, 1, 100246, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102246, 2, 100246, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103246, 3, 100246, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104246, 4, 100246, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105246, 5, 100246, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106246, 6, 100246, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107246, 7, 100246, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101247, 1, 100247, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102247, 2, 100247, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103247, 3, 100247, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104247, 4, 100247, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105247, 5, 100247, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106247, 6, 100247, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107247, 7, 100247, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (101248, 1, 100248, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (102248, 2, 100248, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (103248, 3, 100248, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (104248, 4, 100248, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (105248, 5, 100248, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (106248, 6, 100248, 0, 86399);

insert into imm.day_threshold_ref (DAY_THRESHOLD_ID, DAY_ID, THRESHOLD_VERSION_ID, FROM_TIME, TO_TIME)
values (107248, 7, 100248, 0, 86399);





commit;

exit;
