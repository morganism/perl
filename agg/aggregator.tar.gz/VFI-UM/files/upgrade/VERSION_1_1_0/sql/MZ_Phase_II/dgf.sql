

insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100160, 100001, 100000, 'SMS Interconnect', 'DS73', '', null);

insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100161, 100001, 100000, 'MSS Interconnect', 'DS74', '', null);

insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100162, 100001, 100000, 'MMS Interconnect', 'DS75', '', null);

insert into dgf.node_ref (NODE_ID, GRAPH_ID, NODE_TYPE_ID, NAME, DESCRIPTION, NOTE, SYSTEM_ID)
values (100163, 100001, 100000, 'DWF Output Record', 'DS76', '', null);


insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100130, 100106, 100160, 1, 'SMSC to SMS Interconnect', 'SMSC to SMS Interconnect', '');

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100131, 100160, 100163, 1, 'SMS Interconnect to DWF Output', 'SMS Interconnect to DWF Output', '');

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100132, 100102, 100161, 1, 'MSS to MSS Interconnect', 'MSS to MSS Interconnect', '');

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100133, 100161, 100163, 1, 'MSS Interconnect to DWF Output', 'MSS Interconnect to DWF Output', '');

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100134, 100146, 100162, 1, 'MMS to MMS Interconnect', 'MMS to MMS Interconnect', '');

insert into dgf.edge_ref (EDGE_ID, I_NODE_ID, J_NODE_ID, EDGE_TYPE_ID, NAME, DESCRIPTION, NOTE)
values (100135, 100162, 100163, 1, 'MMS Interconnect to DWF Output', 'MMS Interconnect to DWF Output', '');


insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100100, 100160);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100103, 100161);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100101, 100161);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100102, 100161);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100104, 100162);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100105, 100162);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100100, 100163);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100103, 100163);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100101, 100163);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100102, 100163);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100104, 100163);

insert into dgf.node_group_jn (NODE_GROUP_ID, NODE_ID)
values (100105, 100163);

commit;
exit
