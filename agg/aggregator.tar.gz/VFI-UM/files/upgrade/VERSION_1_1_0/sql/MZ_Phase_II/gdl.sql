




insert into gdl.format_mapping (MAPPING_ID, NAME, DESCRIPTION, PROCESS_TYPE)
values (100090, 'SMS Interconnect Importer (DS73)', 'SMS Interconnect Importer (DS73)', 'IMPORT');

insert into gdl.format_mapping (MAPPING_ID, NAME, DESCRIPTION, PROCESS_TYPE)
values (100091, 'MSS Interconnect Importer (DS74)', 'MSS Interconnect Importer (DS74)', 'IMPORT');

insert into gdl.format_mapping (MAPPING_ID, NAME, DESCRIPTION, PROCESS_TYPE)
values (100092, 'MMS Interconnect Importer (DS75)', 'MMS Interconnect Importer (DS75)', 'IMPORT');

insert into gdl.format_mapping (MAPPING_ID, NAME, DESCRIPTION, PROCESS_TYPE)
values (100093, 'DWF Output Records Importer (DS76)', 'DWF Output Records  Importer (DS76)', 'IMPORT');


insert into gdl.loadable_tables_ref (LOADABLE_TABLE_ID, DB_POOL, TARGET_SCHEMA, TARGET_TABLE, SUPPORTS_ROLLBACK, EM_ID)
values (100090, 'CUSTOMERCP', 'CUSTOMER', 'stg_agg_data_ds73', 'N', null);

insert into gdl.loadable_tables_ref (LOADABLE_TABLE_ID, DB_POOL, TARGET_SCHEMA, TARGET_TABLE, SUPPORTS_ROLLBACK, EM_ID)
values (100091, 'CUSTOMERCP', 'CUSTOMER', 'stg_agg_data_ds74', 'N', null);

insert into gdl.loadable_tables_ref (LOADABLE_TABLE_ID, DB_POOL, TARGET_SCHEMA, TARGET_TABLE, SUPPORTS_ROLLBACK, EM_ID)
values (100092, 'CUSTOMERCP', 'CUSTOMER', 'stg_agg_data_ds75', 'N', null);

insert into gdl.loadable_tables_ref (LOADABLE_TABLE_ID, DB_POOL, TARGET_SCHEMA, TARGET_TABLE, SUPPORTS_ROLLBACK, EM_ID)
values (100093, 'CUSTOMERCP', 'CUSTOMER', 'stg_agg_data_ds76', 'N', null);


insert into gdl.format_mapping_version (MAPPING_VERSION_ID, MAPPING_ID, PARENT_VERSION_ID, VALID_FROM, VALID_TO, STATUS, LOADABLE_TABLE_ID, LOAD_ACTION, TRAILING_NULLS, DESCRIPTION, MAX_REJECTS, UNIQUE_FILENAMES, IS_DIRECT, UNRECOVERABLE, FILE_TYPE, INPUT_DIRECTORY, ACCEPTED_DIRECTORY, REJECTED_DIRECTORY, BAD_DIRECTORY, LOG_DIRECTORY, FILE_MASK, DELIMITERS, ENCLOSING_CHARS, SKIP_COUNT)
values (100090, 100090, null, to_date('01-11-2013', 'dd-mm-yyyy'), to_date('31-12-2020', 'dd-mm-yyyy'), 'A', 100090, 'TRUNCATE', 'Y', 'SMS Interconnect', 1, 'N', 'Y', 'N', 'D', 'gdl/input/DS73/out', 'gdl/accepted/DS73', 'gdl/rejected/DS73', 'gdl/bad/DS73', 'gdl/log/DS73', '[0-9]{20}\.DS73\.out', ',', '', 1);

insert into gdl.format_mapping_version (MAPPING_VERSION_ID, MAPPING_ID, PARENT_VERSION_ID, VALID_FROM, VALID_TO, STATUS, LOADABLE_TABLE_ID, LOAD_ACTION, TRAILING_NULLS, DESCRIPTION, MAX_REJECTS, UNIQUE_FILENAMES, IS_DIRECT, UNRECOVERABLE, FILE_TYPE, INPUT_DIRECTORY, ACCEPTED_DIRECTORY, REJECTED_DIRECTORY, BAD_DIRECTORY, LOG_DIRECTORY, FILE_MASK, DELIMITERS, ENCLOSING_CHARS, SKIP_COUNT)
values (100091, 100091, null, to_date('01-11-2013', 'dd-mm-yyyy'), to_date('31-12-2020', 'dd-mm-yyyy'), 'A', 100091, 'TRUNCATE', 'Y', 'MSS Interconnect', 1, 'N', 'Y', 'N', 'D', 'gdl/input/DS74/out', 'gdl/accepted/DS74', 'gdl/rejected/DS74', 'gdl/bad/DS74', 'gdl/log/DS74', '[0-9]{20}\.DS74\.out', ',', '', 1);

insert into gdl.format_mapping_version (MAPPING_VERSION_ID, MAPPING_ID, PARENT_VERSION_ID, VALID_FROM, VALID_TO, STATUS, LOADABLE_TABLE_ID, LOAD_ACTION, TRAILING_NULLS, DESCRIPTION, MAX_REJECTS, UNIQUE_FILENAMES, IS_DIRECT, UNRECOVERABLE, FILE_TYPE, INPUT_DIRECTORY, ACCEPTED_DIRECTORY, REJECTED_DIRECTORY, BAD_DIRECTORY, LOG_DIRECTORY, FILE_MASK, DELIMITERS, ENCLOSING_CHARS, SKIP_COUNT)
values (100092, 100092, null, to_date('01-11-2013', 'dd-mm-yyyy'), to_date('31-12-2020', 'dd-mm-yyyy'), 'A', 100092, 'TRUNCATE', 'Y', 'MMS Interconnect', 1, 'N', 'Y', 'N', 'D', 'gdl/input/DS75/out', 'gdl/accepted/DS75', 'gdl/rejected/DS75', 'gdl/bad/DS75', 'gdl/log/DS75', '[0-9]{20}\.DS75\.out', ',', '', 1);

insert into gdl.format_mapping_version (MAPPING_VERSION_ID, MAPPING_ID, PARENT_VERSION_ID, VALID_FROM, VALID_TO, STATUS, LOADABLE_TABLE_ID, LOAD_ACTION, TRAILING_NULLS, DESCRIPTION, MAX_REJECTS, UNIQUE_FILENAMES, IS_DIRECT, UNRECOVERABLE, FILE_TYPE, INPUT_DIRECTORY, ACCEPTED_DIRECTORY, REJECTED_DIRECTORY, BAD_DIRECTORY, LOG_DIRECTORY, FILE_MASK, DELIMITERS, ENCLOSING_CHARS, SKIP_COUNT)
values (100093, 100093, null, to_date('01-11-2013', 'dd-mm-yyyy'), to_date('31-12-2020', 'dd-mm-yyyy'), 'A', 100093, 'TRUNCATE', 'Y', 'DWF Output Records', 1, 'N', 'Y', 'N', 'D', 'gdl/input/DS76/out', 'gdl/accepted/DS76', 'gdl/rejected/DS76', 'gdl/bad/DS76', 'gdl/log/DS76', '[0-9]{20}\.DS76\.out', ',', '', 1);


insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109000, 100090, 'currentDir', 1, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109001, 100090, 'edrFileName', 2, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109002, 100090, 'neId', 3, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109003, 100090, 'umIdentifier', 4, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109004, 100090, 'usageType', 5, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109005, 100090, 'timeSlot', 7, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109006, 100090, 'serviceType', 8, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109007, 100090, 'eventCount', 11, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109008, 100090, 'sumDuration', 12, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109009, 100090, 'sumBytes', 13, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109010, 100090, 'sumValue', 14, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109011, 100090, 'dummy filler', 15, null, null, '', 'N');


insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109100, 100091, 'currentDir', 1, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109101, 100091, 'edrFileName', 2, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109102, 100091, 'neId', 3, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109103, 100091, 'umIdentifier', 4, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109104, 100091, 'usageType', 5, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109105, 100091, 'timeSlot', 7, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109106, 100091, 'serviceType', 8, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109107, 100091, 'eventCount', 11, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109108, 100091, 'sumDuration', 12, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109109, 100091, 'sumBytes', 13, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109110, 100091, 'sumValue', 14, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109111, 100091, 'dummy filler', 15, null, null, '', 'N');


insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109200, 100092, 'currentDir', 1, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109201, 100092, 'edrFileName', 2, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109202, 100092, 'neId', 3, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109203, 100092, 'umIdentifier', 4, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109204, 100092, 'usageType', 5, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109205, 100092, 'timeSlot', 7, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109206, 100092, 'serviceType', 8, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109207, 100092, 'eventCount', 11, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109208, 100092, 'sumDuration', 12, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109209, 100092, 'sumBytes', 13, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109210, 100092, 'sumValue', 14, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109211, 100092, 'dummy filler', 15, null, null, '', 'N');


insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109300, 100093, 'currentDir', 1, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109301, 100093, 'edrFileName', 2, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109302, 100093, 'neId', 3, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109303, 100093, 'umIdentifier', 4, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109304, 100093, 'usageType', 5, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109305, 100093, 'timeSlot', 7, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109306, 100093, 'serviceType', 8, null, null, '', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109307, 100093, 'eventCount', 11, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109308, 100093, 'sumDuration', 12, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109309, 100093, 'sumBytes', 13, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109310, 100093, 'sumValue', 14, null, null, 'INTEGER EXTERNAL', 'N');

insert into gdl.format_field_ref (FORMAT_FIELD_ID, MAPPING_VERSION_ID, FIELD_NAME, FIELD_SEQUENCE, FIELD_START_POSITION, FIELD_END_POSITION, FORMAT_FIELD_TYPE, FILLER)
values (109311, 100093, 'dummy filler', 15, null, null, '', 'N');



insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100090, 'PROCESSDATE', null, 'get_process_date_from_filename(''[FILENAME]'')');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100090, 'CURRENTDIR', 109000, 'concat(concat(:currentDir,''/''),:edrFileName)');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100090, 'EDRFILENAME', 109001, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100090, 'NEID', 109002, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100090, 'UMIDENTIFIER', 109003, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100090, 'USAGETYPE', 109004, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100090, 'TIMESLOT', 109005, 'to_date(:timeslot,''YYYYMMDDHH24'')');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100090, 'SERVICETYPE', 109006, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100090, 'EVENTCOUNT', 109007, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100090, 'SUMDURATION', 109008, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100090, 'SUMBYTES', 109009, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100090, 'SUMVALUE', 109010, '');



insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100091, 'PROCESSDATE', null, 'get_process_date_from_filename(''[FILENAME]'')');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100091, 'CURRENTDIR', 109100, 'concat(concat(:currentDir,''/''),:edrFileName)');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100091, 'EDRFILENAME', 109101, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100091, 'NEID', 109102, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100091, 'UMIDENTIFIER', 109103, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100091, 'USAGETYPE', 109104, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100091, 'TIMESLOT', 109105, 'to_date(:timeslot,''YYYYMMDDHH24'')');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100091, 'SERVICETYPE', 109106, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100091, 'EVENTCOUNT', 109107, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100091, 'SUMDURATION', 109108, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100091, 'SUMBYTES', 109109, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100091, 'SUMVALUE', 109110, '');





insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100092, 'PROCESSDATE', null, 'get_process_date_from_filename(''[FILENAME]'')');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100092, 'CURRENTDIR', 109200, 'concat(concat(:currentDir,''/''),:edrFileName)');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100092, 'EDRFILENAME', 109201, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100092, 'NEID', 109202, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100092, 'UMIDENTIFIER', 109203, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100092, 'USAGETYPE', 109204, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100092, 'TIMESLOT', 109205, 'to_date(:timeslot,''YYYYMMDDHH24'')');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100092, 'SERVICETYPE', 109206, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100092, 'EVENTCOUNT', 109207, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100092, 'SUMDURATION', 109208, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100092, 'SUMBYTES', 109209, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100092, 'SUMVALUE', 109210, '');






insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100093, 'PROCESSDATE', null, 'get_process_date_from_filename(''[FILENAME]'')');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100093, 'CURRENTDIR', 109300, 'concat(concat(:currentDir,''/''),:edrFileName)');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100093, 'EDRFILENAME', 109301, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100093, 'NEID', 109302, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100093, 'UMIDENTIFIER', 109303, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100093, 'USAGETYPE', 109304, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100093, 'TIMESLOT', 109305, 'to_date(:timeslot,''YYYYMMDDHH24'')');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100093, 'SERVICETYPE', 109306, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100093, 'EVENTCOUNT', 109307, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100093, 'SUMDURATION', 109308, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100093, 'SUMBYTES', 109309, '');

insert into gdl.field_mapping (MAPPING_VERSION_ID, TARGET_FIELD, FORMAT_FIELD_ID, OPERATION)
values (100093, 'SUMVALUE', 109310, '');



insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109001, 100090, 5014, 'POST', 10, '-iv 100002 -icn sql_ID -tn um.sql_ref -staging_table customer.stg_agg_data_ds73 -scn sql -et U', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109002, 100090, 5002, 'EXEC', 10, '-direct false -parallel false -loadRejectedFiles false', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109003, 100090, 5017, 'INIT', 10, '', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109004, 100090, 5007, 'POST', 20, '', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109005, 100090, 5001, 'POST', 30, 'il_success_dir gdl/accepted/ds73 il_reject_dir gdl/rejected/ds73', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109006, 100090, 5014, 'POST', 40, '-iv 100003 -icn sql_id -tn um.sql_ref -scn sql -et U', '');



insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109101, 100091, 5014, 'POST', 10, '-iv 100002 -icn sql_ID -tn um.sql_ref -staging_table customer.stg_agg_data_ds74 -scn sql -et U', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109102, 100091, 5002, 'EXEC', 10, '-direct false -parallel false -loadRejectedFiles false', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109103, 100091, 5017, 'INIT', 10, '', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109104, 100091, 5007, 'POST', 20, '', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109105, 100091, 5001, 'POST', 30, 'il_success_dir gdl/accepted/ds74 il_reject_dir gdl/rejected/ds74', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109106, 100091, 5014, 'POST', 40, '-iv 100003 -icn sql_id -tn um.sql_ref -scn sql -et U', '');


insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109201, 100092, 5014, 'POST', 10, '-iv 100002 -icn sql_ID -tn um.sql_ref -staging_table customer.stg_agg_data_ds75 -scn sql -et U', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109202, 100092, 5002, 'EXEC', 10, '-direct false -parallel false -loadRejectedFiles false', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109203, 100092, 5017, 'INIT', 10, '', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109204, 100092, 5007, 'POST', 20, '', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109205, 100092, 5001, 'POST', 30, 'il_success_dir gdl/accepted/ds75 il_reject_dir gdl/rejected/ds75', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109206, 100092, 5014, 'POST', 40, '-iv 100003 -icn sql_id -tn um.sql_ref -scn sql -et U', '');



insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109301, 100093, 5014, 'POST', 10, '-iv 100002 -icn sql_ID -tn um.sql_ref -staging_table customer.stg_agg_data_ds76 -scn sql -et U', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109302, 100093, 5002, 'EXEC', 10, '-direct false -parallel false -loadRejectedFiles false', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109303, 100093, 5017, 'INIT', 10, '', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109304, 100093, 5007, 'POST', 20, '', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109305, 100093, 5001, 'POST', 30, 'il_success_dir gdl/accepted/ds76 il_reject_dir gdl/rejected/ds76', '');

insert into gdl.fmt_map_action_map (MAP_ACTION_MAP_ID, MAPPING_VERSION_ID, ACTION_CODE_ID, TYPE, ACTION_ORDER, PARAMETERS, DESCRIPTION)
values (109306, 100093, 5014, 'POST', 40, '-iv 100003 -icn sql_id -tn um.sql_ref -scn sql -et U', '');




commit;

exit
