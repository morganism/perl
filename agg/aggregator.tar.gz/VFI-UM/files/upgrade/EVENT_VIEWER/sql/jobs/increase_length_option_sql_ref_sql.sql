alter table jobs.option_sql_ref modify sql varchar2(4000);
exit;
