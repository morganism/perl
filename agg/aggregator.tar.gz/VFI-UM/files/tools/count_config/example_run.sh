clear.sh TASMDV19 TASMDV17

count_rows.sh TASMDV19 'run1'
count_rows.sh TASMDV17 'run1'

report.sh TASMDV19 TASMDV17 'run1'
