select * from um.SOURCE_DESC_REF where NODE_ID > 99999;
