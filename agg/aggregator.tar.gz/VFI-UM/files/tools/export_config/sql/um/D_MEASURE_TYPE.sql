select * from um.D_MEASURE_TYPE where D_MEASURE_TYPE_ID > -999999;
