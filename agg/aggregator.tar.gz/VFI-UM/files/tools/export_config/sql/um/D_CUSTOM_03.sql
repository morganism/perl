select * from UM.D_CUSTOM_03 where D_CUSTOM_03_ID > 99999 ;
