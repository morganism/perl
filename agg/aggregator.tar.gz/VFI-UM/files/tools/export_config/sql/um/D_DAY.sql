select * from UM.D_DAY where D_DAY_ID > to_date('01-JAN-2000','DD-MON-YYYY') ;
