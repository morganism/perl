select * from UM.D_PERIOD where D_PERIOD_ID > to_date('01-JAN-2000','DD-MON-YYYY') ;
