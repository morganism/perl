select * from UM.D_CUSTOM_02 where D_CUSTOM_02_ID > 99999 ;
