select * from UM.SOURCE_REF ;
