select * from UM.SOURCE_EDR_TYPE_JN ;
