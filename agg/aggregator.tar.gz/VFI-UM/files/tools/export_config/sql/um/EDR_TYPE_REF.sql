select * from UM.EDR_TYPE_REF ;
