select * from UM.D_CUSTOMER_TYPE_REF ;
