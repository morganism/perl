select * from UM.UNIT_REF where UNIT_ID > 12;
