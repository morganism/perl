select * from UM.SQL_REF ;
