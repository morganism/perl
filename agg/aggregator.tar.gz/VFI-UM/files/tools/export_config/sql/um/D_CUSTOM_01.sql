select * from UM.D_CUSTOM_01 where D_CUSTOM_01_ID > 99999 ;
