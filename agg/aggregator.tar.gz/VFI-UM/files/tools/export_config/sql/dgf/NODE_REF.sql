select * from DGF.NODE_REF where NODE_ID > 99999 ;
