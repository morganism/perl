select * from DGF.NODE_TYPE_REF where NODE_TYPE_ID > 99999 ;
