select * from DGF.EDGE_REF where EDGE_ID > 99999 ;
