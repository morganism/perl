select * from DGF.GRAPH_REF where GRAPH_ID > 99999 ;
