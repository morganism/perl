select * from GDL.FORMAT_MAPPING where MAPPING_ID > 99999 ;
