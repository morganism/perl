sqlplus system/manager @ gen_selects.sql 
