function getDdlPattern()
{
    var returnValue = "dropDownFilterValue(COL_?)";
    return returnValue;
}

function getServletUrl()
{
    var returnValue = "/servlet/IMMFilterDropDownXMLServlet?html=true";
    return returnValue;
}
