function getDdlPattern()
{
    var returnValue = "ATTRIBUTE_?";
    return returnValue;
}

function getServletUrl()
{
    var returnValue = "/servlet/IMMGetDropDownXMLServlet?html=true";
    return returnValue;
}
