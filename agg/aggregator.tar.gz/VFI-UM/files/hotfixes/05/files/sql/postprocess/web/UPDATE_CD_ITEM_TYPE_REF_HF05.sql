update web.cd_item_type_ref b set b.initialisation_class='uk.co.cartesian.ascertain.ble.cd.BleDashboardInit' where type_id=2000;

exit;
