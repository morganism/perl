
insert into um.mv_rebuild_ref values (7, 'UM.MV_F_FILE_SHORT', 'FORCE', '40', '');
insert into um.mv_rebuild_ref values (7, 'UM.MV_F_FILE_SHORT_2', 'FORCE', '41', '');
insert into um.mv_rebuild_ref values (7, 'UM.MV_F_FILE_SHORT_3', 'FORCE', '42', '');

exit;
