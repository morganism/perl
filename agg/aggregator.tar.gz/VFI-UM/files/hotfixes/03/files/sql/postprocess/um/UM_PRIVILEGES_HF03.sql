grant select, references on um.source_ref to utils with grant option;
grant select, references on um.source_type_ref to utils with grant option;

exit;
