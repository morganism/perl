delete from web.cd_dashboard_detail where cd_dashboard_id=1200 and type_id=1008 and instance_id=1203;

exit;
