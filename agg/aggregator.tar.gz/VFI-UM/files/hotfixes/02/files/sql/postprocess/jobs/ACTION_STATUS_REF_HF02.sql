grant select, references on jobs.action_status_ref to utils;

exit;
