update um.cd_metric_ref set sample_from=14, sample_to=0;

exit;
