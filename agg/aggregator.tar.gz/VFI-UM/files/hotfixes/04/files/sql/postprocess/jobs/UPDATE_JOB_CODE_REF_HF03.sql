insert into jobs.job_code_ref (JOB_CODE_ID, WEIGHT, PARAMETERS, CLASS_NAME, BLOCKING_STATUS, DESCRIPTION, JOB_CATEGORY_ID, COMPRESSED_LOGS, PARAMETERS_URL)
values (101000, 5, '-container_id 100000', 'uk.co.cartesian.ascertain.ble.BleJob', '', 'Update OLAP Recent Tables', 1, 'N', '');

exit;
