package uk.co.cartesian.ascertain.um.persistence.bean.mrec;

import uk.co.cartesian.ascertain.um.web.action.mrec.MrecSet;

public class MrecChartBean {

	private Long period;
	// TODO dpp Java Long is limited to numbers of 19 digits (must fix this!)             
	private Long line;
	private String lineName;
	private MrecSet set;
	private Double value;
	private Boolean isAggregate;
	private Double maxCriticalThreshold;
	private Double minCriticalThreshold;
	private Double maxSevereThreshold;
	private Double minSevereThreshold;
	private Double maxMajorThreshold;
	private Double minMajorThreshold;
	private Double maxMinorThreshold;
	private Double minMinorThreshold;
	private Double maxInfoThreshold;
	private Double minInfoThreshold;
	private Integer issueCount;


	public Long getLine() {
		return line;
	}
	public void setLine(Long line) {
		this.line = line;
	}
	public Long getPeriod() {
		return period;
	}
	public void setPeriod(Long period) {
		this.period = period;
	}
	public MrecSet getSet() {
		return set;
	}
	public void setSet(MrecSet set) {
		this.set = set;
	}
	public Double getValue() {
		return value;
	}
	public void setValue(Double value) {
		this.value = value;
	}
	public String getLineName() {
		return lineName;
	}
	public void setLineName(String lineName) {
		this.lineName = lineName;
	}

	public Boolean getIsAggregate() {
		return isAggregate;
	}
	public void setIsAggregate(Boolean isAggregate) {
		this.isAggregate = isAggregate;
	}
	public Double getMaxCriticalThreshold() {
		return maxCriticalThreshold;
	}
	public void setMaxCriticalThreshold(Double maxCriticalThreshold) {
		this.maxCriticalThreshold = maxCriticalThreshold;
	}
	public Double getMinCriticalThreshold() {
		return minCriticalThreshold;
	}
	public void setMinCriticalThreshold(Double minCriticalThreshold) {
		this.minCriticalThreshold = minCriticalThreshold;
	}
	public Double getMaxSevereThreshold() {
		return maxSevereThreshold;
	}
	public void setMaxSevereThreshold(Double maxSevereThreshold) {
		this.maxSevereThreshold = maxSevereThreshold;
	}
	public Double getMinSevereThreshold() {
		return minSevereThreshold;
	}
	public void setMinSevereThreshold(Double minSevereThreshold) {
		this.minSevereThreshold = minSevereThreshold;
	}
	public Double getMaxMajorThreshold() {
		return maxMajorThreshold;
	}
	public void setMaxMajorThreshold(Double maxMajorThreshold) {
		this.maxMajorThreshold = maxMajorThreshold;
	}
	public Double getMinMajorThreshold() {
		return minMajorThreshold;
	}
	public void setMinMajorThreshold(Double minMajorThreshold) {
		this.minMajorThreshold = minMajorThreshold;
	}
	public Double getMaxMinorThreshold() {
		return maxMinorThreshold;
	}
	public void setMaxMinorThreshold(Double maxMinorThreshold) {
		this.maxMinorThreshold = maxMinorThreshold;
	}
	public Double getMinMinorThreshold() {
		return minMinorThreshold;
	}
	public void setMinMinorThreshold(Double minMinorThreshold) {
		this.minMinorThreshold = minMinorThreshold;
	}
	public Double getMaxInfoThreshold() {
		return maxInfoThreshold;
	}
	public void setMaxInfoThreshold(Double maxInfoThreshold) {
		this.maxInfoThreshold = maxInfoThreshold;
	}
	public Double getMinInfoThreshold() {
		return minInfoThreshold;
	}
	public void setMinInfoThreshold(Double minInfoThreshold) {
		this.minInfoThreshold = minInfoThreshold;
	}
	public Integer getIssueCount() {
                return issueCount;
        }
        public void setIssueCount(Integer issueCount) {
                this.issueCount = issueCount;
        }

}
