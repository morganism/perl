package uk.co.cartesian.ascertain.um.web.action.mrec;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;

import uk.co.cartesian.ascertain.um.persistence.dao.UMCpmWrapper;
import uk.co.cartesian.ascertain.utils.persistence.dropdown.DbDropDown;
import uk.co.cartesian.ascertain.utils.persistence.dropdown.DropDown;
import uk.co.cartesian.ascertain.utils.persistence.dropdown.UserDefinedItem;
import uk.co.cartesian.ascertain.web.helpers.Utils;

public class MrecChartSetup 
extends Action 
{
	public static final String FORM_FROM_DATE = "from";
    public static final String FORM_TO_DATE = "to";
    public static final String FORM_MREC_TYPE = "mrecType";
    public static final String FORM_MREC_DEFINITION_ID_FILE = "mrecDefinitionId_file";
    public static final String FORM_MREC_DEFINITION_ID_TIME = "mrecDefinitionId_time";
    public static final String FORM_EDGE_ID = "edgeId";
    public static final String FORM_DISPLAY_TYPE = "displayType";
    public static final String FORM_RECONCILIATION_TYPE = "reconciliationType";
   
    public static final String MREC_TYPE_FILE_VALUE = "FILE";
    public static final String MREC_TYPE_TIME_VALUE = "TIME";

    private static final String ATTRIBUTE_MREC_TIME_LIST = "UM__MREC_TIME_LIST";

    private static final long CHART_HISTORY_DAYS = 28;
    private static final long CHART_FORWARD_DAYS = 0;
    private static final long MILLISECONDS_IN_A_DAY = 86400000;

    public static final String TMP_UID = "uk.co.cartesian.ascertain.um.web.action.mrec.MrecChartSetup";

    private static final String _TIME_MREC_SQL = 
        "select distinct mdr.mrec_definition_id,\n" + 
        "       mdr.name\n" + 
        "from um.mrec_metric_ref mmr\n" + 
        "inner join um.mrec_version_ref mvr\n" + 
        "        on mvr.mrec_version_id = mmr.mrec_version_id\n" + 
        "inner join um.mrec_definition_ref mdr\n" + 
        "        on mdr.mrec_definition_id = mvr.mrec_definition_id\n" +
        "order by name";
    
    
    /**
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    throws Exception
    {

	    //Set up to and from date
        DynaActionForm dform = (DynaActionForm) form;
        String from = (String) dform.get(FORM_FROM_DATE);
        String to = (String) dform.get(FORM_TO_DATE);

        if (from == null || from.length() == 0)
        {
            dform.set(FORM_FROM_DATE, Utils.dateToLongString(new Date(System.currentTimeMillis() - (CHART_HISTORY_DAYS * MILLISECONDS_IN_A_DAY))));
        }
        if (to == null || to.length() == 0)
        {
            dform.set(FORM_TO_DATE, Utils.dateToLongString(new Date(System.currentTimeMillis() + (CHART_FORWARD_DAYS * MILLISECONDS_IN_A_DAY))));
        }

        //Create the drop downs
        List<UserDefinedItem> userDefinedItems = new ArrayList<UserDefinedItem>();
        userDefinedItems.add(new UserDefinedItem("<Please Select>", DropDown.NONE_ID));

        DbDropDown timeDd = new DbDropDown(false, false, userDefinedItems, _TIME_MREC_SQL, UMCpmWrapper.getConnectionPoolName());
        request.setAttribute(ATTRIBUTE_MREC_TIME_LIST, timeDd);

        return mapping.findForward("success");
    }

}
