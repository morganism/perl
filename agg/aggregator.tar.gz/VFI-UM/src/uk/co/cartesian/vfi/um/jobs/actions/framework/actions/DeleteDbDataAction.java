package uk.co.cartesian.ascertain.jobs.actions.framework.actions;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import uk.co.cartesian.ascertain.jobs.actions.framework.JobAction;
import uk.co.cartesian.ascertain.jobs.actions.framework.JobActionException;
import uk.co.cartesian.ascertain.jobs.batch.Batch;
import uk.co.cartesian.ascertain.jobs.utils.ErrorCodes;
import uk.co.cartesian.ascertain.utils.database.cpm.ConnectionPoolManager;
import uk.co.cartesian.ascertain.utils.log.LogInitialiser;
import uk.co.cartesian.ascertain.utils.parse.AscertainParseException;
import uk.co.cartesian.ascertain.utils.parse.SquareBracketSubstitutionParser;
import uk.co.cartesian.ascertain.web.helpers.Utils;

/**
 * Removes archived data.
 * @author Cartesian
 */
public class DeleteDbDataAction
extends JobAction
{
    private static final long serialVersionUID = 1L;
    private static Logger logger = LogInitialiser.getLogger(DeleteDbDataAction.class.getName());
    
    private static String _PARTITION_RANGE_QUERY = 
        "SELECT COUNT(*)\n" +
        "FROM all_part_tables t\n" +
        "WHERE t.owner = ?\n" +
        "AND t.table_name = ?\n" +
        "AND t.partitioning_type = 'RANGE'";

    private static String _TABLE_PARTITIONS_QUERY = 
        "SELECT t.partition_position,\n" +
        "       t.high_value,\n" +
        "       t.partition_name\n" +
        "FROM all_tab_partitions t\n" +
        "WHERE t.table_owner = ?\n" +
        "AND t.table_name = ?\n" +
	"AND t.partition_position > 1 \n" + // added for VFI-UM, as interval partitioning is turned on, and the last range partition cannot be dropped
        "ORDER BY 1 ASC ";  // Sort to ensure partitions dropped in correct order - Cannot order by t.high_value

    private static String _REBUILD_UNUSABLE_LOCAL_INDEX_PARTITIONS =
    	"SELECT 'ALTER INDEX '||t.index_owner ||'.' || t.index_name||' REBUILD PARTITION '||t.partition_name stmt,\n" +
    	"       t.index_name,\n" + 
    	"       t.partition_name\n" + 
    	"FROM   all_ind_partitions t\n" + 
    	"JOIN   all_part_indexes p\n" + 
    	"    ON     p.owner = t.index_owner\n" + 
    	"AND    p.index_name  = t.index_name\n" + 
    	"WHERE  p.owner = ?\n" + 
    	"AND    p.table_name  = ?\n" + 
    	"AND    t.status      = 'UNUSABLE'\n" + 
    	"ORDER BY 1 ASC,2 ASC";

    private static String _MAKE_MVS_SAFE_FROM_DELETIONS = // TRUE if you DO NOT want DELETION to UPDATE MV
        "SELECT 'MVIEW '||m.owner||'.'||m.mview_name||' on table '||a.owner||'.'||a.table_name" +
        "||' is not fresh and therefore not safe for deletion' stmt\n" +
        "FROM  all_tables                 a\n" +
        "JOIN  all_mview_detail_relations d\n" +
        "    ON    a.table_name = d.detailobj_name\n" +
        "JOIN  all_mviews                 m\n" +
        "    ON    m.OWNER = d.owner\n" +
        "AND   m.MVIEW_NAME = d.mview_name\n" +
        "WHERE a.owner = ?\n" +
        "AND   a.table_name = ?\n" +
        "AND   refresh_mode = 'DEMAND'\n" +
        "AND (    staleness          = 'NEEDS_COMPILE'\n" +
        "      OR AFTER_FAST_REFRESH = 'NEEDS_COMPILE'\n" +
        "      OR compile_state      = 'NEEDS_COMPILE')\n";

    private static String _ALTER_MVS_CONSIDER_FRESH =
        "SELECT distinct 'alter materialized view ' || m.owner || '.' || m.mview_name || ' CONSIDER FRESH' stmt\n" + 
        "FROM  all_tables                 a\n" +
        "JOIN  all_mview_detail_relations d\n" +
        "    ON    a.table_name = d.detailobj_name\n" +
        "JOIN  all_mviews                 m\n" + 
        "    ON    m.OWNER = d.owner\n" +
        "AND   m.MVIEW_NAME = d.mview_name\n" +
        "WHERE a.owner = ?\n" +
        "AND   a.table_name = ?\n" +
        "AND   refresh_mode = 'DEMAND'\n" +
        "AND (    staleness          = 'NEEDS_COMPILE'\n" +
        "      OR AFTER_FAST_REFRESH = 'NEEDS_COMPILE'\n" +
        "      OR compile_state      = 'NEEDS_COMPILE')\n";


    private static final String _DATE_VARIABLE = ExportDbDataToFileAction._DATE_VARIABLE;  //The square bracket substitution variable name for the date
    private static final String _CP_PARAMETER = "-cp";
    private static final String _SCHEMA_PARAMETER = "-schema";
    private static final String _TABLE_PARAMETER = "-table";
    private static final String _WHERE_CLAUSE_PARAMETER = "-whereClause"; //The where clause - limits how much data to delete when not using partitions
    private static final String _WINDOW_PARAMETER = "-window"; //This is the number of days of data to keep
    //private static final String _PARTITION_SAFE_PARAMETER = "-partitionSafe";  //No longer used replaced by -partitionHighValue.  If set then we use partitioning!
    private static final String _PARTITION_HIGH_VALUE_PARAMETER = "-partitionHighValue";  //SQL that defines how we determine the partition high value
    private static final String _MAKE_MVS_SAFE_FROM_DELETES_PARAMETER = "-makeMVsSafeFromDeletes"; //[true|false]Refers to whether MV's on the object should have the effects of the deletion applied

    /**
     * 
     */
    @Override
    public List<Batch> perform(Batch batch)
    throws JobActionException
    {
        logger.debug("DeleteDbDataAction:execute(...) - START");
        setReturnCode(ErrorCodes.SUCCESS);
        
        //Get our parameter values
        String cpName = getRequiredParameter(_CP_PARAMETER).toUpperCase();
        String schema = getRequiredParameter(_SCHEMA_PARAMETER).toUpperCase();
        String tableName = getRequiredParameter(_TABLE_PARAMETER).toUpperCase();
        String partitionHighValueSql = getOptionalParameter(_PARTITION_HIGH_VALUE_PARAMETER);
        String makeMVsSafeFromDeletes = getOptionalParameter(_MAKE_MVS_SAFE_FROM_DELETES_PARAMETER);
        String whereClauseSql = getOptionalParameter(_WHERE_CLAUSE_PARAMETER);
        String window = getOptionalParameter(_WINDOW_PARAMETER);

        // if mvMakeSaveFromDeletes is true check to see that relevant MVs are fresh and exit if not.  Otherwise ignore MV state
        boolean doDelete = true;
        if(makeMVsSafeFromDeletes == null) makeMVsSafeFromDeletes = "true"; //Default to true
        if(makeMVsSafeFromDeletes.equalsIgnoreCase("true")) 
        {
           int depMVsStale = countDependentNonFreshMVs(cpName, schema, tableName); 
           if( depMVsStale > 0 )  //exit with error if there are stale MVs
           {
               log("There are one or more stale materialised views associated with the data about to be deleted - deletion aborted");
               setReturnCode(ErrorCodes.STATE);
               doDelete = false;
           }
        }
        
        if(doDelete)
        {
            //Currently this stuff supports one substitution variable [DATE]
            //Figure out the date up to which we delete data
            Integer days = 0;
            if(StringUtils.isNotEmpty(window))
            {
                days = Integer.valueOf(window);
            }
            Calendar archivalDate = new GregorianCalendar();
            archivalDate.add(Calendar.HOUR, -1*days*24);
            
            //OK we are going to delete some data...
            if(StringUtils.isNotEmpty(partitionHighValueSql) && (isRangePartitioned(cpName, schema, tableName)) )
            {
                doDropPartitions(cpName, schema, tableName, partitionHighValueSql, archivalDate);
            }
            else
            {
                doDeleteFromTable(cpName, schema, tableName, whereClauseSql, archivalDate);
            }
             
            // having deleted the data, if we must make any MV's safe ( no deletions in MV ) we must alter the MVs to fresh
            if( makeMVsSafeFromDeletes.equalsIgnoreCase("true") )
            {
               doConsiderFreshForTableMvs(cpName, schema, tableName); 
            }
        }

        logger.debug("DeleteDbDataAction:execute(...) - FINISH");
        return null;
    }

    /**
     *
     * @param schema
     * @param tableName
     * @return
     * @throws JobActionException
     */
    private int countDependentNonFreshMVs(String cpmName, String schema, String tableName)
    throws JobActionException
    {
        int returnValue = 0;

        Connection c = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String stmt = null;
        try
        {
            c = ConnectionPoolManager.getInstance().getConnection(cpmName, true);
            ps = c.prepareStatement(_MAKE_MVS_SAFE_FROM_DELETIONS);
            ps.setString(1, schema);
            ps.setString(2, tableName);
            rs = ps.executeQuery();
            int mvCount = 0;
            while(rs.next())
            {
                ++mvCount;
                stmt  = rs.getString("stmt");
                log(stmt);
            } 
            returnValue = mvCount;
        }
        catch(SQLException e)
        {
            logger.error("DeleteDbDataAction:execute(...) - SQL Error while checking for stale MVs", e);
            log("SQL Error while checking for stale materialised views.");
            throw new JobActionException("SQL Error checking for stale MVs\n" + e.getMessage(), ErrorCodes.SQL);
        }
        finally
        {
            try{c.close();} catch (Exception e) {};
            try{ps.close();} catch (Exception e) {};
            try{rs.close();} catch (Exception e) {};
        }
        return returnValue;
    }

    
    /**
     * 
     * @param schema
     * @param tableName
     * @return
     * @throws JobActionException
     */
    private boolean isRangePartitioned(String cpmName, String schema, String tableName)
    throws JobActionException
    {
        boolean returnValue = false;
        
        Connection c = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            c = ConnectionPoolManager.getInstance().getConnection(cpmName, true);
            ps = c.prepareStatement(_PARTITION_RANGE_QUERY);
            ps.setString(1, schema);
            ps.setString(2, tableName);
            rs = ps.executeQuery();
            while(rs.next())
            {
                Integer count = rs.getInt(1);
                if (count > 0) 
                {
                    returnValue = true;
                }
            }
        }
        catch(SQLException e)
        {
            logger.error("DeleteDbDataAction:isRangePartitioned(...) - SQL Error while checking partitioning.", e);
            log("SQL Error while checking partitioning.");
            throw new JobActionException("SQL Error while checking partitioning\n" + e.getMessage(), ErrorCodes.SQL);
        }
        finally
        {
            try{c.close();} catch (Exception e) {};
            try{ps.close();} catch (Exception e) {};
            try{rs.close();} catch (Exception e) {};
        }
        return returnValue;
    }

    
    /**
     * This method will fail if the partitioning is not date partitioning, maybe need to make this a little more intelligent??
     * @param cpmName
     * @param schema
     * @param tableName
     * @param givenWhereClause
     * @param window
     * @throws JobActionException
     */
    private void doDropPartitions(String cpmName, String schema, String tableName, String partitionHighValueSql, Calendar archivalDate)
    throws JobActionException
    {
        //If it is safe to use partition pruning then we ignore the where clause and simply delete all partition outside of our window
        Connection c = null;
        PreparedStatement ps1 = null;
        PreparedStatement ps2 = null;
        PreparedStatement ps3 = null;
        Statement s = null;
        Statement s2 = null;
        ResultSet rs1 = null;
        ResultSet rs2 = null;
        ResultSet rs3 = null;
        try
        {
            //Set up our query to get the partitions to drop
            c = ConnectionPoolManager.getInstance().getConnection(cpmName, true);
            ps1 = c.prepareStatement(_TABLE_PARTITIONS_QUERY);
            ps1.setString(1, schema);
            ps1.setString(2, tableName);

            //Set up the query to get the index partitions that need rebuilding ( 0 to n )
            ps3 = c.prepareStatement(_REBUILD_UNUSABLE_LOCAL_INDEX_PARTITIONS);
            ps3.setString(1, schema);
            ps3.setString(2, tableName);           
            
            //Parse our query and substitute in the [DATE] variable
            Map<String, String> variables = SquareBracketSubstitutionParser.convertJobParametersToParserParameters(this.getParameters());
            variables.put(_DATE_VARIABLE, "TO_DATE('" + Utils.dateToShortString(archivalDate.getTime()) + "','" + Utils.ORACLE_SHORT_DATE_FORMAT + "')");
            SquareBracketSubstitutionParser parser = new SquareBracketSubstitutionParser(variables);
            String highValueSql = parser.parse(partitionHighValueSql);
            
            //Get all partitions for this table
            String highValue = null;
            String partitionName = null;
            String sql = null;
            String ddl = null;
            String indexName = null;
            rs1 = ps1.executeQuery();
            while(rs1.next())
            {
                // For each of the partitions check to see if it is old enough to be dropped
                highValue = rs1.getString("high_value");
                sql = "SELECT 'true' FROM dual WHERE " + highValue + " < (" + highValueSql + ")";
                ps2 = c.prepareStatement(sql);
                rs2 = ps2.executeQuery();

                if(rs2.next())
                {
                    // This partition is old enough to be deleted - create drop statement
                    // update global indexes slower but keeps global indexes usable and online throughout
                    // faster and less expensive than rebuilding the index afterwards
                    partitionName = rs1.getString("partition_name");
                    ddl = "ALTER TABLE " + schema + "." + tableName + " DROP PARTITION " + partitionName + " UPDATE GLOBAL INDEXES ";
                    log("Dropping partition '" + tableName + ":" + partitionName + "'");
                    s = c.createStatement();
                    s.executeUpdate(ddl);
                    s.close();
                }
                ps2.close();
                rs2.close();
           
                //Once all partitions to be dropped for table have been dropped then check for and rebuild unusable index partitions
                rs3 = ps3.executeQuery();
                while(rs3.next())
                {
                    // If rows found the index partition is unusable so needs to be rebuilt so execute the generated statement
                    ddl = rs3.getString("stmt");
                    partitionName = rs3.getString("partition_name");
                    indexName = rs3.getString("index_name");
                    log("Rebuilding Index partition '" + indexName + ":" + partitionName + "' on table " + tableName );
                    s2 = c.createStatement();
                    s2.executeUpdate(ddl);
                    s2.close();
                }
                rs3.close();                
            }
        }
        catch(Exception e)
        {
            logger.error("DeleteDbDataAction:doDropPartitions(...) - SQL Error while dropping partitions.", e);
            log("SQL Error while dropping partitions.");
            throw new JobActionException("SQL Error while dropping partitions\n" + e.getMessage(), ErrorCodes.SQL);
        }
        finally
        {
            try{c.close();} catch (Exception e) {};
            try{ps1.close();} catch (Exception e) {};
            try{ps2.close();} catch (Exception e) {};
            try{ps3.close();} catch (Exception e) {};
            try{s.close();} catch (Exception e) {};
            try{rs1.close();} catch (Exception e) {};
            try{rs2.close();} catch (Exception e) {};
            try{rs3.close();} catch (Exception e) {};
        }
    }
    
    /**
     * 
     * @param cpmName
     * @param schema
     * @param tableName
     * @param givenWhereClause
     * @param window
     * @throws JobActionException
     */
    private void doDeleteFromTable(String cpmName, String schema, String tableName, String givenWhereClause, Calendar archivalDate)
    throws JobActionException
    {
        String sqlCommand = "DELETE FROM " + schema + "." + tableName + " srct ";
        
        //Now we define the query part to limit what data is exported
        Connection con = null;
        Statement s = null;
        try
        {
            if( (givenWhereClause != null) && (!givenWhereClause.trim().equals("")) )
            {
                //Create the where clause part of the statement
                String whereClause = givenWhereClause;
                
                //Parse our query and substitute in the [DATE] variable
                Map<String, String> variables = SquareBracketSubstitutionParser.convertJobParametersToParserParameters(this.getParameters());
                variables.put(_DATE_VARIABLE, "TO_DATE('" + Utils.dateToShortString(archivalDate.getTime()) + "','" + Utils.ORACLE_SHORT_DATE_FORMAT + "')");
                SquareBracketSubstitutionParser parser = new SquareBracketSubstitutionParser(variables);
                whereClause = parser.parse(whereClause);
                sqlCommand += "\n" + whereClause;
            }

            con = ConnectionPoolManager.getInstance().getConnection(cpmName, true);
            s = con.createStatement();
            int records = s.executeUpdate(sqlCommand);
            log("Deleted "+records+" records from table "+schema + "." + tableName);
            
        }
        catch(AscertainParseException e)
        {
        	log("SQL Command: "+sqlCommand);
            throw new JobActionException(e.getMessage(), ErrorCodes.FORMAT);
        }
        catch(SQLException e)
        {
        	log("SQL Command: "+sqlCommand);
            logger.error("DeleteDbDataAction:doDeleteFromTable(...) - SQL Error while deleting.", e);
            log("SQL Error while deleting.");
            throw new JobActionException("SQL Error while deleting\n" + e.getMessage(), ErrorCodes.SQL);
        }
        finally
        {
            try{con.close();} catch (Exception e) {};
            try{s.close();} catch (Exception e) {};
        }
    }

    /**
     *
     * @param cpmName
     * @param schema
     * @param tableName
     */
    private void doConsiderFreshForTableMvs(String cpmName,String schema,String tableName)
    throws JobActionException
    {
        Connection c4 = null;
        Connection c5 = null;
        PreparedStatement ps4 = null;
        Statement s5 = null;
        ResultSet rs4 = null;

        //Set up our query to get the commands to make the MVS related to the table fresh
        try 
        {
           c4 = ConnectionPoolManager.getInstance().getConnection(cpmName, true);
           ps4 = c4.prepareStatement(_ALTER_MVS_CONSIDER_FRESH);
           ps4.setString(1, schema);
           ps4.setString(2, tableName);
           rs4 = ps4.executeQuery(); 
           c5 = ConnectionPoolManager.getInstance().getConnection(cpmName, true); 
           
           while(rs4.next())
           { 
                 String sqlCommand = rs4.getString("stmt");
                 s5 = c5.createStatement();
                 s5.execute(sqlCommand);
                 s5.close();
           }
           
           c5.close();
           ps4.close();
           rs4.close();
           c4.close();
        }
        catch(SQLException e)
        {
            logger.error("DeleteDbDataAction:doConsiderFreshForTableMvs(...) - SQL Error while performing a consider fresh on the materialized views.", e);
            log("SQL Error while performing a consider fresh on the materialized views.");
            throw new JobActionException("SQL Error while performing a consider fresh on the materialized views\n" + e.getMessage(), ErrorCodes.SQL);
        }
        finally
        {
            try{c4.close();} catch (Exception e) {};
            try{ps4.close();} catch (Exception e) {};
            try{rs4.close();} catch (Exception e) {};
            try{c5.close();} catch (Exception e) {};
            try{s5.close();} catch (Exception e) {};
        }
    }
}

