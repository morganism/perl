package uk.co.cartesian.ascertain.um.persistence.persister.mrec;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.apache.commons.lang.NotImplementedException;
import org.apache.log4j.Logger;
import org.apache.struts.util.LabelValueBean;

import uk.co.cartesian.ascertain.um.web.action.mrec.MrecChartSetup;
import uk.co.cartesian.ascertain.um.web.action.mrec.MrecChartable;
import uk.co.cartesian.ascertain.utils.log.LogInitialiser;
import uk.co.cartesian.ascertain.utils.persistence.Data;
import uk.co.cartesian.ascertain.utils.persistence.DatabasePersister;
import uk.co.cartesian.ascertain.utils.persistence.Resources;
import uk.co.cartesian.ascertain.utils.persistence.exceptions.ReadException;

public class MrecChartDatabasePersister extends DatabasePersister{

	protected static Logger logger = LogInitialiser.getLogger(MrecChartDatabasePersister.class.getName());

	public MrecChartDatabasePersister(Resources resources) {
		super(resources);
	}

	@Override
	protected void create(Data data, Connection conn) throws SQLException {
		throw new NotImplementedException();
	}

	@Override
	protected void delete(Data data, Connection conn) throws SQLException {
		throw new NotImplementedException();
	}

	@Override
	protected void read(Data data, Connection conn) throws SQLException, ReadException, IOException {
		throw new NotImplementedException();
	}

	@Override
	protected void readAll(List<Data> list, Connection conn) throws SQLException, ReadException, IOException {
		throw new NotImplementedException();
	}

	@Override
	protected void update(Data data, Connection conn) throws SQLException {
		throw new NotImplementedException();
	}

    private static final String CHARTDATA_SQL1 =
    	/* Get available Data from  um.agg_f_mrec_chart */
	"SELECT 'n' as is_aggregate, \n" +
	"	afmc.d_period_id, \n" +
        "	to_char(afmc.d_period_id,'DD/MM/YYYY HH24:MI') as d_period_string, \n" +
        "	to_char(afmc.d_period_id,'DD-MM-YYYY-HH24-MI-SS') as d_period_url, \n" +
        "	afmc.d_mrec_line_id, \n" +
        "	dmreclmv.mrec_line_type, \n" +
        "	dmreclmv.mrec_line_name, \n" +
        "	dmreclmv.mrec_definition_id, \n" +
       	"	dmreclmv.mrec_version_id, \n" +
       	"	dmreclmv.mrec_type, \n" +
        "	_MREC_DISP_TYPE_ mrec, \n" +
       	" 	issue_count \n" +
	"FROM um.agg_f_mrec_chart afmc \n" +
	"INNER JOIN um.d_mrec_line_mv dmreclmv \n" +
       	"	ON afmc.d_mrec_line_id = dmreclmv.d_mrec_line_id \n" +
	"LEFT OUTER JOIN (select mrec_definition_id, d_period_id, decode (count(mij.issue_id), 0, null, count(mij.issue_id)) as issue_count \n" +
	"		  from	 um.mrec_issue_jn mij \n " +
	"		  where  mij.issue_status = 'O' \n" +
	"		  and 	 mij.d_period_id between _FROM_DATE_ and _TO_DATE_ \n " +
	"		  and	 mij.mrec_definition_id = _MREC_DEF_ID_  \n " + 
	"		  group by mrec_definition_id, d_period_id ) mij2 ON mij2.d_period_id = afmc.d_period_id and dmreclmv.line_type = 0 \n" + 
	"WHERE dmreclmv.mrec_definition_id = _MREC_DEF_ID_ \n";
    
    private static final String CHARTDATA_SQL2 =
        "AND afmc.d_edge_id = _EDGE_ID_ \n";

    private static final String CHARTDATA_SQL5A =
	"AND afmc.d_period_id >= _FROM_DATE_ \n" +
        "AND afmc.d_period_id <= _TO_DATE_ \n" +
	"UNION ALL \n" +
    	/* Get NULL value (padding) for missing 
    	   Aggregated Data from start of date range up to 
    	   the first d_period of current data in F_MREC in the date range */

	"SELECT 'n' as is_aggregate, \n" +
        "   	dd.d_period_id as d_period_id, \n" +
        "   	to_char(dd.d_period_id,'DD/MM/YYYY HH24:MI') as d_period_string, \n" +
        "   	to_char(dd.d_period_id,'DD-MM-YYYY-HH24-MI-SS') as d_period_url, \n" +
        "   	dmreclmv.d_mrec_line_id, \n" +
        "   	dmreclmv.mrec_line_type, \n" +
        "   	dmreclmv.mrec_line_name, \n" +
        "   	dmreclmv.mrec_definition_id, \n" +
        "   	dmreclmv.mrec_version_id, \n" +
        "   	dmreclmv.mrec_type, \n" +
        "   	null, \n" +
        "   	null \n" +
    	"FROM um.d_mrec_line_mv  dmreclmv \n" +
    	"FULL OUTER JOIN um.d_period dd \n" +
        "         ON 1=1 \n" +
    	"WHERE dmreclmv.mrec_definition_id = _MREC_DEF_ID_ \n" +
    	"AND dd.d_period_id >= _FROM_DATE_ \n" +
    	"AND dd.d_period_id <=  _TO_DATE_ \n" +
    	"AND not exists ( select 1  \n" +
        " 	          from   um.agg_f_mrec_chart ac  \n" +
        "             	  where  ac.d_period_id = dd.d_period_id  \n" +
        "             	  and    ac.d_mrec_line_id = dmreclmv.d_mrec_line_id )     \n";        

    private static final String FORECAST_QUERY = 
	" AND   exists (select max(d_mrec_line_id) \n" +
        "               from   um.d_mrec_line_mv d \n" +
        "               where  d.mrec_definition_id = dmreclmv.mrec_definition_id \n" +
        "               and    d.line_type = dmreclmv.line_type) \n";


    private static final String CHARTDATA_PARENT_QUERY_NO_THRES =
	"SELECT is_aggregate, d_period_id, d_period_string, d_period_url, d_mrec_line_id, mrec_line_type, mrec_line_name, mrec_definition_id, mrec_type, mrec, issue_count \n" +
	"       , null max_critical_threshold \n" +
        "       , null min_critical_threshold \n" +
        "       , null max_severe_threshold \n" +
        "       , null min_severe_threshold \n" +
        "       , null max_major_threshold \n" +
        "       , null min_major_threshold \n" +
        "       , null max_minor_threshold \n" +
        "       , null min_minor_threshold \n" +
        "       , null max_info_threshold \n" +
        "       , null min_info_threshold \n" +
	"FROM t \n";

    private static final String CHARTDATA_PARENT_QUERY = 
        "SELECT is_aggregate, d_period_id, d_period_string, d_period_url, d_mrec_line_id, mrec_line_type, mrec_line_name, mrec_definition_id, mrec_type, mrec, issue_count \n" + 
	"       , volumetricrec.getThresholdLimit(3000, 'MAX', threshold_version_id, thres_sum) max_critical_threshold \n" +
        "       , volumetricrec.getThresholdLimit(3000, 'MIN', threshold_version_id, thres_sum) min_critical_threshold \n" +
        "       , volumetricrec.getThresholdLimit(3001, 'MAX', threshold_version_id, thres_sum) max_severe_threshold \n" +
        "       , volumetricrec.getThresholdLimit(3001, 'MIN', threshold_version_id, thres_sum) min_severe_threshold \n" +
        "       , volumetricrec.getThresholdLimit(3002, 'MAX', threshold_version_id, thres_sum) max_major_threshold \n" +
        "       , volumetricrec.getThresholdLimit(3002, 'MIN', threshold_version_id, thres_sum) min_major_threshold \n" +
        "       , volumetricrec.getThresholdLimit(3003, 'MAX', threshold_version_id, thres_sum) max_minor_threshold \n" +
        "       , volumetricrec.getThresholdLimit(3003, 'MIN', threshold_version_id, thres_sum) min_minor_threshold \n" +
        "       , volumetricrec.getThresholdLimit(3004, 'MAX', threshold_version_id, thres_sum) max_info_threshold \n" +
        "       , volumetricrec.getThresholdLimit(3004, 'MIN', threshold_version_id, thres_sum) min_info_threshold \n" +
	" FROM (select  t.*, \n" +
	"		greatest (sum(decode(t.mrec_line_type,'i Side',abs(mrec),0)) over (partition by t.d_period_id),  \n" +
 	"        		  sum(decode(t.mrec_line_type,'j Side',abs(mrec),0)) over (partition by t.d_period_id)) thres_sum,  \n" +
        "       	decode(mrec_line_type, \n" +
        "                  'Reconciliation',um.volumetricrec.getThreshVerIdForDPeriod(t.mrec_version_id, t.d_period_id) \n" +
        "                  ,null) threshold_version_id \n" +
        " 	from t  ) \n" ;

	private static final String READ_MREC_CHARTDATA_DISCRETE_ORDER =
		"ORDER BY d_period_id, mrec_line_type\n";


	/**
	 * 
	 * @param chartable
	 * @return
	 */
	public static String getChartSql(MrecChartable chartable)
	{
        // NOTE Avoid using bind variables as this can result in Oracle using
        // inappropriate/inefficient/cached execution plans

		String sql = CHARTDATA_SQL1;		
		
		if(MrecChartSetup.MREC_TYPE_FILE_VALUE.equals(chartable.getMrecType()) && chartable.getEdgeId() != null && chartable.getEdgeId() != 0)
		{
		    //This is a file set reconciliation so we need to add the edge stuff
		    sql += CHARTDATA_SQL2 + CHARTDATA_SQL5A;

		    //Substitute our edge value
	        sql = sql.replaceAll("_EDGE_ID_", chartable.getEdgeId().toString());
		}
		else
		{	
			if (chartable.getReconciliationType() != null && chartable.getReconciliationType().equalsIgnoreCase("forecast")) {
				sql += FORECAST_QUERY;
			}		
 	           //This is a time based reconciliation so we do not need to add the edge stuff
			sql += CHARTDATA_SQL5A;		
		}

		//Substitute in our dates
		sql = sql.replaceAll("_FROM_DATE_", "to_date( '"+chartable.getFromDate()+"','DY, DD MONTH YYYY')")
		         .replaceAll("_TO_DATE_", "to_date( '"+chartable.getToDate()+"','DY, DD MONTH YYYY')");

	    //substitute our mrec definition value
	    sql = sql.replaceAll("_MREC_DEF_ID_", chartable.getMrecDefinitionId().toString());

	    // substitute display type
	    if (chartable.getDisplayType() != null && chartable.getDisplayType().equalsIgnoreCase("percentage") && chartable.getReconciliationType().equalsIgnoreCase("value")) {
	    	
	    	sql = sql.replaceAll("_MREC_DISP_TYPE_", "mrec_perc");
	    }
	    else if (chartable.getDisplayType() != null && chartable.getDisplayType().equalsIgnoreCase("percentage") && chartable.getReconciliationType().equalsIgnoreCase("forecast")) {
//		sql = sql.replaceAll("_MREC_DISP_TYPE_", "decode(dmreclmv.line_type,0,frec_perc,-1,round(forecast_perc_plus/greatest(abs(forecast_perc_plus),abs(mrec_perc_plus)),4)*100,1,round(mrec_perc_plus/greatest(abs(mrec_perc_plus),abs(forecast_perc_plus)),4)*100)");
		sql = sql.replaceAll("_MREC_DISP_TYPE_", "frec_perc");
	    } 
	    else if (chartable.getDisplayType() != null && chartable.getDisplayType().equalsIgnoreCase("absolute") && chartable.getReconciliationType().equalsIgnoreCase("forecast")) {
//		sql = sql.replaceAll("_MREC_DISP_TYPE_", "decode(dmreclmv.line_type,0,frec,-1,forecast_perc_plus,1,mrec_perc_plus)");
		sql = sql.replaceAll("_MREC_DISP_TYPE_", "decode(dmreclmv.line_type,0,frec,mrec)");
	    }
	    else {
	    	sql = sql.replaceAll("_MREC_DISP_TYPE_", "mrec");
	    }
	    

		if ( chartable.getIncludeThresholds() != null && chartable.getIncludeThresholds().equalsIgnoreCase("true") ) 
		{
			sql = "WITH t AS ( \n" + sql + ") \n" + CHARTDATA_PARENT_QUERY;
		}
		else 
		{
			sql = "WITH t AS ( \n" + sql + ") \n" + CHARTDATA_PARENT_QUERY_NO_THRES;
		}

		return sql;
	}

	/**
	 * Returns the result set inserting an 'order by' clause into the query. Independently on how the 
	 * data table is ordered on the page, the result set used to create the chart has to be always ordered by date.
	 */
	public ResultSet readOrderedChartResults(Statement stmt, MrecChartable chartable) throws SQLException
	{
		String chartSql = getChartSql(chartable);
		int orderByClausePosition = chartSql.toLowerCase().lastIndexOf("order by");		
		if (orderByClausePosition > 0)
		{
			chartSql = chartSql.substring(0, orderByClausePosition);
		}
				
		chartSql = chartSql + READ_MREC_CHARTDATA_DISCRETE_ORDER;

		logger.debug("MrecChartDatabasePersister.readOrderedChartResults(...) - Statement: \n" + chartSql);
		
		return stmt.executeQuery(chartSql);
		
	}


	private static final String READ_ALL_LINES =
		"SELECT distinct t.mrec_line_name\n" +
		"  FROM\n" + 
		"       um.d_mrec_line_mv t\n" + 
		" WHERE\n" + 
		"   t.mrec_definition_id = ?\n" + 
		" ORDER BY t.mrec_line_name";
	
	public void readAllLineIds(MrecChartable chartable, List<LabelValueBean> mrecLines, Connection conn)
	throws SQLException, ReadException
	{
		Statement stmnt = null;
		ResultSet results = null;
		try
		{
			// NOTE Avoid using bind variables as this can result in Oracle using
			// inappropriate/inefficient/cached execution plans
			String readAllLineIdsSQL = READ_ALL_LINES.replaceFirst("\\?", chartable.getMrecDefinitionId().toString());

			logger.debug("MrecChartDatabasePersister:readAllLineIds(...) - SQL: \n" + readAllLineIdsSQL);

			stmnt = conn.createStatement();
			results = stmnt.executeQuery(readAllLineIdsSQL);
			while(results.next())
			{
				mrecLines.add(new LabelValueBean(results.getString("mrec_line_name"), results.getString("mrec_line_name")));
			}
		}
		finally
		{
			try { results.close(); } catch (Throwable te) {}
			try { stmnt.close(); } catch (Throwable te) {}
		}
	}

	private static final String ISSUE_GRACE_PERIOD =
	" select trunc(sysdate) - to_number( nvl(trim(replace(REGEXP_substr(parameters, '-issue_grace_period ([[:digit:]]+)', 1),'-issue_grace_period ','')),-100) ) PERIOD_ID \n " +
	" from   um.mrec_version_ref  \n " +
	" where  mrec_definition_id = ? \n " +
	" and    status = 'A'  \n " +
	" union  \n " +
	" select trunc(sysdate) + 100  \n " +
	" from   dual  \n " +
	" where  not exists (select 1  \n " +
        "     	             from   um.mrec_version_ref   \n " +
        " 	             where  mrec_definition_id = ?  \n " +
        " 	             and    status = 'A' ) "; 

	public Long readIssueGracePeriod(MrecChartable chartable, Connection conn)
        throws SQLException, ReadException
        {
                Statement stmnt = null;
                ResultSet results = null;
		Long issueGraceCutoff = null;
                try
                {
                        // NOTE Avoid using bind variables as this can result in Oracle using
                        // inappropriate/inefficient/cached execution plans
                        String readIssueGracePeriod = ISSUE_GRACE_PERIOD.replaceAll("\\?", chartable.getMrecDefinitionId().toString());
					

                        logger.debug("MrecChartDatabasePersister:readIssueGracePeriod(...) - SQL: \n" + readIssueGracePeriod);

                        stmnt = conn.createStatement();
                        results = stmnt.executeQuery(readIssueGracePeriod);
			
                        while(results.next())
                        {
				issueGraceCutoff = new Long( results.getTimestamp("PERIOD_ID").getTime() );
                        }
			return issueGraceCutoff;
                }
                finally
                {
                        try { results.close(); } catch (Throwable te) {}
                        try { stmnt.close(); } catch (Throwable te) {}
                }
	}


	private static final String NUM_ACTIVE_THRESHOLDS =
        " select count(1) active" + 
	" from   um.mrec_definition_ref d, " +
        "	 um.mrec_version_ref v, " +
	"        imm.threshold_version_ref i " +
	" where  d.mrec_definition_id = v.mrec_definition_id " +
	" and    v.status = 'A'" +
	" and    i.threshold_definition_id = v.threshold_definition_id " +
	" and    i.status = 'A' " +
	" and    d.mrec_definition_id = ? ";


        public Integer readActiveThreshold(MrecChartable chartable, Connection conn)
        throws SQLException, ReadException
        {
                Statement stmnt = null;
                ResultSet results = null;
                Integer activeThreshold = null;
                try
                {
                        // NOTE Avoid using bind variables as this can result in Oracle using
                        // inappropriate/inefficient/cached execution plans
                        String readActiveThresholdSQL = NUM_ACTIVE_THRESHOLDS.replaceAll("\\?", chartable.getMrecDefinitionId().toString());


                        logger.debug("MrecChartDatabasePersister:readActiveThreshold(...) - SQL: \n" + readActiveThresholdSQL);

                        stmnt = conn.createStatement();
                        results = stmnt.executeQuery(readActiveThresholdSQL);

                        while(results.next())
                        {
                                activeThreshold = new Integer( results.getInt("active") );
                        }
                        return activeThreshold;
                }
                finally
                {
                        try { results.close(); } catch (Throwable te) {}
                        try { stmnt.close(); } catch (Throwable te) {}
                }
        }


	public static Object getChartAggDataSql(MrecChartable chartable) 
	{
		String sql = getChartSql(chartable);
		return sql;
	}

}
